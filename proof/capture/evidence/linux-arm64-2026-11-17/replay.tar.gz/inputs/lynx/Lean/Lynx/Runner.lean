module

import Lynx
import Lynx.Runner.Elab
import Lean

/-! JSON runner for verification and Lean source rendering. Positions are one-based Unicode character positions.
See `Runner.schema.json` for the request and response schemas.
Every syntax node requires `span`: `[]`, `[line]`, or `[line, column]`.
Nodes without a location inherit the enclosing location, if any. Line-only spans
never imply a diagnostic column. Function and variable names retain their Erlang spelling; the decoder
constructs and escapes their Lean identifiers.

Each verified file emits `{"status": "ok" | "error" | "skipped", "file": ..., "module": ...,
"time_ms": ..., "theorems": [...], "diagnostics": [...]}`. Time includes rendering, imports,
elaboration, auditing, and artifact writing; shared runtime loading is excluded.
Theorems report `name` (including `/arity`) and `time_ms` for each law command's
elaboration. They are elaborated sequentially and may use earlier declarations.
Cached and skipped files have no theorem timings because no elaboration occurs.
Files blocked by an unsuccessful input import are skipped without elaboration.
A `{"status": "done"}` message terminates each completed request.
Each newline-delimited request includes `"command": "verify"`.
Updates are flushed as each file finishes. The runner exits when stdin closes,
abandoning any request in progress, as nobody reads its result.
Invalid input and runner failures return `{"status": "failure", "message": "..."}`.
Each verification diagnostic has `file`, `module`, nullable `declaration`, `severity`
(error/warning/information), and `message`, with `line` and `column` included only when known.
Requests include `cache_dir` and may include `options`, an object of Lean options set
at the top of every translated module. Values are natural numbers, Booleans, or strings.
Input files may include a hexadecimal `cache_key` incorporating dependencies; cached
artifacts are kept separately for each set of options.
Requests may include `debug_dir`, a directory where the rendered source of every module
is written by module path, such as `Erlang/json.lean`, when a file does not verify.
With `debug` set to `"lean"` or `"olean"`, they are written even when every file verifies.
With `"olean"`, the compiled files of every verified module are also written next to its
source, such as `Erlang/json.olean`, so the directory can be added to `LEAN_PATH`.
Requests may include `check_source: true` to parse each rendered source and report
an error where it differs from the elaborated commands.
Requests may include `export`, a path where the declarations of the request's modules
and their dependencies are written in Lean's export format, for checking with
`lake check --from-export`. It is written only when every file verifies.
Files without a key and their dependents are verified without persistent caching.
Verified artifacts are cached below `cache_dir/lean-VERSION-HASH`, using Lake’s compiled artifact hashes.
Only successful elaboration and axiom audits are cached; updates include a `cached` Boolean.
Input files are an ordered array of {file, module, imports, contents, cache_key} objects.
A prelude file has empty contents and a preludes array of {source, file, span,
indentation} blocks, joined in order into one module. The first block begins with
the module header, whose imports are loaded before the blocks are parsed and
elaborated sequentially. Dependent files import the prelude before their embedded proofs
and termination suffixes are parsed; no declarations leak through request order.
Theorem nodes contain name, named params, an optional requires helper, an ensures helper,
and a proof object. Helpers are ordinary translated computations called with the theorem's
parameters. Each helper carries its level, which selects how it is stated to return true.
Helpers returning `Except` are stated directly as `= .ok true`. Other helpers are stated
through `Lynx.sequential`, except concurrent ones, which are stated through
`Lynx.concurrent`: every run of the helper ends with `ok true`. An absent requires helper
means no assumption. Helpers that are not pure
are called through `Lynx.apply helper table depth`, which passes them the dispatcher of the
program's function table up to a call depth; an optional table names it, and it defaults
to empty. Their statements hold from some depth on: `∃ bound, ∀ depth, bound ≤ depth → …`.
Proofs are elaborated against these statements as given.
Levels are `pure`, `apply`, `sequential`, and `concurrent`. Definitions, mutual groups,
table entries, remote calls, and theorem helpers state their purity (`pure`, `sequential`, or
`concurrent`) apart from calls to function values, and a `dispatches` flag, which is `true`
when present, if they make such calls. Their level is then also at least the file's
`dispatcher_purity`: the purity of calls to function values in the program, which is `apply`
when every entry of its table returns `Except`. Theorems name these `requires_purity`,
`requires_dispatches`, `ensures_purity`, and `ensures_dispatches`.
Pure definitions return `Except Lynx.Exception Lynx.Term`, including those that may not
return: translation cutoffs and partial fixed points raise `Lynx.Exception.exhausted`.
Definitions at the `apply` level also return `Except`, but call function values through a
`Lynx.Dispatcher`, which every definition that is not pure receives as its first parameter.
Calls carry their callee's purity, other computations embed callees returning `Except` with
`Result.ofExcept`, and callees that are not pure receive the caller's dispatcher.
A proof object contains tactic source, nonnegative indentation, and a span locating
the first character of that source. The producer handles host delimiters and line offsets. Proof syntax keeps
its own source ranges, mapped to the supplied host locations using a synthetic file map.
Original source files are not read.
Definitions may carry a termination_suffix object with Lean source, file, indentation,
and span. It is parsed as the declaration's termination clause before elaboration;
suffix diagnostics retain the supplied origin, even when it differs from the module file.
Function values carry the module, name, and arity the compiler gave their function.
Function tables carry entry metadata: module, name, body, captures, args, purity, and span.
The decoder builds typed callables, which receive the dispatcher unless they are pure.
Each entry also generates checked application equations through
`Lynx.Dispatcher.ofTable`. Pure entries preserve the call depth; other entries run
with the dispatcher one level down. Receives also run one level down, from the
dispatcher's `inner` level, and do not return once the depth is exhausted.
Files are elaborated in the supplied dependency order against their declared imports.
Verified files are exported to temporary modules for importing by later files.
Each file's definitions live in its module namespace.
Module names arrive qualified by the producer, such as `Erlang.foo` or `Elixir.Foo`;
functions acquire `/arity` here.
Imports name other input modules or compiled Lean modules loaded from disk.
Erlang imports without a distinct input file resolve to Lynx.Modules.Erlang.* runtime modules.
Runtime module identities differ from their Erlang.* declaration namespaces.
Verification elaborates decoded syntax directly. Rendering pretty-prints that syntax as Lean source. -/
namespace Lynx.Runner
open Lean
open Lean.Parser.Term (doSeqItem)

private def fields (j : Json) (allowed : List String) : Except String Unit := do
  let obj ← j.getObj?
  for (key, _) in obj.toArray do
    unless key ∈ allowed do throw s!"unsupported field '{key}'"

private def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
private def str (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
private def arr (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

/-- Nonnegative literal float segment sizes are resolved to their width, keeping
generated proofs free of runtime size computations. Other sizes are computed at runtime. -/
private def literalFloatWidth (segment : Json) (unit : Nat) : Except String (Option Nat) := do
  let size ← field segment "size"
  if (← str size "kind") == "integer" then
    let size ← (← field size "value").getInt?
    pure (if 0 ≤ size then some (size.toNat * unit) else none)
  else pure none

private inductive Location where
  | unknown
  | line (line : Nat)
  | column (position : Position)

private instance : Inhabited Location := ⟨.unknown⟩

private structure Span where
  info : SourceInfo := .synthetic 0 0 true
  location : Location := .unknown
  fileName : Option String := none

private instance : Inhabited Span := ⟨{}⟩

private structure ProofDiagnostic where
  declarationName : Name
  message : String
  location : Location
  fileName : Option String := none

private structure PatternExtraction where
  lookup : TSyntax `term
  pattern : TSyntax `term
  catchAll : Bool := false
  /-- The binder for the remaining bits of a bitstring extraction. The pattern
  then matches the extracted value only. -/
  rest : Option (TSyntax `term) := none

private structure DecodeState where
  spans : Array Span := #[]
  diagnostics : Array ProofDiagnostic := #[]
  theorems : Array (Name × Span) := #[]
  /-- The source of each theorem's proof, rendered verbatim. -/
  proofSources : Array (Name × String) := #[]
  patternExtractions : Array PatternExtraction := #[]
  nextBitstringPattern : Nat := 0
  /-- Names of the pooled literals already defined in this module. -/
  literals : Std.HashSet String := {}
  /-- Definitions of pooled literals, emitted before the command using them. -/
  pendingLiterals : Array (TSyntax `command) := #[]
  /-- Whether the computation being decoded returns `Except`: it is pure, or pure
  apart from calling function values. -/
  pureContext : Bool := false
  /-- The dispatcher available to the computation being decoded, which every
  computation that is not pure receives as its first parameter. -/
  dispatcher : Option (TSyntax `term) := none
  /-- The purity of each definition in this file, by `name/arity`. -/
  purities : Std.HashMap String String := {}
  /-- The purity of calls to function values in this program, if the file makes any. -/
  dispatcherPurity : Option String := none

private abbrev DecodeM := ReaderT Lean.Environment (StateT DecodeState (Except String))

/-- Pure computations return `Except`, and the others `Result`. -/
private def contextual (pureName resultName : Name) : DecodeM Ident := do
  return mkIdent (if (← get).pureContext then pureName else resultName)

/-- The result type of the computation being decoded, for values of a type. -/
private def resultTypeOf (value : TSyntax `term) : DecodeM (TSyntax `term) := do
  if (← get).pureContext then
    let except := mkIdent ``Except
    let exception := mkIdent ``Lynx.Exception
    return Unhygienic.run `($except $exception $value)
  let result := mkIdent ``Lynx.Result
  return Unhygienic.run `($result $value)

/-- Embed a pure computation in the computation being decoded. -/
private def embedPure (computation : TSyntax `term) : DecodeM (TSyntax `term) := do
  if (← get).pureContext then return computation
  let ofExcept := mkIdent ``Lynx.Result.ofExcept
  return Unhygienic.run `($ofExcept $computation)

private def purityRank : String → Nat
  | "pure" => 0
  | "apply" => 1
  | "sequential" => 2
  | _ => 3

/-- The level a node runs at: its own purity, raised to the program's dispatcher
purity when the node calls function values, as `dispatchesKey` records. -/
private def resolveLevel (dispatcherPurity : Option String) (j : Json)
    (key dispatchesKey : String) :
    Except String String := do
  let level ← str j key
  unless ["pure", "sequential", "concurrent"].contains level do
    throw s!"{key} must be pure, sequential, or concurrent"
  match field j dispatchesKey with
  | .error _ => return level
  | .ok value =>
    unless (← value.getBool?) do throw s!"{dispatchesKey} must be true when present"
    let some dispatcherPurity := dispatcherPurity
      | throw s!"{dispatchesKey} requires the file's dispatcher_purity"
    return if purityRank dispatcherPurity > purityRank level then dispatcherPurity else level

private def level (j : Json) (key dispatchesKey : String) : DecodeM String := do
  resolveLevel (← get).dispatcherPurity j key dispatchesKey

/-- Pure computations and those that only call function values return `Except`. -/
private def returnsExcept (level : String) : Bool := level == "pure" || level == "apply"

/-- The parameter through which definitions receive their dispatcher. -/
private def dispatcherId : Ident := mkIdent `lynxDispatch

/-- Decode in a context of the given purity, restoring the enclosing one. Contexts
that are not pure receive their dispatcher as `dispatcher`. -/
private def withPurity (level : String) (action : DecodeM α)
    (dispatcher : TSyntax `term := ⟨dispatcherId.raw⟩) : DecodeM α := do
  let previous := (← get)
  modify fun s => { s with
    pureContext := returnsExcept level
    dispatcher := if level == "pure" then none else some dispatcher }
  let result ← action
  modify fun s => { s with pureContext := previous.pureContext, dispatcher := previous.dispatcher }
  return result

/-- The dispatcher of the computation being decoded, which `use` requires. -/
private def requireDispatcher (use : String) : DecodeM (TSyntax `term) := do
  match (← get).dispatcher with
  | some dispatcher => pure dispatcher
  | none => throw s!"pure computations cannot {use}"

private def span (map : FileMap) (j : Json) (parent : Span := {}) : DecodeM Span := do
  let xs ← arr j "span"
  if xs.isEmpty then
    modify fun s => { s with spans := s.spans.push parent }
    return parent
  unless xs.size ≤ 2 do throw "span must be [], [line], or [line, column]"
  let line ← xs[0]!.getNat?
  let column ← if xs.size == 2 then xs[1]!.getNat? else pure 1
  unless line > 0 && column > 0 && line ≤ map.getLastLine do
    throw "span position is out of range"
  let pos := map.ofPosition ⟨line, column - 1⟩
  unless map.toPosition pos == ⟨line, column - 1⟩ do
    throw "span position is out of range"
  -- A line-only location is a zero-width anchor, not a claimed first column.
  let stop := if xs.size == 1 || pos.atEnd map.source then pos else pos.next map.source
  let result : Span := ⟨.synthetic pos stop true,
    if xs.size == 1 then .line line else .column ⟨line, column - 1⟩, none⟩
  modify fun s => { s with spans := s.spans.push result }
  return result

private def identifier (value : String) : DecodeM (TSyntax `ident) := do
  let stx ← Parser.runParserCategory (← read) `term value
  unless stx.isIdent do throw s!"invalid identifier '{value}'"
  return mkIdent stx.getId

/-- Fill quotation scaffolding only; preserve source information on spliced nodes. -/
private partial def located (info : SourceInfo) (stx : Syntax) : Syntax :=
  match stx with
  | .node old kind args => .node (if old == .none then info else old) kind (args.map (located info))
  | .atom old value => .atom (if old == .none then info else old) value
  | .ident old raw name pre => .ident (if old == .none then info else old) raw name pre
  | .missing => .missing

private def withSpan (info : SourceInfo) (stx : TSyntax k) : TSyntax k :=
  ⟨(located info stx.raw).setInfo info⟩

private def functionName (name : String) (arity : Nat) : TSyntax `ident :=
  mkIdent (Name.mkSimple s!"{name}/{arity}")

private def variableName (j : Json) : DecodeM (TSyntax `ident) := do
  let value ← field j "name"
  let name ← match value.getNat? with
    | .ok index => pure s!"_{index}"
    | .error _ => do
      match value.getStr? with
      | .ok name => pure (if name.startsWith "_" then "_v" ++ name else "v" ++ name)
      | .error _ => do
        -- Generated binders occupy a namespace that Core variable names cannot reach.
        if (field value "group").isOk then
          fields value ["group", "index"]
          pure s!"lynxMapGroup{← (← field value "group").getNat?}_{← (← field value "index").getNat?}"
        else if (field value "bitstring").isOk then
          fields value ["bitstring"]
          pure s!"lynxBits{← (← field value "bitstring").getNat?}"
        else if (field value "pattern").isOk then
          fields value ["pattern"]
          pure s!"lynxMap{← (← field value "pattern").getNat?}"
        else
          fields value ["generated"]
          let index ← (← field value "generated").getNat?
          pure s!"lynxGenerated{index}"
  return mkIdent (Name.mkSimple name)

private def param (map : FileMap) (info : Span) (j : Json) : DecodeM (TSyntax `ident) := do
  fields j ["kind", "name", "span"]
  unless (← str j "kind") == "var" do throw "parameter must be a variable"
  return withSpan (← span map j info).info (← variableName j)

private def product (values : Array (TSyntax `term)) : DecodeM (TSyntax `term) := do
  if values.isEmpty then return Unhygienic.run `(())
  let mut result := values.back!
  for value in values.toList.dropLast.reverse do
    result := Unhygienic.run `(($value, $result))
  return result

/-- Give shared continuations the enclosing computation's result type before
elaborating matches that capture them. Keep the result polymorphic for Core's
zero and multiple return values, and use applied lambdas for recursive proofs. -/
private def withContinuation (name : TSyntax `ident) (body next : TSyntax `term) :
    DecodeM (TSyntax `term) := do
  let valueType := mkIdent `lynxValue
  let bodyName := mkIdent `lynxBody
  let nextName := mkIdent `lynxNext
  let unitType := mkIdent ``Unit
  let resultType ← resultTypeOf valueType
  return Unhygienic.run `(
    (fun {$valueType : Type}
        ($bodyName : ($unitType → $resultType) → $resultType)
        ($nextName : $unitType → $resultType) => $bodyName $nextName)
      (fun $name => $body) (fun (_ : $unitType) => $next))

private partial def catchAllPattern (j : Json) : Except String Bool := do
  match ← str j "kind" with
  | "var" | "wildcard" => return true
  | "map" => return !(← arr j "entries").isEmpty
  | "bitstring_pattern" => return true
  | "alias" => catchAllPattern (← field j "pattern")
  | _ => return false

/-- Collect extraction checks during ordinary recursive pattern decoding. -/
private def withExtractions (decode : DecodeM α) : DecodeM (α × Array PatternExtraction) := do
  let saved := (← get).patternExtractions
  modify fun s => { s with patternExtractions := #[] }
  let result ← decode
  let patterns := (← get).patternExtractions
  modify fun s => { s with patternExtractions := saved }
  return (result, patterns)

/-- Queue a decoded pattern before the checks that depend on its bindings. -/
private def addExtraction (lookup pattern : TSyntax `term) (catchAll : Bool := false)
    (nested : Array PatternExtraction := #[]) (rest : Option (TSyntax `term) := none) : DecodeM Unit :=
  modify fun s => { s with
    patternExtractions := (s.patternExtractions.push ⟨lookup, pattern, catchAll, rest⟩) ++ nested }

/-- Match extracted values with the clause's fallthrough continuation. -/
private def patternMatches (patterns : Array PatternExtraction)
    (body fallback : TSyntax `term) : TSyntax `term := Id.run do
  let mut branch := body
  let extracted := mkIdent `lynxExtracted
  let extract := mkIdent ``Lynx.Term.Bitstring.extract
  for extraction in patterns.reverse do
    let lookup := extraction.lookup
    let pat := extraction.pattern
    branch := if extraction.catchAll then
      Unhygienic.run `(match ($lookup) with | $pat => $branch)
    else if let some rest := extraction.rest then
      let found := if pat.raw.isIdent then Unhygienic.run `(fun $pat $rest => $branch)
        else Unhygienic.run `(fun $extracted:ident $rest => match $extracted:ident with
          | $pat => $branch | _ => $fallback)
      Unhygienic.run `($extract ($lookup) $found (fun _ => $fallback))
    else
      Unhygienic.run `(match ($lookup) with | $pat => $branch | _ => $fallback)
  return branch

/-- Source locations do not affect literal-key identity. -/
private partial def withoutSpans : Json → Json
  | .arr values => .arr (values.map withoutSpans)
  | .obj fields => Json.mkObj (fields.toArray.toList.filterMap fun (key, value) =>
      if key == "span" then none else some (key, withoutSpans value))
  | value => value

private def literalMapKeys? (pattern : Json) : Except String (Option (Array Json)) := do
  unless (← str pattern "kind") == "map" do return none
  fields pattern ["kind", "entries", "span"]
  let entries ← arr pattern "entries"
  if entries.isEmpty then return none
  let mut keys := #[]
  for entry in entries do
    fields entry ["key", "value", "span"]
    let key ← field entry "key"
    unless (← str key "kind") ∈ ["atom", "integer", "float", "binary", "bitstring", "nil"] do
      return none
    keys := keys.push (withoutSpans key)
  return some (keys.qsort fun a b => a.compress < b.compress)

/-- Share literal-key extraction across consecutive clauses. Move their value
patterns and guards into an ordinary inner match; a label shares fallthrough. -/
private def groupMapCases (j : Json) : DecodeM (Option Json) := do
  let clauses ← arr j "cases"
  let expressions ← arr j "expressions"
  let nodeSpan ← field j "span"
  for start in [:clauses.size] do
    let patterns ← arr clauses[start]! "patterns"
    let signatures ← patterns.mapM fun pat => do return ← literalMapKeys? pat
    unless signatures.any (·.isSome) do continue
    unless patterns.size == expressions.size do throw "match case must have one pattern per expression"
    let mut stop := start + 1
    while stop < clauses.size do
      let next ← arr clauses[stop]! "patterns"
      if next.size != patterns.size then break
      let mut same := true
      for i in [:patterns.size] do
        if let some keys := signatures[i]! then
          if (← literalMapKeys? next[i]!) != some keys then same := false
      unless same do break
      stop := stop + 1
    if stop == start + 1 then continue
    let group := (← get).spans.size
    let binder (index : Nat) := Json.mkObj [("kind", toJson "var"),
      ("name", Json.mkObj [("group", toJson group), ("index", toJson index)]), ("span", nodeSpan)]
    let mut values := #[]
    let mut outerPatterns := #[]
    for i in [:patterns.size] do
      let pat := patterns[i]!
      if signatures[i]!.isSome then
        let mut entries := #[]
        for entry in ← arr pat "entries" do
          let value := binder values.size
          values := values.push value
          entries := entries.push (entry.setObjVal! "value" value)
        outerPatterns := outerPatterns.push (pat.setObjVal! "entries" (toJson entries))
      else
        let value := binder values.size
        values := values.push value
        outerPatterns := outerPatterns.push value
    let mut innerCases := #[]
    for clause in clauses.extract start stop do
      let pats ← arr clause "patterns"
      let mut innerPatterns := #[]
      for i in [:patterns.size] do
        if signatures[i]!.isSome then
          let mut entries ← arr pats[i]! "entries"
          for entry in ← arr patterns[i]! "entries" do
            let key := withoutSpans (← field entry "key")
            let some index := entries.findIdx? (fun e => withoutSpans (e.getObjValD "key") == key)
              | throw "inconsistent grouped map keys"
            innerPatterns := innerPatterns.push (← field entries[index]! "value")
            entries := entries.eraseIdxIfInBounds index
        else innerPatterns := innerPatterns.push pats[i]!
      innerCases := innerCases.push (clause.setObjVal! "patterns" (toJson innerPatterns))
    let label := toJson s!"map_group_{group}"
    let jump := Json.mkObj [("kind", toJson "jump"), ("label", label), ("span", nodeSpan)]
    let wildcard := Json.mkObj [("kind", toJson "wildcard"), ("span", nodeSpan)]
    let fallback (pats : Array Json) := Json.mkObj [("patterns", toJson pats),
      ("body", jump), ("span", nodeSpan)]
    innerCases := innerCases.push (fallback (values.map fun _ => wildcard))
    let inner := Json.mkObj [("kind", toJson "match"), ("expressions", toJson values),
      ("cases", toJson innerCases), ("span", nodeSpan)]
    let grouped := Json.mkObj [("patterns", toJson outerPatterns),
      ("body", inner), ("span", ← field clauses[start]! "span")]
    let body := j.setObjVal! "cases" (toJson (clauses.extract 0 start ++
      #[grouped, fallback (expressions.map fun _ => wildcard)]))
    let continuation ← if stop < clauses.size then
      pure (j.setObjVal! "cases" (toJson (clauses.extract stop clauses.size)))
      else do
        let tuple (elements : Array Json) := Json.mkObj [("kind", toJson "tuple"),
          ("elements", toJson elements), ("span", nodeSpan)]
        let value := if expressions.size == 1 then expressions[0]! else tuple expressions
        let atom := Json.mkObj [("kind", toJson "atom"), ("value", toJson "case_clause"), ("span", nodeSpan)]
        pure (Json.mkObj [("kind", toJson "raise"), ("class", toJson "error"),
          ("reason", tuple #[atom, value]), ("span", nodeSpan)])
    return some (Json.mkObj [("kind", toJson "label"), ("label", label),
      ("continuation", continuation), ("body", body), ("span", nodeSpan)])
  return none

/-- Helpers for collecting type tests from the positive, conjunctive part of a guard. -/
private def guardKind (j : Json) : String := (str j "kind").toOption.getD ""

private def atomIs (j : Json) (value : String) : Bool :=
  guardKind j == "atom" && (str j "value").toOption == some value

private def returned? (j : Json) : Option Json := do
  guard (guardKind j == "return")
  let values ← (arr j "values").toOption
  guard (values.size == 1)
  return values[0]!

private def returnsBool (j : Json) (value : String) : Bool :=
  (returned? j).any (atomIs · value)

/-- Core lowers short-circuit operators to matches. Leave those guards intact,
along with any guard containing a disjunction. -/
private partial def guardHasBranching (j : Json) : Bool :=
  guardKind j == "match" ||
  (guardKind j == "remote_call" && (str j "module").toOption == some "Erlang.erlang" &&
    ((str j "name").toOption.getD "") ∈ ["or", "orelse"]) ||
  match j with
  | .arr xs => xs.any guardHasBranching
  | .obj xs => xs.toArray.any fun (_, v) => guardHasBranching v
  | _ => false

private abbrev GuardBindings := Array (Json × Json)

private def guardLookup (bindings : GuardBindings) (name : Json) : Option Json :=
  (bindings.findSome? fun (key, value) => if key == name then some value else none)

/-- Standalone binders, including those in values extracted from map patterns.
An alias on an existing structural pattern already constrains its own type. -/
private partial def guardBinders (j : Json) : Array Json :=
  match guardKind j with
  | "var" => #[(j.getObjValD "name")]
  | "cons" => guardBinders (j.getObjValD "head") ++ guardBinders (j.getObjValD "tail")
  | "tuple" => ((arr j "elements").toOption.getD #[]).flatMap guardBinders
  | "map" => ((arr j "entries").toOption.getD #[]).flatMap fun e => guardBinders (e.getObjValD "value")
  | "alias" => guardBinders (j.getObjValD "pattern")
  | _ => #[]

private def typePattern? (j : Json) : Option Json := do
  guard (guardKind j == "remote_call" && (str j "module").toOption == some "Erlang.erlang")
  let args ← (arr j "args").toOption
  guard (args.size == 1 && guardKind args[0]! == "var")
  let constructor ← match (str j "name").toOption.getD "" with
    | "is_integer" => some "integer"
    | "is_float" => some "float"
    | "is_atom" => some "atom"
    | "is_tuple" => some "tuple"
    | "is_map" => some "map"
    | "is_pid" => some "pid"
    | "is_reference" => some "reference"
    | "is_function" => some "function"
    | "is_bitstring" => some "bitstring"
    | "is_binary" => some "binary"
    | _ => none
  return Json.mkObj [("kind", toJson "$type"), ("constructor", toJson constructor),
    ("span", j.getObjValD "span")]

/-- Follow the values that must be true, rather than every call evaluated by Core.
Only follow conjunctions and Core bind scaffolding; leave other operators intact. -/
private partial def positiveGuardCalls (j : Json) (bindings : GuardBindings := #[]) : Array Json := Id.run do
  match guardKind j with
  | "var" =>
    let some value := guardLookup bindings (j.getObjValD "name") | return #[]
    return positiveGuardCalls value (bindings.filter fun (key, _) => key != (j.getObjValD "name"))
  | "return" => return (returned? j).map (positiveGuardCalls · bindings) |>.getD #[]
  | "bind" | "try" =>
    if guardKind j == "try" && !returnsBool (j.getObjValD "handler") "false" then return #[]
    let vars := (arr j "vars").toOption.getD #[]
    if vars.size != 1 || guardKind vars[0]! != "var" then return #[]
    let name := (vars[0]!.getObjValD "name")
    return positiveGuardCalls (j.getObjValD "body")
      (#[ (name, (j.getObjValD "computation")) ] ++ bindings.filter fun (key, _) => key != name)
  | "remote_call" =>
    if (typePattern? j).isSome then return #[j]
    if (str j "module").toOption != some "Erlang.erlang" then return #[]
    let args := (arr j "args").toOption.getD #[]
    if args.size != 2 then return #[]
    if (str j "name").toOption == some "and" then
      return args.flatMap (positiveGuardCalls · bindings)
    return #[]
  | _ => return #[]

private def guardReturn (j value : Json) : Json := Json.mkObj
  [("kind", toJson "return"), ("values", toJson #[value]), ("span", (j.getObjValD "span"))]

private def guardTrue (j : Json) : Json := guardReturn j (Json.mkObj
  [("kind", toJson "atom"), ("value", toJson "true"), ("span", (j.getObjValD "span"))])

/-- Replace selected tests once, propagate Boolean constants through Core binds,
and shrink conjunctions without dropping computations that can still fail. -/
private partial def shrinkGuard (j : Json) (selected : Array Json)
    (values : GuardBindings := #[]) : Json × Array Json := Id.run do
  if let some i := selected.findIdx? (· == j) then
    return (guardTrue j, selected.eraseIdxIfInBounds i)
  if guardKind j == "var" then return (guardLookup values (j.getObjValD "name") |>.getD j, selected)
  if guardKind j ∈ ["bind", "try"] then
    let (computation, remaining) := shrinkGuard (j.getObjValD "computation") selected values
    let vars := (arr j "vars").toOption.getD #[]
    let names := vars.map (·.getObjValD "name")
    let values := values.filter fun (name, _) => !names.contains name
    if vars.size == 1 then
      if let some value := returned? computation then
        if atomIs value "true" || atomIs value "false" || guardKind value == "var" then
          return shrinkGuard (j.getObjValD "body") remaining (values.push (names[0]!, value))
    let (body, remaining) := shrinkGuard (j.getObjValD "body") remaining values
    if guardKind j == "bind" && vars.size == 1 then
      if let some value := returned? body then
        if guardKind value == "var" && value.getObjValD "name" == names[0]! then
          return (computation, remaining)
    return (j.setObjVal! "computation" computation |>.setObjVal! "body" body, remaining)
  let mut remaining := selected
  let mut result := j
  match j with
  | .arr xs =>
    let mut ys := #[]
    for x in xs do
      let (y, rest) := shrinkGuard x remaining values
      ys := ys.push y
      remaining := rest
    result := toJson ys
  | .obj xs =>
    for (key, value) in xs.toArray do
      if key ∈ ["span", "patterns", "name"] then continue
      let (value, rest) := shrinkGuard value remaining values
      result := result.setObjVal! key value
      remaining := rest
  | _ => pure ()
  if guardKind result == "remote_call" && (str result "module").toOption == some "Erlang.erlang" &&
      (str result "name").toOption == some "and" then
    let args := (arr result "args").toOption.getD #[]
    if args.size == 2 && args.all (atomIs · "true") then return (guardTrue result, remaining)
  return (result, remaining)

private partial def refineGuardPattern (j : Json) (name pattern : Json) : Json := Id.run do
  if guardKind j == "var" && (j.getObjValD "name") == name then
    return Json.mkObj [("kind", toJson "alias"), ("var", j),
      ("pattern", pattern), ("span", (j.getObjValD "span"))]
  match guardKind j with
  | "cons" => return j.setObjVal! "head" (refineGuardPattern (j.getObjValD "head") name pattern)
      |>.setObjVal! "tail" (refineGuardPattern (j.getObjValD "tail") name pattern)
  | "tuple" => return j.setObjVal! "elements" (toJson
      (((arr j "elements").toOption.getD #[]).map (refineGuardPattern · name pattern)))
  | "map" => return j.setObjVal! "entries" (toJson
      (((arr j "entries").toOption.getD #[]).map fun e =>
        e.setObjVal! "value" (refineGuardPattern (e.getObjValD "value") name pattern)))
  | "alias" => return j.setObjVal! "pattern" (refineGuardPattern (j.getObjValD "pattern") name pattern)
  | _ => return j

/-- Terms such as `match`, `if`, and `do` parse as `do` elements when written in a
`do` block. Parenthesize them so rendered source parses back to the same terms. -/
private def doTerm (term : TSyntax `term) : TSyntax `term :=
  let kinds := [``Parser.Term.do, ``Parser.Term.match, ``termIfThenElse, ``termDepIfThenElse,
    ``termIfLet, ``Parser.Term.let, ``Parser.Term.have]
  if kinds.any term.raw.isOfKind then Unhygienic.run `(($term)) else term

/-- Refine only locally bound variables. Core sometimes tests a scrutinee variable
instead of the fresh whole-value binder; map that name to the pattern binder. -/
private def refineGuardClause (c : Json) (expressions : Array Json) (receiveClause := false) : DecodeM Json := do
  let .ok guard := field c "guard" | return c
  if guardHasBranching guard then return c
  let patterns ← if receiveClause then pure #[← field c "pattern"] else arr c "patterns"
  let binders := patterns.flatMap guardBinders
  let mut aliases : GuardBindings := #[]
  for i in [:min patterns.size expressions.size] do
    if guardKind patterns[i]! == "var" && guardKind expressions[i]! == "var" then
      aliases := aliases.push (expressions[i]!.getObjValD "name", patterns[i]!.getObjValD "name")
  let mut refinements : GuardBindings := #[]
  let mut selected := #[]
  for call in positiveGuardCalls guard do
    let some pattern := typePattern? call | continue
    let args ← arr call "args"
    let source := (args[0]!.getObjValD "name")
    let name := if binders.contains source then source else (guardLookup aliases source).getD source
    unless binders.contains name do continue
    if refinements.any (fun (key, _) => key == name) then continue
    refinements := refinements.push (name, pattern)
    selected := selected.push call
  if refinements.isEmpty then return c
  let (guard, _) := shrinkGuard guard selected
  let mut c := c.setObjVal! "guard" guard
  if !receiveClause && returnsBool guard "true" then
    c := Json.mkObj ((← c.getObj?).toArray.toList.filter fun (key, _) => key != "guard")
  let mut patterns := patterns
  for (name, pattern) in refinements do
    patterns := patterns.map (refineGuardPattern · name pattern)
  return if receiveClause then c.setObjVal! "pattern" patterns[0]!
    else c.setObjVal! "patterns" (toJson patterns)

private partial def term (map : FileMap) (parent : Span) (pattern : Bool)
    (j : Json) : DecodeM (TSyntax `term) := do
  -- Named literals are pooled: defined once per module, before the command
  -- using them, and referred to by name. Patterns need their constructors.
  if let .ok name := str j "pooled" then
    let unnamed := Json.mkObj ((← j.getObj?).toArray.toList.filter (·.1 != "pooled"))
    if pattern then return ← term map parent pattern unnamed
    let id := mkIdent (Name.mkSimple name)
    unless (← get).literals.contains name do
      let decoded ← term map parent false unnamed
      let termType := mkIdent ``Lynx.Term
      let definition := Unhygienic.run `(def $id : $termType := $decoded)
      modify fun s => { s with literals := s.literals.insert name,
                               pendingLiterals := s.pendingLiterals.push definition }
    return id
  let info ← span map j parent
  let kind ← str j "kind"
  if pattern && kind ∈ ["local_call", "remote_call", "fun_call", "bind", "return", "raise", "raise_dynamic", "reraise", "nonzero_width", "orelse", "andalso", "in", "match", "receive", "try", "stacktrace", "label", "jump"] then
    throw s!"{kind} is not valid in patterns"
  let result ← match kind with
  | "$type" => do
    unless pattern do throw "type refinement is only valid in patterns"
    fields j ["kind", "constructor", "span"]
    let name ← str j "constructor"
    let ctor := mkIdent (``Lynx.Term ++ Name.mkSimple (if name == "binary" then "bitstring" else name))
    match name with
    | "integer" | "float" | "atom" | "tuple" | "map" | "pid" | "reference" =>
      pure (Unhygienic.run `($ctor _))
    | "bitstring" => pure (Unhygienic.run `($ctor _ _ _))
    | "binary" => pure (Unhygienic.run `($ctor _ 0 _))
    | "function" => pure (Unhygienic.run `($ctor _ _ _ _))
    | _ => throw "unsupported type refinement"
  | "wildcard" => do
    fields j ["kind", "span"]
    unless pattern do throw "wildcard is only valid in patterns"
    pure (Unhygienic.run `(_))
  | "var" => do
    fields j ["kind", "name", "span"]
    pure ⟨(← variableName j).raw⟩
  | "alias" => do
    fields j ["kind", "var", "pattern", "span"]
    unless pattern do throw "alias is only valid in patterns"
    let var ← param map info (← field j "var")
    let pat ← term map info true (← field j "pattern")
    pure (Unhygienic.run `($var:ident@$pat))
  | "integer" => do
    fields j ["kind", "value", "span"]
    let value ← (← field j "value").getInt?
    let literal : TSyntax `term := ⟨← Parser.runParserCategory (← read) `term (toString value)⟩
    let ctor := mkIdent ``Lynx.Term.integer
    pure (Unhygienic.run `($ctor $literal))
  | "float" => do
    fields j ["kind", "negative", "exponent", "fraction", "span"]
    let negative ← (← field j "negative").getBool?
    let exponent ← (← field j "exponent").getNat?
    let fraction ← (← field j "fraction").getNat?
    unless exponent < 2047 do throw "float exponent must be less than 2047"
    unless fraction < 2 ^ 52 do throw "float fraction must be less than 2^52"
    let sign := mkIdent (if negative then ``Bool.true else ``Bool.false)
    let exponent : TSyntax `term := ⟨Syntax.mkNumLit (toString exponent)⟩
    let fraction : TSyntax `term := ⟨Syntax.mkNumLit (toString fraction)⟩
    let ctor := mkIdent ``Lynx.Term.float
    pure (Unhygienic.run `($ctor ⟨$sign, $exponent, $fraction⟩))
  | "cutoff" => do
    fields j ["kind", "span"]
    unless !pattern do throw "translation cutoff is only valid in computations"
    embedPure ⟨(mkIdent ``Lynx.Except.cutoff).raw⟩
  | "atom" => do
    fields j ["kind", "value", "span"]
    let literal : TSyntax `term := ⟨Syntax.mkStrLit (← str j "value")⟩
    let ctor := mkIdent ``Lynx.Term.atom
    pure (Unhygienic.run `($ctor $literal))
  | "bitstring_pattern" => do
    fields j ["kind", "segments", "span", "input"]
    unless pattern do throw "bitstring pattern is only valid in patterns"
    let nodeSpan ← field j "span"
    let fresh : DecodeM Json := do
      let index := (← get).nextBitstringPattern
      modify fun s => { s with nextBitstringPattern := index + 1 }
      pure (Json.mkObj [("kind", toJson "var"), ("span", nodeSpan),
        ("name", Json.mkObj [("bitstring", toJson index)])])
    -- A matched variable is extracted from directly, without rebinding it.
    let binder ← match field j "input" with
      | .ok input => pure input
      | .error _ => fresh
    let input ← term map info true binder
    let mut remaining := input
    let accepted := Unhygienic.run `(Bool.true)
    let segments ← arr j "segments"
    let mut trailing := false
    for i in [:segments.size] do
      let segment := segments[i]!
      let segmentType ← str segment "type"
      let si ← span map segment info
      let value ← field segment "value"
      if segmentType == "binary" && i + 1 == segments.size then do
        fields segment ["type", "value", "size", "unit", "span"]
        let unit ← (← field segment "unit").getNat?
        unless 1 ≤ unit && unit ≤ 256 do throw "bitstring segment unit must be in 1..256"
        let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
        let size ← term map si false (← field segment "size")
        let extract := mkIdent ``Lynx.Term.Bitstring.matchTail
        trailing := true
        let lookup := Unhygienic.run `($extract $remaining $size $unit)
        addExtraction lookup accepted
        let (pat, nested) ← withExtractions (term map si true value)
        addExtraction remaining pat (← catchAllPattern value) nested
      else do
        let little ← if segmentType == "binary" then pure (mkIdent ``Bool.false) else
          match ← str segment "endian" with
          | "big" => pure (mkIdent ``Bool.false)
          | "little" => pure (mkIdent ``Bool.true)
          | other => throw s!"unsupported bitstring endianness '{other}'"
        let next ← fresh
        let rest ← term map si false next
        let extract ← if segmentType == "binary" then do
          fields segment ["type", "value", "size", "unit", "span"]
          let size ← term map si false (← field segment "size")
          let unit ← (← field segment "unit").getNat?
          unless 1 ≤ unit && unit ≤ 256 do throw "bitstring segment unit must be in 1..256"
          let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
          let extract := mkIdent ``Lynx.Term.Bitstring.matchBinary
          pure (Unhygienic.run `($extract $remaining $size $unit))
        else if segmentType == "integer" then do
          fields segment ["type", "value", "size", "unit", "signed", "endian", "span"]
          let size ← term map si false (← field segment "size")
          let unit ← (← field segment "unit").getNat?
          unless 1 ≤ unit && unit ≤ 256 do throw "integer segment unit must be in 1..256"
          let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
          let signed ← if ← (← field segment "signed").getBool? then pure (mkIdent ``Bool.true)
            else pure (mkIdent ``Bool.false)
          let extract := mkIdent ``Lynx.Term.Bitstring.matchInteger
          pure (Unhygienic.run `($extract $remaining $size $unit $signed $little))
        else if segmentType == "float" then do
          fields segment ["type", "value", "size", "unit", "endian", "span"]
          let unit ← (← field segment "unit").getNat?
          unless 1 ≤ unit && unit ≤ 256 do throw "float segment unit must be in 1..256"
          let width ← match ← literalFloatWidth segment unit with
            | some width => pure ⟨Syntax.mkNumLit (toString width)⟩
            | none => do
              let size ← term map si false (← field segment "size")
              let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
              let floatWidth := mkIdent ``Lynx.Term.Bitstring.floatWidth
              pure (Unhygienic.run `($floatWidth $size $unit))
          let extract := mkIdent ``Lynx.Term.Bitstring.matchFloat
          pure (Unhygienic.run `($extract $remaining $width $little))
        else if segmentType == "utf8" || segmentType == "utf16" || segmentType == "utf32" then do
          fields segment ["type", "value", "endian", "span"]
          if segmentType == "utf8" then do
            let extract := mkIdent ``Lynx.Term.Bitstring.matchUtf8
            pure (Unhygienic.run `($extract $remaining))
          else do
            let extract := mkIdent (if segmentType == "utf16" then
              ``Lynx.Term.Bitstring.matchUtf16 else ``Lynx.Term.Bitstring.matchUtf32)
            pure (Unhygienic.run `($extract $remaining $little))
        else throw s!"unsupported bitstring pattern segment '{segmentType}'"
        remaining := rest
        let (pat, nested) ← withExtractions (term map si true value)
        addExtraction extract pat false nested (rest := some rest)
    unless trailing do
      let finish := mkIdent ``Lynx.Term.Bitstring.matchEnd
      let lookup := Unhygienic.run `($finish $remaining)
      addExtraction lookup accepted
    pure input
  | "bitstring" => do
    fields j ["kind", "bytes", "last_bits", "span"]
    let bytes ← (← arr j "bytes").mapM fun byte => do
      let value ← byte.getNat?
      unless value < 256 do throw "bitstring bytes must be less than 256"
      pure (⟨Syntax.mkNumLit (toString value)⟩ : TSyntax `term)
    let lastBits ← (← field j "last_bits").getNat?
    unless lastBits < 8 do throw "bitstring last_bits must be less than 8"
    unless !bytes.isEmpty || lastBits == 0 do throw "empty bitstrings must have last_bits zero"
    let ctor := mkIdent ``Lynx.Term.bitstring
    let last : TSyntax `term := ⟨Syntax.mkNumLit (toString lastBits)⟩
    unless lastBits == 0 do
      let padding := 8 - lastBits
      let value ← (← arr j "bytes").back!.getNat?
      unless value % (2 ^ padding) == 0 do throw "bitstring padding must be zero"
    if pattern then
      if lastBits == 0 then pure (Unhygienic.run `($ctor ⟨⟨[$bytes,*]⟩⟩ 0 _))
      else pure (Unhygienic.run `($ctor ⟨⟨[$bytes,*]⟩⟩ ⟨$last, _⟩ _))
    else
      pure (Unhygienic.run `($ctor ⟨#[$bytes,*]⟩ $last (by decide)))
  | "bitstring_constructor" => do
    fields j ["kind", "segments", "span"]
    if pattern then throw "bitstring construction is not a pattern"
    let segments ← (← arr j "segments").mapM fun segment => do
      let segmentType ← str segment "type"
      match segmentType with
      | "integer" => fields segment ["type", "value", "size", "unit", "signed", "endian", "span"]
      | "float" => fields segment ["type", "value", "size", "unit", "endian", "span"]
      | "binary" => fields segment ["type", "value", "size", "unit", "span"]
      | "utf8" | "utf16" | "utf32" => fields segment ["type", "value", "endian", "span"]
      | other => throw s!"unsupported bitstring segment type '{other}'"
      let si ← span map segment info
      let value ← term map si false (← field segment "value")
      let body ← if segmentType == "binary" then do
        let size ← term map si false (← field segment "size")
        let unit ← (← field segment "unit").getNat?
        unless 1 ≤ unit && unit ≤ 256 do throw "binary segment unit must be in 1..256"
        let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
        let build := mkIdent ``Lynx.Term.Bitstring.binarySegment
        pure (Unhygienic.run `($build $value $size $unit))
      else do
        let little ← match ← str segment "endian" with
          | "big" => pure (mkIdent ``Bool.false)
          | "little" => pure (mkIdent ``Bool.true)
          | other => throw s!"unsupported bitstring segment endianness '{other}'"
        if segmentType == "utf8" then do
          let build := mkIdent ``Lynx.Term.Bitstring.utf8Segment
          pure (Unhygienic.run `($build $value))
        else if segmentType == "utf16" || segmentType == "utf32" then do
          let build := mkIdent (if segmentType == "utf16" then
            ``Lynx.Term.Bitstring.utf16Segment else ``Lynx.Term.Bitstring.utf32Segment)
          pure (Unhygienic.run `($build $value $little))
        else if segmentType == "float" then do
          let unit ← (← field segment "unit").getNat?
          unless 1 ≤ unit && unit ≤ 256 do throw "float segment unit must be in 1..256"
          let width ← match ← literalFloatWidth segment unit with
            | some width => pure ⟨Syntax.mkNumLit (toString width)⟩
            | none => do
              let size ← term map si false (← field segment "size")
              let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
              let floatWidth := mkIdent ``Lynx.Term.Bitstring.floatWidth
              pure (Unhygienic.run `($floatWidth $size $unit))
          let build := mkIdent ``Lynx.Term.Bitstring.floatSegment
          pure (Unhygienic.run `($build $value $width $little))
        else do
          let size ← term map si false (← field segment "size")
          let unit ← (← field segment "unit").getNat?
          unless 1 ≤ unit && unit ≤ 256 do throw "integer segment unit must be in 1..256"
          let _ ← (← field segment "signed").getBool?
          let unit : TSyntax `term := ⟨Syntax.mkNumLit (toString unit)⟩
          let build := mkIdent ``Lynx.Term.Bitstring.integerSegment
          pure (Unhygienic.run `($build $value $size $unit $little))
      pure (withSpan si.info body)
    let empty := Unhygienic.run `(Lynx.Term.bitstring ⟨#[]⟩ 0 (by decide))
    let ok := mkIdent ``Except.ok
    let append := mkIdent ``Lynx.Term.Bitstring.append
    let bind := mkIdent ``Except.bind
    let mut body := segments.back?.getD (Unhygienic.run `($ok $empty))
    -- All segment operands are Core values: preserve segment validation order.
    -- Construction is pure, so other computations embed it.
    for segment in segments.toList.dropLast.reverse do
      body := Unhygienic.run `($bind $segment (fun lynxBinarySegment =>
        $bind $body (fun lynxBinaryTail => $append lynxBinarySegment lynxBinaryTail)))
    embedPure body
  | "nil" => do
    fields j ["kind", "span"]
    pure ⟨(mkIdent ``Lynx.Term.nil).raw⟩
  | "cons" => do
    fields j ["kind", "head", "tail", "span"]
    -- Proper lists build their conses through `Lynx.Term.list`, except in
    -- patterns, which need constructors.
    if !pattern then
      let pooled (node : Json) := (node.getObjVal? "pooled").toOption.isSome
      let mut heads := #[]
      let mut rest := j
      while guardKind rest == "cons" && !pooled rest do
        heads := heads.push (← field rest "head")
        rest ← field rest "tail"
      if guardKind rest == "nil" && !pooled rest then
        let elements ← heads.mapM (term map info false)
        let list := mkIdent ``Lynx.Term.list
        return withSpan info.info (Unhygienic.run `($list [$elements,*]))
    let head ← term map info pattern (← field j "head")
    let tail ← term map info pattern (← field j "tail")
    let ctor := mkIdent ``Lynx.Term.cons
    pure (Unhygienic.run `($ctor $head $tail))
  | "function" => do
    fields j ["kind", "module", "name", "arity", "captures", "span"]
    let module := Syntax.mkStrLit (← str j "module")
    let name := Syntax.mkStrLit (← str j "name")
    let arity : TSyntax `term := ⟨Syntax.mkNumLit (toString (← (← field j "arity").getNat?))⟩
    let captures ← (← arr j "captures").mapM (term map info pattern)
    let ctor := mkIdent ``Lynx.Term.function
    pure (Unhygienic.run `($ctor $module $name $arity #[$captures,*]))
  | "tuple" => do
    fields j ["kind", "elements", "span"]
    let elements ← (← arr j "elements").mapM (term map info pattern)
    let ctor := mkIdent ``Lynx.Term.tuple
    -- Use Array's ordinary constructor in patterns, avoiding the array-literal
    -- match elaborator's auxiliary arity checks and equality proofs.
    if pattern then pure (Unhygienic.run `($ctor ⟨[$elements,*]⟩))
    else pure (Unhygienic.run `($ctor #[$elements,*]))
  | "map" => do
    fields j ["kind", "entries", "span"]
    if pattern then
      let entries ← arr j "entries"
      if entries.isEmpty then
        let ctor := mkIdent ``Lynx.Term.map
        return withSpan info.info (Unhygienic.run `($ctor _))
      let nodeSpan ← field j "span"
      let binder := Json.mkObj [("kind", toJson "var"),
        ("name", Json.mkObj [("pattern", toJson (← get).spans.size)]), ("span", nodeSpan)]
      let keys ← entries.mapM fun entry => do
        fields entry ["key", "value", "span"]
        let ei ← span map entry info
        term map ei false (← field entry "key")
      let values ← entries.mapM fun entry => field entry "value"
      let input ← term map info true binder
      let getMapKeys := mkIdent ``Lynx.Term.getMapKeys
      let lookup := withSpan info.info (Unhygienic.run `($getMapKeys [$keys,*] $input))
      let (values, nested) ← withExtractions (values.mapM (term map info true))
      addExtraction lookup (Unhygienic.run `([$values,*])) false nested
      return input
    let entries ← (← arr j "entries").mapM fun entry => do
      fields entry ["key", "value", "span"]
      let ei ← span map entry info
      let key ← term map ei false (← field entry "key")
      let value ← term map ei false (← field entry "value")
      pure (withSpan ei.info (Unhygienic.run `(($key, $value))))
    -- Core entries are in construction order; Term.map lookup takes the first binding.
    let entries := entries.reverse
    let ctor := mkIdent ``Lynx.Term.map
    pure (Unhygienic.run `($ctor [$entries,*]))
  | "local_call" | "remote_call" => do
    fields j (if kind == "local_call" then ["kind", "name", "args", "span"]
      else ["kind", "module", "name", "args", "purity", "dispatches", "span"])
    let args ← (← arr j "args").mapM (term map info false)
    let name := functionName (← str j "name") args.size
    let fn ← if kind == "local_call" then pure name else do
      let namespaceId ← identifier (← str j "module")
      pure (mkIdent (namespaceId.getId ++ name.getId))
    -- Callees returning `Except` are embedded by other computations. Callees
    -- that are not pure receive the caller's dispatcher first.
    let level ← if kind == "local_call" then
        let key := s!"{← str j "name"}/{args.size}"
        match (← get).purities[key]? with
        | some level => pure level
        | none => throw s!"unknown local function {key}"
      else level j "purity" "dispatches"
    if (← get).pureContext && !returnsExcept level then
      throw s!"computations returning Except cannot call {level} functions"
    let args ← if level == "pure" then pure args
      else pure (#[← requireDispatcher s!"call {level} functions"] ++ args)
    let call := if args.isEmpty then ⟨fn.raw⟩ else Unhygienic.run `($fn $args*)
    if returnsExcept level then embedPure call else pure call
  | "fun_call" => do
    fields j ["kind", "function", "args", "span"]
    let fn ← term map info false (← field j "function")
    let args ← (← arr j "args").mapM (term map info false)
    let dispatcher ← requireDispatcher "call function values"
    let apply := mkIdent (if (← get).pureContext then ``Lynx.Dispatcher.pure else ``Lynx.Dispatcher.call)
    pure (Unhygienic.run `($apply $dispatcher $fn #[$args,*]))
  | "label" => do
    fields j ["kind", "label", "continuation", "body", "span"]
    let label := mkIdent (Name.mkSimple s!"lynxLabel_{← str j "label"}")
    let continuation ← term map info false (← field j "continuation")
    let body ← term map info false (← field j "body")
    -- Use the same applied-lambda form as match fallthrough continuations.
    withContinuation label body continuation
  | "jump" => do
    fields j ["kind", "label", "span"]
    let label := mkIdent (Name.mkSimple s!"lynxLabel_{← str j "label"}")
    pure (Unhygienic.run `($label ()))
  | "bind" => do
    fields j ["kind", "vars", "computation", "body", "span"]
    let vars ← (← arr j "vars").mapM fun binder => do
      if (← str binder "kind") == "wildcard" then term map info true binder
      else pure (⟨(← param map info binder).raw⟩ : TSyntax `term)
    let var ← product vars
    let computation := doTerm (← term map info false (← field j "computation"))
    let body ← term map info false (← field j "body")
    -- Identifier binds retain the return witnesses introduced by wf preprocessing.
    let item ← if var.raw.isIdent then do
      let id : TSyntax `ident := ⟨var.raw⟩
      pure (withSpan info.info (Unhygienic.run `(doSeqItem| let $id:ident ← $computation:term)))
    else pure (withSpan info.info (Unhygienic.run `(doSeqItem| let $var:term ← $computation:term)))
    -- Consecutive Core binds share one block; preserve locations on each statement.
    match body with
    | `(do $items:doSeqItem*) => pure (Unhygienic.run `(do $item:doSeqItem $items:doSeqItem*))
    | _ =>
      let last := Unhygienic.run `(doSeqItem| $(doTerm body):term)
      pure (Unhygienic.run `(do $item:doSeqItem $last:doSeqItem))
  | "return" => do
    fields j ["kind", "values", "span"]
    let values ← (← arr j "values").mapM (term map info false)
    let value ← product values
    -- `pure` remains local to this computation, including inside a bind's RHS.
    let pureId := mkIdent `pure
    pure (Unhygienic.run `($pureId $value))
  | "raise" => do
    fields j ["kind", "class", "reason", "span"]
    let ctor ← match ← str j "class" with
      | "error" => pure (mkIdent ``Lynx.Exception.error)
      | "throw" => pure (mkIdent ``Lynx.Exception.throw)
      | "exit" => pure (mkIdent ``Lynx.Exception.exit)
      | other => throw s!"unsupported exception class '{other}'"
    let reason ← term map info false (← field j "reason")
    let error ← contextual ``Except.error ``Lynx.Result.error
    pure (Unhygienic.run `($error ($ctor $reason)))
  | "in" => do
    fields j ["kind", "value", "elements", "span"]
    let value ← term map info false (← field j "value")
    let elements ← (← arr j "elements").mapM (term map info false)
    let member := mkIdent ``Lynx.Term.isMember
    let ok ← contextual ``Except.ok ``Lynx.Result.ok
    pure (Unhygienic.run `($ok ($member $value [$elements,*])))
  | "orelse" | "andalso" => do
    fields j ["kind", "left", "right", "badbool", "span"]
    let left ← term map info false (← field j "left")
    let right ← term map info false (← field j "right")
    let combinator ← if kind == "orelse" then contextual ``Lynx.Except.orElse ``Lynx.Result.orElse
      else contextual ``Lynx.Except.andAlso ``Lynx.Result.andAlso
    -- Elixir's strict operators raise badbool instead of badarg.
    match (j.getObjValAs? Bool "badbool").toOption with
    | some true => pure (Unhygienic.run `($combinator $left $right true))
    | _ => pure (Unhygienic.run `($combinator $left $right))
  | "nonzero_width" => do
    fields j ["kind", "size", "body", "span"]
    let size ← term map info false (← field j "size")
    let body ← term map info false (← field j "body")
    let zero := mkIdent ``Lynx.Term.Bitstring.zeroWidth
    -- The named check lets termination proofs use the nonzero width.
    let nonzero := mkIdent `lynxNonzero
    let error ← contextual ``Except.error ``Lynx.Result.error
    pure (Unhygienic.run `(if $nonzero:ident : $zero $size = Bool.true then
      $error (Lynx.Exception.error (Lynx.Term.atom "badarg")) else $body))
  | "try" => do
    fields j ["kind", "computation", "vars", "body", "exception_vars", "handler", "span"]
    let vars ← (← arr j "vars").mapM (param map info)
    let binder ← product (vars.map fun v => ⟨v.raw⟩)
    let evars ← (← arr j "exception_vars").mapM (param map info)
    unless evars.size == 2 || evars.size == 3 do
      throw "try requires class/reason and an optional raw exception variable"
    let computation ← term map info false (← field j "computation")
    let body ← term map info false (← field j "body")
    let handler ← term map info false (← field j "handler")
    let exception := if evars.size == 3 then evars[2]! else mkIdent `lynxException
    let classVar := evars[0]!
    let reasonVar := evars[1]!
    let exceptionClass := mkIdent ``Lynx.Exception.classTerm
    let reason := mkIdent ``Lynx.Exception.reason
    let tryWith ← contextual ``Lynx.Except.tryWith ``Lynx.Result.tryWith
    -- `have` keeps the class and reason out of the local context as `let`
    -- values, so `partial_fixpoint` can split handler matches on them.
    pure (Unhygienic.run `($tryWith $computation (fun $binder:term => $body)
      (fun $exception:ident =>
        have $classVar := $exceptionClass $exception:ident
        have $reasonVar := $reason $exception:ident
        $handler)))
  | "stacktrace" => do
    fields j ["kind", "exception", "span"]
    let exception ← term map info false (← field j "exception")
    let stacktrace := mkIdent ``Lynx.Exception.stacktrace
    let ok ← contextual ``Except.ok ``Lynx.Result.ok
    pure (Unhygienic.run `($ok ($stacktrace $exception)))
  | "reraise" => do
    fields j ["kind", "exception", "reason", "span"]
    let exception ← term map info false (← field j "exception")
    let reason ← term map info false (← field j "reason")
    let withReason := mkIdent ``Lynx.Exception.withReason
    let error ← contextual ``Except.error ``Lynx.Result.error
    pure (Unhygienic.run `($error ($withReason $exception $reason)))
  | "raise_dynamic" => do
    fields j ["kind", "class", "reason", "exception", "span"]
    let exceptionClass ← term map info false (← field j "class")
    let reason ← term map info false (← field j "reason")
    let exception ← term map info false (← field j "exception")
    let classJson ← field j "class"
    if (← str classJson "kind") == "atom" then
      let ctor? := match ← str classJson "value" with
        | "error" => some (mkIdent ``Lynx.Exception.error)
        | "throw" => some (mkIdent ``Lynx.Exception.throw)
        | "exit" => some (mkIdent ``Lynx.Exception.exit)
        | _ => none
      if let some ctor := ctor? then
        let error ← contextual ``Except.error ``Lynx.Result.error
        return withSpan info.info (Unhygienic.run `($error ($ctor $reason)))
    let error ← contextual ``Except.error ``Lynx.Result.error
    let ok ← contextual ``Except.ok ``Lynx.Result.ok
    let atom := mkIdent ``Lynx.Term.atom
    let errorClass := mkIdent ``Lynx.Exception.error
    let throwClass := mkIdent ``Lynx.Exception.throw
    let exitClass := mkIdent ``Lynx.Exception.exit
    pure (Unhygienic.run `(
      let _ := $exception;
      match ($exceptionClass) with
      | $atom "error" => $error ($errorClass $reason)
      | $atom "throw" => $error ($throwClass $reason)
      | $atom "exit" => $error ($exitClass $reason)
      | _ => $ok ($atom "badarg")))
  | "receive" => do
    fields j ["kind", "message", "cases", "timeout", "after", "span"]
    -- Receives run one call depth down, so recursion through them terminates.
    let outer ← requireDispatcher "receive messages"
    modify fun s => { s with dispatcher := some ⟨dispatcherId.raw⟩ }
    let message ← param map info (← field j "message")
    let clauses ← (← arr j "cases").mapM (fun c => refineGuardClause c #[] true)
    let termType : TSyntax `term := ⟨(mkIdent ``Lynx.Term).raw⟩
    let unitType : TSyntax `term := ⟨(mkIdent ``Unit).raw⟩
    let unit : TSyntax `term := Unhygienic.run `(())
    let option := mkIdent ``Option
    let someId := mkIdent ``Option.some
    let noneId := mkIdent ``Option.none
    let exceptOk := mkIdent ``Except.ok
    let atomId := mkIdent ``Lynx.Term.atom
    let mut payloadTypes : Array (TSyntax `term) := #[]
    let mut payloads : Array (TSyntax `term) := #[]
    let mut patterns : Array (TSyntax `term) := #[]
    let mut lookups : Array (Array PatternExtraction) := #[]
    let mut guards : Array (TSyntax `term) := #[]
    let mut bodies : Array (TSyntax `term) := #[]
    for clause in clauses do
      fields clause ["span", "pattern", "vars", "guard", "body"]
      let ci ← span map clause info
      let vars ← (← arr clause "vars").mapM (param map ci)
      let mut payload := unit
      let mut payloadType := unitType
      for v in vars.reverse do
        let value : TSyntax `term := ⟨v.raw⟩
        if payloadType.raw == unitType.raw then
          payload := value
          payloadType := termType
        else
          payload := Unhygienic.run `(($value, $payload))
          payloadType := Unhygienic.run `($termType × $payloadType)
      payloadTypes := payloadTypes.push payloadType
      payloads := payloads.push payload
      let (pat, maps) ← withExtractions (term map ci true (← field clause "pattern"))
      patterns := patterns.push pat
      lookups := lookups.push maps
      guards := guards.push (← term map ci false (← field clause "guard"))
      bodies := bodies.push (← term map ci false (← field clause "body"))
    let sum := mkIdent ``Sum
    let inl := mkIdent ``Sum.inl
    let inr := mkIdent ``Sum.inr
    let emptyType : TSyntax `term := ⟨(mkIdent ``Empty).raw⟩
    let mut bindingType := if clauses.isEmpty then emptyType else payloadTypes.back!
    for t in payloadTypes.toList.dropLast.reverse do
      bindingType := Unhygienic.run `($sum $t $bindingType)
    let mut select : TSyntax `term := Unhygienic.run `($noneId)
    let mut alternatives : Array (TSyntax ``Lean.Parser.Term.matchAlt) := #[]
    let toExcept := mkIdent ``Lynx.Result.toExceptRead
    let env := mkIdent `_lynxReceiveEnv
    let envType : TSyntax `term := ⟨(mkIdent ``Lynx.Environment).raw⟩
    let purity : TSyntax `term := ⟨← Parser.runParserCategory (← read) `term
      "by simp (config := { maxDischargeDepth := 64 })"⟩
    for i in [:clauses.size] do
      let mut payload := payloads[i]!
      if i + 1 < clauses.size then payload := Unhygienic.run `($inl $payload)
      for _ in [:i] do payload := Unhygienic.run `($inr $payload)
      let body := bodies[i]!
      alternatives := alternatives.push (Unhygienic.run `(Lean.Parser.Term.matchAltExpr| | $payload => $body))
    let fallback := mkIdent `lynxReceiveNext
    for i in (List.range clauses.size).reverse do
      let mut payload := payloads[i]!
      if i + 1 < clauses.size then payload := Unhygienic.run `($inl $payload)
      for _ in [:i] do payload := Unhygienic.run `($inr $payload)
      let pat := patterns[i]!
      let guard := guards[i]!
      let accepted : TSyntax `term := Unhygienic.run `($someId $payload)
      let guardJson ← field clauses[i]! "guard"
      let unconditional := (← str guardJson "kind") == "return" &&
        (match (arr guardJson "values" >>= fun values => do
            unless values.size == 1 do throw "guard must return one value"
            str values[0]! "value") with
          | .ok "true" => true
          | _ => false)
      let branch ← if unconditional then pure accepted else pure (Unhygienic.run `(
        match ($toExcept $guard $env:ident $purity) with
        | $exceptOk ($atomId "true") => $accepted
        | _ => $fallback ()))
      let branch := patternMatches lookups[i]! branch (Unhygienic.run `($fallback ()))
      let rest := select
      let catchAll ← catchAllPattern (← field clauses[i]! "pattern")
      let matched := if catchAll then Unhygienic.run `(match $message:ident with | $pat => $branch)
        else Unhygienic.run `(match $message:ident with | $pat => $branch | _ => $fallback ())
      select := if catchAll && unconditional && lookups[i]!.isEmpty then matched else Unhygienic.run `(
        let $fallback := fun (_ : $unitType) => ($rest : $option $bindingType)
        $matched)
    let selector := if clauses.isEmpty then Unhygienic.run `(fun (_ : $envType) (_ : $termType) => ($noneId : $option $bindingType))
      else Unhygienic.run `(fun ($env:ident : $envType) ($message:ident : $termType) => ($select : $option $bindingType))
    let selected := mkIdent `lynxReceived
    let continuation ← if clauses.isEmpty then pure (Unhygienic.run `(nomatch $selected:ident))
      else pure (Unhygienic.run `(match $selected:ident with $alternatives:matchAlt*))
    let timeout ← term map info false (← field j "timeout")
    let afterBody ← term map info false (← field j "after")
    let receive := mkIdent ``Lynx.Result.receiveWith
    let computation := Unhygienic.run `($receive $timeout $selector (fun
      | $someId $selected:ident => $continuation
      | $noneId => $afterBody))
    modify fun s => { s with dispatcher := some outer }
    let dispatcherMk := mkIdent ``Lynx.Dispatcher.mk
    let error := mkIdent ``Lynx.Result.error
    let exhausted := mkIdent ``Lynx.Exception.exhausted
    pure (Unhygienic.run `(match $outer:term with
      | $dispatcherMk _ _ _ ($someId $dispatcherId:ident) => $computation
      | _ => $error $exhausted))
  | "match" => do
    fields j ["kind", "expressions", "cases", "span"]
    if let some grouped ← groupMapCases j then return ← term map info false grouped
    let exprJson ← arr j "expressions"
    let exprs ← exprJson.mapM (term map info false)
    let unit : TSyntax `term := ⟨(mkIdent ``Unit.unit).raw⟩
    let clauses ← (← arr j "cases").mapM (fun c => refineGuardClause c exprJson)
    -- Bitstring patterns on variables extract from them directly. Their positions
    -- are dropped from the match: Lean cannot derive functional induction when
    -- a match only rebinds several of a recursive function's parameters.
    let direct (pattern : Json) (i : Nat) : Bool :=
      (str pattern "kind").toOption == some "bitstring_pattern" &&
        (exprJson[i]? >>= fun e => (str e "kind").toOption) == some "var"
    let clauses ← clauses.mapM fun c => do
      let patterns ← arr c "patterns"
      pure (c.setObjVal! "patterns" (toJson (patterns.mapIdx fun i pattern =>
        if direct pattern i then pattern.setObjVal! "input" exprJson[i]! else pattern)))
    let mut nests : Array Bool := #[]
    let mut lookups : Array (Array PatternExtraction) := #[]
    let mut cases : Array (TSyntax ``Lean.Parser.Term.matchAlt) := #[]
    for c in clauses do
      fields c (if (field c "guard").isOk then ["patterns", "guard", "body", "span"]
        else ["patterns", "body", "span"])
      let ci ← span map c info
      let (pats, maps) ← withExtractions ((← arr c "patterns").mapM (term map ci true))
      lookups := lookups.push maps
      unless pats.size == exprs.size do throw "match case must have one pattern per expression"
      let pats := if pats.isEmpty then #[unit] else pats
      let body ← term map ci false (← field c "body")
      nests := nests.push ((field c "guard").isOk || !maps.isEmpty)
      cases := cases.push (withSpan ci.info
        (Unhygienic.run `(Lean.Parser.Term.matchAltExpr| | $pats,* => $body)))
    if cases.isEmpty then throw "match requires at least one case"
    -- Core can omit the fallback when it knows an operation returns a Boolean.
    -- Term's type includes other values, so Lean still needs an exhaustive match.
    let catchAll ← clauses.anyM fun c => do
      if (field c "guard").isOk then return false
      (← arr c "patterns").allM fun p => do
        pure ((← str p "kind") ∈ ["var", "wildcard"])
    unless catchAll do
      -- Source variables always start with `v` or `_`, keeping these binders distinct.
      let unmatched : Array (TSyntax `term) := exprs.mapIdx fun i _ =>
        ⟨(mkIdent (Name.mkSimple s!"lynxUnmatched{i}")).raw⟩
      let tuple := mkIdent ``Lynx.Term.tuple
      let value ← if unmatched.size == 1 then pure unmatched[0]!
        else pure (Unhygienic.run `($tuple #[$unmatched,*]))
      let error ← contextual ``Except.error ``Lynx.Result.error
      let exception := mkIdent ``Lynx.Exception.error
      let atom := mkIdent ``Lynx.Term.atom
      let body := Unhygienic.run `($error ($exception ($tuple #[$atom "case_clause", $value])))
      cases := cases.push (Unhygienic.run `(Lean.Parser.Term.matchAltExpr| | $unmatched,* => $body))
    let exprs := if exprs.isEmpty then #[unit] else exprs
    -- Fallthrough alternatives rebind variable discriminants to their own names.
    -- Lean generalizes a matched parameter, and the remaining clauses refer to
    -- it again; with a wildcard, termination goals would lose that they are equal.
    let wildcards : Array (TSyntax `term) := exprs.mapIdx fun i expr =>
      if (exprJson[i]? >>= fun e => (str e "kind").toOption) == some "var" then expr
      else Unhygienic.run `(_)
    if nests.contains true then
      let fallback := mkIdent `lynxMatchNext
      let guardCall ← contextual ``Lynx.Except.guard ``Lynx.Result.guard
      let error ← contextual ``Except.error ``Lynx.Result.error
      let mut result := Unhygienic.run `($error
        (Lynx.Exception.error (Lynx.Term.atom "function_clause")))
      let mut stop := cases.size
      while stop > 0 do
        let i := stop - 1
        if nests[i]?.getD false then
          let c := clauses[i]!
          let ci ← span map c info
          match cases[i]! with
          | `(Lean.Parser.Term.matchAltExpr| | $pats,* => $body) =>
            let branch ← if (field c "guard").isOk then do
              let guard ← term map ci false (← field c "guard")
              pure (Unhygienic.run `($guardCall $guard (fun _ => $body) $fallback))
              else pure body
            let branch := patternMatches lookups[i]! branch (Unhygienic.run `($fallback ()))
            let patterns ← arr c "patterns"
            let keep := (List.range pats.getElems.size).toArray.filter fun k =>
              !(patterns[k]?.map (direct · k)).getD false
            let kept := keep.map (pats.getElems[·]!)
            let keptExprs := keep.map (exprs[·]!)
            let keptWildcards := keep.map (wildcards[·]!)
            let catchAll ← keep.allM fun k => do
              match patterns[k]? with
              | some pattern => catchAllPattern pattern
              | none => pure true
            let matched := if keep.isEmpty then branch
              else if catchAll then Unhygienic.run `(
                match $[$keptExprs:term],* with | $[$kept:term],* => $branch)
              else Unhygienic.run `(match $[$keptExprs:term],* with
                | $[$kept:term],* => $branch | $[$keptWildcards:term],* => $fallback ())
            -- An applied lambda shares the continuation without leaving a recursive
            -- let-bound thunk in Lean's generated induction principle.
            result ← withContinuation fallback matched result
          | _ => throw "invalid match alternative"
          stop := i
        else
          -- Keep consecutive unconditional clauses in one ordinary match, including
          -- recursive suffixes. Guards and map patterns introduce fallback thunks.
          let mut start := i
          while start > 0 && !(nests[start - 1]?.getD false) do
            start := start - 1
          let mut group := cases.extract start stop
          let catchAll ← (clauses.extract start (min stop clauses.size)).anyM fun c => do
            (← arr c "patterns").allM fun p => do
              pure ((← str p "kind") ∈ ["var", "wildcard"])
          unless catchAll || stop > clauses.size do
            group := group.push (Unhygienic.run `(Lean.Parser.Term.matchAltExpr|
              | $wildcards,* => $result))
          result := Unhygienic.run `(match $[$exprs:term],* with $group:matchAlt*)
          stop := start
      return withSpan info.info result
    pure (Unhygienic.run `(match $[$exprs:term],* with $cases:matchAlt*))
  | _ => throw s!"unsupported {if pattern then "pattern" else "term"} kind '{kind}'"
  return withSpan info.info result

private def proofPosition (proofMap : FileMap) (start : Position) (indentation : Nat)
    (pos : String.Pos.Raw) : Position :=
  let p := proofMap.toPosition pos
  if p.line < 2 then start
  else ⟨start.line + p.line - 2, p.column + if p.line == 2 then start.column else indentation⟩

/-- Parsed proof nodes retain their individual ranges in the original file map,
including Unicode columns, relative to the supplied proof origin. -/
private partial def locateProof (map proofMap : FileMap) (start : Position)
    (indentation : Nat) (anchor : Span) (stx : Syntax) : DecodeM Syntax := do
  let pos? := stx.getPos?
  let stop? := stx.getTailPos?
  let mut stx := stx
  if let .node info kind args := stx then
    stx := .node info kind (← args.mapM (locateProof map proofMap start indentation anchor))
  let some pos := pos? | return stx
  let stop := stop?.getD pos
  let location := match anchor.location with
    | .unknown => Location.unknown
    | .line _ => .line (proofPosition proofMap start indentation pos).line
    | .column _ => .column (proofPosition proofMap start indentation pos)
  let info := SourceInfo.synthetic
    (map.ofPosition (proofPosition proofMap start indentation pos))
    (map.ofPosition (proofPosition proofMap start indentation stop)) true
  modify fun s => { s with spans := s.spans.push ⟨info, location, anchor.fileName⟩ }
  return stx.setInfo info

private def leanProof (map : FileMap) (parent : Span) (name : Name) (j : Json) : DecodeM (TSyntax `term × Span) := do
  fields j ["source", "indentation", "span"]
  let info ← span map j parent
  let indentation ← (← field j "indentation").getNat?
  let input := "by\n" ++ (← str j "source")
  let ctx := Parser.mkInputContext input "<proof>" (normalizeLineEndings := false)
  let parser := Parser.andthenFn Parser.whitespace (Parser.categoryParserFnImpl `term)
  let env ← read
  let parsed := parser.run ctx { env, options := {} } (Parser.getTokenTable env) (Parser.mkParserState input)
  let parsed := if parsed.allErrors.isEmpty && !ctx.atEnd parsed.pos then
    parsed.mkError "end of input" else parsed
  let start := match info.location with
    | .column p => p
    | .line line => ⟨line, 0⟩
    | .unknown => ⟨1, 0⟩
  for (pos, _, error) in parsed.allErrors do
    let p := proofPosition ctx.fileMap start indentation pos
    let location := match info.location with
      | .unknown => Location.unknown
      | .line _ => .line p.line
      | .column _ => .column p
    modify fun s => { s with diagnostics := s.diagnostics.push ⟨name, toString error, location, none⟩ }
  if !parsed.allErrors.isEmpty then return (⟨.missing⟩, info)
  return (⟨← locateProof map ctx.fileMap start indentation info parsed.stxStack.back⟩, info)

/-- Parse a termination suffix and retain the source location of every syntax node. -/
private def leanSuffix (map : FileMap) (parent : Span) (name : Name) (j : Json) : DecodeM Syntax := do
  fields j ["source", "file", "indentation", "span"]
  let info := { (← span map j parent) with fileName := some (← str j "file") }
  let indentation ← (← field j "indentation").getNat?
  let source ← str j "source"
  if source.trimAscii.toString.isEmpty then throw "termination suffix cannot be empty"
  let input := "\n" ++ source
  let ctx := Parser.mkInputContext input "<termination suffix>" (normalizeLineEndings := false)
  let parser := Parser.andthenFn Parser.whitespace Parser.Termination.suffix.fn
  let env ← read
  let parsed := parser.run ctx { env, options := {} } (Parser.getTokenTable env) (Parser.mkParserState input)
  let parsed := if parsed.allErrors.isEmpty && !ctx.atEnd parsed.pos then
    parsed.mkError "end of input" else parsed
  let start := match info.location with
    | .column p => p
    | .line line => ⟨line, 0⟩
    | .unknown => ⟨1, 0⟩
  for (pos, _, error) in parsed.allErrors do
    let p := proofPosition ctx.fileMap start indentation pos
    let location := match info.location with
      | .unknown => Location.unknown
      | .line _ => .line p.line
      | .column _ => .column p
    modify fun s => { s with diagnostics := s.diagnostics.push ⟨name, toString error, location, info.fileName⟩ }
  if !parsed.allErrors.isEmpty then return .missing
  return ← locateProof map ctx.fileMap start indentation info parsed.stxStack.back

private structure TableEntry where
  captures : Array (TSyntax `ident)
  arguments : Array (TSyntax `ident)
  body : TSyntax `term
  adapter : TSyntax `term
  level : String
  /-- The module and name the compiler gave the function. -/
  module : String
  name : String

/-- Decode a table entry. Entries that are not pure receive their dispatcher as
the adapter's first parameter; `dispatcher` instead substitutes a given one into
the body, for stating its application equations. -/
private def tableEntry (map : FileMap) (info : Span) (entry : Json)
    (dispatcher : TSyntax `term := ⟨dispatcherId.raw⟩) : DecodeM TableEntry := do
  fields entry ["module", "name", "body", "captures", "args", "purity", "dispatches", "span"]
  let entryInfo ← span map entry info
  let captureIds ← (← arr entry "captures").mapM (param map entryInfo)
  let argumentIds ← (← arr entry "args").mapM (param map entryInfo)
  let captures := captureIds.map fun id => (⟨id.raw⟩ : TSyntax `term)
  let arguments := argumentIds.map fun id => (⟨id.raw⟩ : TSyntax `term)
  let level ← level entry "purity" "dispatches"
  let body ← withPurity level (dispatcher := dispatcher) <|
    term map entryInfo false (← field entry "body")
  let error := mkIdent (if returnsExcept level then ``Except.error else ``Lynx.Result.error)
  let exceptionError := mkIdent ``Lynx.Exception.error
  let atom := mkIdent ``Lynx.Term.atom
  let capturesId := mkIdent `captures
  let argsId := mkIdent `args
  -- List patterns, unlike array literal patterns, give matches equation lemmas
  -- that evaluation and simp can use.
  let adapter := Unhygienic.run `(fun $capturesId:ident $argsId:ident =>
      match ($capturesId:ident).toList, ($argsId:ident).toList with
      | [$captures,*], [$arguments,*] => $body
      | _, _ => $error ($exceptionError ($atom "badarg")))
  let adapter := if level == "pure" then adapter
    else Unhygienic.run `(fun $dispatcherId:ident => $adapter)
  return { captures := captureIds, arguments := argumentIds, body
           adapter := withSpan entryInfo.info adapter, level,
           module := ← str entry "module", name := ← str entry "name" }

private partial def command (map : FileMap) (j : Json) (parent : Span := {}) :
    DecodeM (TSyntax `command) := do
  let info ← span map j parent
  let kind ← str j "kind"
  let result ← match kind with
  | "fun_table" => do
    fields j ["kind", "name", "entries", "span"]
    let name ← identifier (← str j "name")
    unless name.getId.getPrefix == .anonymous do throw "table name must be unqualified"
    let funDef := mkIdent ``Lynx.Term.FunDef.mk
    let entries ← (← arr j "entries").mapM fun entry => do
      let entry ← tableEntry map info entry
      let ctor := mkIdent (match entry.level with
        | "pure" => ``Lynx.Term.FunEntry.pure
        | "apply" => ``Lynx.Term.FunEntry.apply
        | _ => ``Lynx.Term.FunEntry.effectful)
      let module := Syntax.mkStrLit entry.module
      let name := Syntax.mkStrLit entry.name
      let arity := Syntax.mkNumLit (toString entry.arguments.size)
      pure (Unhygienic.run `($funDef $module $name $arity ($ctor $(entry.adapter))))
    let body := Unhygienic.run `([$entries,*])
    let tableType := mkIdent ``Lynx.Term.FunTable
    pure (Unhygienic.run `(def $name : $tableType := $body))
  | "mutual" => do
    fields j ["kind", "defs", "purity", "dispatches", "span"]
    let defs ← arr j "defs"
    if defs.isEmpty then throw "mutual requires at least one definition"
    let decls ← defs.mapM fun decl => do
      unless (← str decl "kind") == "def" do throw "mutual requires def declarations"
      unless (← level decl "purity" "dispatches") == (← level j "purity" "dispatches") do
        throw "mutual definitions must agree with the group purity"
      command map decl info
    pure (Unhygienic.run `(mutual $decls:command* end))
  | "theorem" => do
    fields j ["kind", "name", "params", "requires", "ensures", "proof", "span",
      "table", "requires_purity", "requires_dispatches", "ensures_purity",
      "ensures_dispatches"]
    let params ← (← arr j "params").mapM fun p => do
      pure (mkIdent (Name.mkSimple (← p.getStr?)))
    let arity := params.size
    let args := params.map fun p => (⟨p.raw⟩ : TSyntax `term)
    let name := functionName (← str j "name") arity
    let termType := mkIdent ``Lynx.Term
    let binders := params.map fun p => Unhygienic.run `(bracketedBinder| ($p : $termType))
    let table ← match field j "table" with
      | .error _ => pure (Unhygienic.run `([]))
      | .ok value => pure (⟨(← identifier (← value.getStr?)).raw⟩ : TSyntax `term)
    -- Helpers that are not pure call function values through the program table,
    -- up to a depth bound the statement quantifies. Its names avoid the parameters.
    let fresh (base : String) : Ident := Id.run do
      let mut name := base
      while params.any (·.getId == Name.mkSimple name) do name := name ++ "'"
      return mkIdent (Name.mkSimple name)
    let depth := fresh "depth"
    let bound := fresh "bound"
    let apply := mkIdent ``Lynx.apply
    let helper (callee : Ident) (level : String) : TSyntax `term :=
      if level == "pure" then Unhygienic.run `($callee $args*)
      else Unhygienic.run `($apply $callee $table $depth $args*)
    let requirement ← match field j "requires" with
      | .error _ => pure none
      | .ok value => do
        let level ← level j "requires_purity" "requires_dispatches"
        pure (some (helper (functionName (← value.getStr?) arity) level, level))
    let ensuresPurity ← level j "ensures_purity" "ensures_dispatches"
    let ensures := helper (functionName (← str j "ensures") arity) ensuresPurity
    let (proof, proofInfo) ← leanProof map info name.getId (← field j "proof")
    let source ← str (← field j "proof") "source"
    modify fun s => { s with
      theorems := s.theorems.push (name.getId, proofInfo)
      proofSources := s.proofSources.push (name.getId, source) }
    let ok := mkIdent ``Lynx.Outcome.ok
    let run := mkIdent ``Lynx.sequential
    let everyRun := mkIdent ``Lynx.concurrent
    let trueTerm := mkIdent ``Lynx.Term.true
    let hypothesis := mkIdent `requires
    -- Each helper is stated as strongly as its purity allows: directly when it
    -- returns `Except`, through `Lynx.sequential` when it needs an environment,
    -- and through `Lynx.concurrent`, over every run, when it is concurrent.
    let exceptOk := mkIdent ``Except.ok
    let natType := mkIdent ``Nat
    -- Helpers that are not pure return `true` from some depth on, so a law holds
    -- for every input however deep its calls go. Each helper has its own bound.
    let eventually (level : String) (statement : TSyntax `term) : TSyntax `term :=
      if level == "pure" then statement
      else Unhygienic.run `(∃ $bound:ident : $natType, ∀ $depth:ident : $natType,
        $bound ≤ $depth → $statement)
    let direct (computation : TSyntax `term) : TSyntax `term :=
      Unhygienic.run `($computation = $exceptOk $trueTerm)
    let runs (computation : TSyntax `term) : TSyntax `term :=
      Unhygienic.run `($run $computation = $ok $trueTerm)
    let everyRunEnds (computation : TSyntax `term) : TSyntax `term :=
      Unhygienic.run `($everyRun $computation ($ok $trueTerm))
    -- A precondition is assumed directly only when it makes no runtime requests:
    -- it then returns `Except`, so the statement is equivalent to running it.
    let binders := match requirement with
      | none => binders
      | some (requires, level) =>
        let statement := match level with
          | "concurrent" => eventually level (everyRunEnds requires)
          | "sequential" => eventually level (runs requires)
          | _ => eventually level (direct requires)
        binders.push (Unhygienic.run `(bracketedBinder| ($hypothesis : $statement)))
    -- A direct expectation implies it holds when run, in every run.
    let goal := match ensuresPurity with
      | "pure" | "apply" => eventually ensuresPurity (direct ensures)
      | "concurrent" => eventually ensuresPurity (everyRunEnds ensures)
      | _ => eventually ensuresPurity (runs ensures)
    pure (Unhygienic.run `(theorem $name $binders:bracketedBinder* : $goal := $proof))
  | "def" => do
    fields j ["kind", "name", "params", "body", "purity", "dispatches", "span",
      "termination_suffix", "measure"]
    let params ← (← arr j "params").mapM (param map info)
    let name := functionName (← str j "name") params.size
    let termType := mkIdent ``Lynx.Term
    let level ← level j "purity" "dispatches"
    let resultType ← withPurity level (resultTypeOf termType)
    let binders := params.map fun p => Unhygienic.run `(bracketedBinder| ($p : $termType))
    -- The dispatcher comes first, so recursion treats it as a fixed parameter.
    let dispatcherType := mkIdent ``Lynx.Dispatcher
    let binders := if level == "pure" then binders
      else #[Unhygienic.run `(bracketedBinder| ($dispatcherId : $dispatcherType))] ++ binders
    let body ← withPurity level <| term map info false (← field j "body")
    let declaration := Unhygienic.run `(def $name $binders:bracketedBinder* : $resultType := $body)
    -- A simple definition has a declValSimple containing :=, body, suffix, and where.
    let attach (suffix : Syntax) : TSyntax `command :=
      let definition := declaration.raw[1]
      let value := definition[3].setArg 2 suffix
      ⟨declaration.raw.setArg 1 (definition.setArg 3 value)⟩
    match field j "termination_suffix", field j "measure" with
    | .ok annotation, _ =>
      pure (attach (← leanSuffix map info name.getId annotation))
    | .error _, .ok coordinates =>
      -- Lexicographic coordinates are constants or a parameter's size plus an offset.
      let coordinates ← (← coordinates.getArr?).mapM fun coordinate => do
        if let .ok value := field coordinate "const" then
          fields coordinate ["const"]
          pure (⟨Syntax.mkNumLit (toString (← value.getNat?))⟩ : TSyntax `term)
        else
          fields coordinate ["param", "offset"]
          let index ← (← field coordinate "param").getNat?
          let offset ← (← field coordinate "offset").getNat?
          let some p := params[index]? | throw "measure parameter is out of range"
          let size := Unhygienic.run `(sizeOf $p)
          if offset == 0 then pure size
          else pure (Unhygienic.run `($(Syntax.mkNumLit (toString offset)) + $size))
      if coordinates.isEmpty then throw "measure must have at least one coordinate"
      let measure ← product coordinates
      pure (attach (Unhygienic.run `(Parser.Termination.suffix| termination_by $measure)))
    | .error _, .error _ => pure declaration
  | _ => throw s!"unsupported command kind '{kind}'"
  return withSpan info.info result

/-- Table metadata also gives kernel-checked application equations for every
entry, so proofs can simplify dynamic calls through the program's dispatcher
without inspecting the table or duplicating callback implementations. Pure
entries preserve the call depth; others run with one level less. -/
private def commands (map : FileMap) (j : Json) : DecodeM (Array (TSyntax `command)) := do
  let errors := (← get).diagnostics.size
  let declaration ← command map j
  if (← get).diagnostics.size != errors then return #[]
  let literals := (← get).pendingLiterals
  modify fun s => { s with pendingLiterals := #[] }
  if (← str j "kind") != "fun_table" then return literals.push declaration
  let info ← span map j
  let table ← identifier (← str j "name")
  let entries ← arr j "entries"
  let mut result := literals.push declaration
  let termType := mkIdent ``Lynx.Term
  let natType := mkIdent ``Nat
  let ofTable := mkIdent ``Lynx.Dispatcher.ofTable
  let pureCall := mkIdent ``Lynx.Dispatcher.pure
  let effectfulCall := mkIdent ``Lynx.Dispatcher.call
  let function := mkIdent ``Lynx.Term.function
  let ofExcept := mkIdent ``Lynx.Result.ofExcept
  let depth := mkIdent `depth
  -- Implicit arguments are named, so the lookup proofs elaborate against them.
  let tableArg := mkIdent `table
  let moduleArg := mkIdent `module
  let nameArg := mkIdent `name
  let arityArg := mkIdent `arity
  let capturesArg := mkIdent `captures
  let argumentsArg := mkIdent `arguments
  for index in [:entries.size] do
    let level ← level entries[index]! "purity" "dispatches"
    -- Entries that dispatch further run with the dispatcher one level down.
    let outer : TSyntax `term := if level == "pure" then ⟨depth.raw⟩
      else Unhygienic.run `($depth:ident + 1)
    let entry ← tableEntry map info entries[index]! (Unhygienic.run `($ofTable $table $depth:ident))
    let binders := (entry.captures ++ entry.arguments).map fun id =>
      Unhygienic.run `(bracketedBinder| ($id : $termType))
    let captures := entry.captures.map fun id => (⟨id.raw⟩ : TSyntax `term)
    let arguments := entry.arguments.map fun id => (⟨id.raw⟩ : TSyntax `term)
    let module := Syntax.mkStrLit entry.module
    let functionName := Syntax.mkStrLit entry.name
    let arity : TSyntax `term := ⟨Syntax.mkNumLit (toString arguments.size)⟩
    let body := entry.body
    let callee : TSyntax `term := Unhygienic.run `($function $module $functionName $arity #[$captures,*])
    let dispatcher : TSyntax `term := Unhygienic.run `(($ofTable $table $outer))
    let lemma (suffix : String) (call : Ident) (rhs : TSyntax `term) (reduce : Name) :=
      -- Equations are named after the function, such as `«maps:get/2».pure`.
      let name := mkIdent (.str (.mkSimple s!"{entry.module}:{entry.name}/{arguments.size}") suffix)
      let reduce := mkIdent reduce
      withSpan info.info (Unhygienic.run `(@[simp] theorem $name ($depth:ident : $natType)
        $binders:bracketedBinder* :
        $call $dispatcher $callee #[$arguments,*] = $rhs :=
        $reduce ($tableArg := $table) ($depth:ident := $depth:ident) ($moduleArg := $module)
          ($nameArg := $functionName)
          ($arityArg := $arity) ($capturesArg := #[$captures,*])
          ($argumentsArg := #[$arguments,*]) (by rfl) (by rfl)))
    match level with
    | "pure" =>
      result := result.push (lemma "pure" pureCall body ``Lynx.Dispatcher.pure_pure)
      result := result.push (lemma "call" effectfulCall (Unhygienic.run `($ofExcept $body))
        ``Lynx.Dispatcher.call_pure)
    | "apply" =>
      result := result.push (lemma "pure" pureCall body ``Lynx.Dispatcher.pure_apply)
      result := result.push (lemma "call" effectfulCall (Unhygienic.run `($ofExcept $body))
        ``Lynx.Dispatcher.call_apply)
    | _ =>
      result := result.push (lemma "call" effectfulCall body ``Lynx.Dispatcher.call_effectful)
  return result

private def diagnostic (file moduleName severity message : String)
    (location : Location := .unknown) (declarationName : Option Name := none) : Json :=
  Json.mkObj <| [("file", toJson file), ("module", toJson moduleName),
    ("declaration", toJson (declarationName.map Name.getString!)),
    ("severity", toJson severity), ("message", toJson message)] ++
    match location with
    | .unknown => []
    | .line line => [("line", toJson line)]
    | .column pos => [("line", toJson pos.line), ("column", toJson (pos.column + 1))]

/-- Match original offsets, retaining the precision the producer actually supplied.
If ranges coincide (e.g. a column at EOF and a line-only anchor), conservatively
report the less precise location rather than inventing a column. -/
private def messageLocation (map : FileMap) (spans : Array Span) (msg : Message) :
    Option String × Location := Id.run do
  let mut result := (none, Location.unknown)
  for span in spans do
    if let .synthetic start stop _ := span.info then
      if map.toPosition start == msg.pos && some (map.toPosition stop) == msg.endPos then
        match span.location with
        | .unknown => return (span.fileName, .unknown)
        | .line line => return (span.fileName, .line line)
        | .column pos => result := (span.fileName, .column pos)
  return result

/-- Read declaration identifiers from generated syntax.
A command containing several declarations has no single declaration name. -/
private partial def declarationNames (stx : Syntax) : Array Name :=
  if stx.isOfKind ``Lean.Parser.Command.declaration then
    let id := stx[1][1]
    let id := if id.isIdent then id else id[0]
    if id.isIdent then #[id.getId] else #[]
  else
    stx.getArgs.foldl (fun names child => names ++ declarationNames child) #[]

/-- Reveal the outer computation constructor and terminal payloads without
running process effects or traversing their continuations. -/
private def normalizeComputation (computation : Expr) : MetaM Expr := do
  let computation ← Meta.withTransparency .all <| Meta.whnf computation
  if computation.isAppOfArity ``Lynx.Result.ok 2 ||
      computation.isAppOfArity ``Lynx.Result.error 2 then
    let args := computation.getAppArgs
    let payload ← Meta.withTransparency .all <| Meta.whnf args[1]!
    return mkAppN computation.getAppFn (args.set! 1 payload)
  return computation

/-- Show both sides of the original law, independently of its incomplete proof
and of simplification that may have reduced the proof goal to `False`. -/
private def comparisonDescription (type : Expr) : MetaM (Option String) := do
  -- Show the outcome a law expects with its term reduced.
  let reduceOutcome (outcome : Expr) : MetaM Expr := do
    if outcome.isAppOfArity ``Lynx.Outcome.ok 2 then
      let args := outcome.getAppArgs
      pure (mkAppN outcome.getAppFn
        (args.set! 1 (← Meta.withTransparency .all <| Meta.whnf args[1]!)))
    else pure outcome
  -- Laws state their helpers through `Lynx.sequential` or `Lynx.concurrent`; show the
  -- computation they run.
  let (actual, expected) ← if type.isAppOfArity ``Lynx.concurrent 3 then
      let args := type.getAppArgs
      pure (← normalizeComputation args[1]!, ← reduceOutcome args[2]!)
    else
      unless type.isAppOfArity ``Eq 3 do return none
      let args := type.getAppArgs
      if args[1]!.isAppOfArity ``Lynx.sequential 2 then
        pure (← normalizeComputation args[1]!.getAppArgs[1]!, ← reduceOutcome args[2]!)
      else
        let resultType ← Meta.whnf args[0]!
        unless resultType.isAppOfArity ``Lynx.Result 1 do return none
        pure (← normalizeComputation args[1]!, ← normalizeComputation args[2]!)
  -- Continuations can contain the rest of the program. Bound their rendering;
  -- the constructor and leading arguments remain visible.
  withOptions (fun opts => opts.set `pp.maxSteps (80 : Nat)) do
    return some s!"  expected: {← Meta.ppExpr expected}\n  got:      {← Meta.ppExpr actual}"

/-- Describe the comparison inside a law's quantifiers: every depth from some
bound on. -/
private partial def lawComparison (type : Expr) : MetaM (Option String) := do
  if type.isAppOfArity ``Exists 2 then
    Meta.lambdaTelescope type.appArg! fun _ body => lawComparison body
  else if type.isForall then
    Meta.forallTelescope type fun _ body => lawComparison body
  else comparisonDescription type

private def lawFailureDetails (name : Name) : Elab.Command.CommandElabM (Option String) := do
  try
    let name := (← getCurrNamespace) ++ name
    let some (.thmInfo info) := (← getEnv).find? name | return none
    Elab.Command.liftTermElabM do
      Meta.forallTelescopeReducing info.type fun binders type => do
        let some expectation ← lawComparison type | return none
        let mut details := s!"Expectation (definitionally reduced):\n{expectation}"
        for binder in binders do
          let declaration ← binder.fvarId!.getDecl
          if declaration.userName == `requires then
            if let some requirement ← lawComparison declaration.type then
              details := details ++ s!"\n\nRequires (definitionally reduced):\n{requirement}"
        return some details
  catch _ => return none

/-- Laws elaborate one command at a time, so each theorem is timed with its proof. Other files
elaborate proofs and check declarations in parallel, as `lean` does, keeping only the snapshot
data a command-line run needs. -/
private def elabOptions (async : Bool) : Options :=
  (Options.empty.setBool `Elab.async async).setBool `internal.cmdlineSnapshots async

private def elaborateFile (env : Lean.Environment) (file : String) (map : FileMap)
    (commands : Array (TSyntax `command)) (theoremNames : Array Name) (async : Bool := false)
    : IO (Elab.Command.State × Array (Message × Option Name) × Array Json) := do
  let action : Elab.Command.CommandElabM (Array (Message × Option Name) × Array Json) := do
    let mut messages := #[]
    let mut theorems := #[]
    let mut pending := #[]
    for cmd in commands do
      let names := declarationNames cmd.raw
      let declarationName := if names.size == 1 then names[0]? else none
      let started ← IO.monoMsNow
      Elab.Command.elabCommandTopLevel cmd
      -- Proofs and kernel checks elaborating in the background report through snapshot tasks.
      -- Take them out of the state, which later commands would otherwise wait on and report again.
      pending := pending.push ((← get).snapshotTasks, declarationName)
      modify fun state => { state with snapshotTasks := #[] }
      let elapsed := (← IO.monoMsNow) - started
      if let some name := declarationName then
        if theoremNames.contains name then
          theorems := theorems.push (Json.mkObj [
            ("name", toJson name.getString!), ("time_ms", toJson elapsed)])
      let commandMessages := (← get).messages.toList
      let mut hint ← match declarationName with
        | some name =>
            if theoremNames.contains name && commandMessages.any (·.severity == .error) then
              lawFailureDetails name
            else pure none
        | none => pure none
      for msg in commandMessages do
        let msg ← match msg.severity, hint with
          | .error, some explanation => do
              hint := none
              pure { msg with data := m!"{explanation}\n\n{msg.data}" }
          | _, _ => pure msg
        messages := messages.push (msg, declarationName)
    for (tasks, declarationName) in pending do
      for task in tasks do
        for snapshot in task.get.getAll do
          for msg in snapshot.diagnostics.msgLog.toList do
            messages := messages.push (msg, declarationName)
    return (messages, theorems)
  let ((messages, theorems), state) ← (action.run { fileName := file, fileMap := map, snap? := none, cancelTk? := none }).run
    (Elab.Command.mkState env {} (elabOptions async)) |>.toIO
      (fun _ => IO.userError "runner elaboration failed")
  return (state, messages, theorems)

/-- One input file, decoded directly to Lean commands without elaboration. -/
structure DecodedFile where
  fileName : String
  moduleName : String
  imports : Array String
  fileMap : FileMap
  commands : Array (TSyntax `command)
  private cacheKey : Option String
  private spans : Array Span
  private proofDiagnostics : Array ProofDiagnostic
  private theorems : Array (Name × Span)
  private proofSources : Array (Name × String)
  private reexportImports : Bool
  private preludes : Array Json

/-- Immutable runtime imports, reused without retaining translated declarations. -/
private structure Runtime where
  env : Lean.Environment
  imports : ImportState

private def runtimeImports : Array Import :=
  #[{ module := `Lynx, isExported := true }, { module := `Lynx.Runner.Elab, isExported := true }]

private def getRuntime (cache : IO.Ref (Option Runtime)) : IO Runtime := do
  if let some runtime ← cache.get then return runtime
  unsafe enableInitializersExecution
  let runtime ← withImporting do
    let (_, state) ← (importModulesCore runtimeImports (globalLevel := .exported)).run
    let env ← finalizeImport state runtimeImports {} 0 false true (level := .exported)
    pure ({ env, imports := state } : Runtime)
  cache.set (some runtime)
  return runtime

private def importFile (runtime : Runtime) (imports : Array Import)
    (artifacts : NameMap ImportArtifacts) : IO Lean.Environment := do
  if imports == runtimeImports then return runtime.env
  unsafe enableInitializersExecution
  withImporting do
    -- Each file extends the runtime's import state, never a preceding file's state.
    let (_, state) ← (importModulesCore imports (globalLevel := .exported) (arts := artifacts)).run runtime.imports
    finalizeImport state imports {} 0 false true (level := .exported)

/-- Reserve synthetic offsets for supplied spans and embedded proof locations. -/
private partial def sourceExtent (j : Json) : Nat × Nat := Id.run do
  let mut lines := 1
  let mut columns := 1
  if let .ok xs := arr j "span" then
    if let some line := xs[0]? then
      lines := max lines (line.getNat?.toOption.getD 1)
    if let some column := xs[1]? then
      columns := max columns (column.getNat?.toOption.getD 1)
  if let .ok source := str j "source" then
    let sourceLines := source.splitOn "\n"
    lines := lines + sourceLines.length + 1
    -- Later lines start after the indentation, so the longest line bounds every column.
    let longest := sourceLines.foldl (fun longest line => max longest line.length) 0
    columns := columns + longest + (field j "indentation" >>= Json.getNat?).toOption.getD 0
  let children : Array Json := match j with
    | .arr xs => xs
    | .obj xs => xs.toArray.map (·.2)
    | _ => #[]
  for child in children do
    let (l, c) := sourceExtent child
    lines := max lines l
    columns := max columns c
  return (lines, columns)

private def sourceMap (entry : Json) : FileMap :=
  let (lines, columns) := sourceExtent entry
  let line := String.ofList (List.replicate columns ' ')
  FileMap.ofString (String.intercalate "\n" (List.replicate lines line))

/-- Resolve runtime modules consistently before decoding and importing a file. -/
private def inputImports (files : Array Json) (entry : Json) (env : Lean.Environment) :
    Except String (Array String) := do
  let moduleName ← str entry "module"
  (← arr entry "imports").mapM fun j => do
    let name ← j.getStr?
    let name := if name.startsWith "Erlang." &&
        (name == moduleName || !files.any (fun file => (str file "module").toOption == some name)) then
      "Lynx.Modules." ++ name
      else name
    let id ← (identifier name).run env |>.run' {}
    return id.getId.toString

/-- Lean options set at the top of every translated module. -/
private def optionCommands (j : Json) : Except String (Array (TSyntax `command)) := do
  let .ok (.obj options) := j.getObjVal? "options" | return #[]
  options.toArray.mapM fun (name, value) => do
    let id := mkIdent name.toName
    match value with
    | .num number =>
      unless number.exponent == 0 && number.mantissa ≥ 0 do
        throw s!"option {name} must be a natural number"
      let value := Syntax.mkNumLit (toString number.mantissa)
      pure (Unhygienic.run `(set_option $id:ident $value:num))
    | .bool true => pure (Unhygienic.run `(set_option $id:ident true))
    | .bool false => pure (Unhygienic.run `(set_option $id:ident false))
    | .str string => pure (Unhygienic.run `(set_option $id:ident $(Syntax.mkStrLit string):str))
    | _ => throw s!"option {name} must be a number, Boolean, or string"

/-- `Unhygienic.run` gives every quoted identifier the same macro scope, which source
rendering would print as `name✝`. Erasing it elaborates the same program as rendered. -/
private partial def eraseScopes : Syntax → Syntax
  | .ident info raw name preresolved => .ident info raw name.eraseMacroScopes preresolved
  | .node info kind args => .node info kind (args.map eraseScopes)
  | stx => stx

/-- Decode input files after the selected command requests them. -/
private def decodeFile (files : Array Json) (entry : Json) (env : Lean.Environment)
    (options : Array (TSyntax `command)) : IO DecodedFile := do
  let file ← IO.ofExcept (str entry "file")
  try
    let moduleName ← IO.ofExcept (str entry "module")
    let key ← (entry.getObjVal? "cache_key").toOption.mapM fun value => do
      let key ← IO.ofExcept value.getStr?
      unless [32, 64, 128].contains key.length && key.toList.all (fun c => c.isDigit || ('a' ≤ c && c ≤ 'f')) do
        throw (IO.userError "cache_key must be a 32, 64, or 128 character lowercase hex digest")
      pure key
    let map := sourceMap entry
    let preludes ← IO.ofExcept <| match field entry "preludes" with
      | .error _ => pure #[]
      | .ok value => value.getArr?
    if !preludes.isEmpty && !(← IO.ofExcept (arr entry "contents")).isEmpty then
      throw (IO.userError "prelude modules cannot contain translated declarations")
    let (moduleName, imports, commands, state, reexportImports) ← IO.ofExcept do
      fields entry ["file", "module", "imports", "contents", "cache_key", "preludes",
        "dispatcher_purity"]
      let dispatcherPurity ← match field entry "dispatcher_purity" with
        | .error _ => pure none
        | .ok value => do
          let level ← value.getStr?
          unless ["apply", "sequential", "concurrent"].contains level do
            throw "dispatcher_purity must be apply, sequential, or concurrent"
          pure (some level)
      let namespaceId ← (identifier moduleName).run env |>.run' {}
      let imports ← inputImports files entry env
      let contents ← arr entry "contents"
      let reexportImports := !contents.isEmpty || !preludes.isEmpty
      -- Calls embed pure callees in other computations, so collect every purity first.
      let mut purities : Std.HashMap String String := {}
      for content in contents do
        let definitions ← match (← str content "kind") with
          | "def" => pure #[content]
          | "mutual" => arr content "defs"
          | _ => pure #[]
        for definition in definitions do
          let key := s!"{← str definition "name"}/{(← arr definition "params").size}"
          let level ← resolveLevel dispatcherPurity definition "purity" "dispatches"
          purities := purities.insert key level
      let (commands, state) ← contents.mapM (commands map) |>.run env |>.run
        { purities, dispatcherPurity }
      -- Generated Core may contain unused match alternatives. Scope the
      -- option to generated declarations, restoring diagnostics for laws.
      let ignoreUnused := mkIdent `match.ignoreUnusedAlts
      let mut sectionCommands : Array (TSyntax `command) := #[]
      let mut generatedSection := false
      for i in [:contents.size] do
        let generated := (← str contents[i]! "kind") != "theorem"
        if generated != generatedSection then
          if generated then
            sectionCommands := sectionCommands.push (Unhygienic.run `(section))
            sectionCommands := sectionCommands.push (Unhygienic.run `(set_option $ignoreUnused:ident true))
          else
            sectionCommands := sectionCommands.push (Unhygienic.run `(end))
          generatedSection := generated
        sectionCommands := sectionCommands ++ commands[i]!
      if generatedSection then sectionCommands := sectionCommands.push (Unhygienic.run `(end))
      let visibility := Unhygienic.run `(@[expose] public section)
      let start := Unhygienic.run `(namespace $namespaceId)
      let stop := Unhygienic.run `(end $namespaceId)
      pure (namespaceId.getId.toString, imports,
        #[visibility] ++ options ++ #[start] ++ sectionCommands ++ #[stop], state, reexportImports)
    let commands := commands.map fun command => ⟨eraseScopes command.raw⟩
    return ⟨file, moduleName, imports, map, commands, key,
      state.spans, state.diagnostics, state.theorems, state.proofSources,
      reexportImports, preludes⟩
  catch err => throw (IO.userError s!"{file}: {err}")

private def parsingDiagnostics (file : DecodedFile) : Array Json :=
  file.proofDiagnostics.map fun error =>
    diagnostic (error.fileName.getD file.fileName) file.moduleName "error"
      error.message error.location (some error.declarationName)

/-- The placeholder standing for a theorem's proof while rendering. -/
private def proofPlaceholder : String := "lynxProofSource"

/-- Replace the proof of a theorem with recorded source by a placeholder.
Formatting would reflow the proof's tactics, which are sensitive to layout. -/
private def withProofPlaceholder (file : DecodedFile) (cmd : TSyntax `command) :
    Option (Nat × TSyntax `command) := do
  let decl := cmd.raw[1]
  guard (cmd.raw.isOfKind ``Parser.Command.declaration && decl.isOfKind ``Parser.Command.theorem)
  let index ← file.proofSources.findIdx? (·.1 == decl[1][0].getId)
  let value := decl[3]
  guard (value.isOfKind ``Parser.Command.declValSimple)
  let value := value.setArg 1 (mkIdent (Name.mkSimple proofPlaceholder))
  pure (index, ⟨cmd.raw.setArg 1 (decl.setArg 3 value)⟩)

/-- Insert proof source as a tactic block where the placeholder was rendered.
Theorems are top-level commands, so their tactics are indented by two spaces. -/
private def insertProofSource (source rendered : String) : String := Id.run do
  let [before, after] := rendered.splitOn proofPlaceholder | return rendered
  let before := before.trimAsciiEnd.toString
  let lines := (source.trimAsciiEnd.toString.splitOn "\n").map fun (line : String) =>
    if line.trimAscii.isEmpty then "" else "  " ++ line
  return before ++ " by\n" ++ "\n".intercalate lines ++ after

/-- The runtime modules every rendered file imports, so it elaborates as the runner does. -/
private def renderedRuntime : List (String × String) :=
  [("public import ", "Lynx"), ("import ", "Lynx.Runner.Elab")]

/-- Prelude blocks follow their header, which the runner extends with the runtime and the
file's imports. The rendered header declares them too, after the prelude's own imports. -/
private def renderPreludes (file : DecodedFile) : IO String := do
  let sources ← file.preludes.mapM fun block => IO.ofExcept (str block "source")
  let some first := sources[0]? | return ""
  let input := Parser.mkInputContext first file.fileName (normalizeLineEndings := false)
  let (header, _, _) ← Parser.parseHeader input
  let header : Elab.HeaderSyntax := header
  let declared := (header.imports (includeInit := false)).map fun (declared : Import) => declared.module.toString
  let added := renderedRuntime ++ file.imports.toList.map ("public import ", ·)
  let imports := added.filter (!declared.contains ·.2) |>.map fun (keyword, name) => keyword ++ name
  let stop := header.raw.getTailPos?.getD 0
  let first := String.Pos.Raw.extract first 0 stop ++ String.join (imports.map ("\n" ++ ·)) ++
    String.Pos.Raw.extract first stop first.rawEndPos
  return String.intercalate "\n\n" (first :: sources.toList.drop 1) ++ "\n"

private def renderFile (file : DecodedFile) (env : Lean.Environment) : IO String := do
  if !file.preludes.isEmpty then return ← renderPreludes file
  let action : CoreM String := do
    let commands ← file.commands.mapM fun cmd => do
      let some (index, cmd) := withProofPlaceholder file cmd
        | return (← PrettyPrinter.ppCommand cmd).pretty 100
      return insertProofSource (file.proofSources[index]!.2)
        ((← PrettyPrinter.ppCommand cmd).pretty 100)
    -- Exposed definitions and public law types mention imported operations.
    let importPrefix := if file.reexportImports then "public import " else "import "
    let imports := file.imports.toList.map (importPrefix ++ ·)
    -- Laws also import their dependencies for evaluation, see `lawImports`.
    let imports := if file.theorems.isEmpty then imports else
      imports ++ file.imports.toList.map ("meta import " ++ ·)
    -- The runner elaborates every file with its elaborators and simplification procedures.
    let runtime := renderedRuntime.map fun (keyword, name) => keyword ++ name
    return "module\n\n" ++ String.intercalate "\n" (runtime ++ imports) ++
      "\n\n" ++ String.intercalate "\n\n" commands.toList ++ "\n"
  (action.run' { fileName := file.fileName, fileMap := file.fileMap }
    { env := env }).toIO (fun _ => IO.userError s!"{file.fileName}: Lean source rendering failed")

/-- Remove parentheses, which rendering adds where precedence requires them, and
other differences that rendering cannot represent. -/
private partial def unparen (stx : Syntax) : Syntax :=
  if stx.isOfKind ``Parser.Term.paren then unparen stx[1]
  -- Applications without arguments render as their function.
  else if stx.isOfKind ``Parser.Term.app && stx[1].getNumArgs == 0 then unparen stx[0]
  else stx

/-- The first subterms where two syntax trees differ, ignoring source information
and parentheses. -/
private partial def syntaxDifference (expected actual : Syntax) : Option (Syntax × Syntax) :=
  -- Tactic sequences may end with an empty separator when the source ends with a newline.
  let trim (args : Array Syntax) : Array Syntax :=
    if args.back?.any (fun arg => arg.isOfKind nullKind && arg.getNumArgs == 0) then args.pop
    else args
  match unparen expected, unparen actual with
  | .node _ kind args, .node _ kind' args' =>
    let (args, args') := if kind == nullKind then (trim args, trim args') else (args, args')
    if kind != kind' || args.size != args'.size then some (unparen expected, unparen actual)
    else (args.zip args').findSome? fun (a, b) => syntaxDifference a b
  | .atom _ value, .atom _ value' =>
    if value == value' then none else some (unparen expected, unparen actual)
  | .ident _ _ name _, .ident _ _ name' _ =>
    if name == name' then none else some (unparen expected, unparen actual)
  | .missing, .missing => none
  | expected, actual => some (expected, actual)

/-- Parse rendered source and report where it differs from the elaborated commands. -/
private def checkRendered (file : DecodedFile) (source : String) (env : Lean.Environment) :
    IO (Option String) := do
  let input := Parser.mkInputContext source file.fileName
  let (_, state, messages) ← Parser.parseHeader input
  let mut state := state
  let mut messages := messages
  let mut parsed := #[]
  repeat
    let (command, state', messages') :=
      Parser.parseCommand input { env, options := {} } state messages
    state := state'
    messages := messages'
    if Parser.isTerminalCommand command then break
    parsed := parsed.push command
  if let some error := messages.toList.find? (·.severity == .error) then
    let position := s!"{error.pos.line}:{error.pos.column + 1}"
    return some s!"rendered source does not parse at {position}: {← error.data.toString}"
  if parsed.size != file.commands.size then
    return some s!"rendered source has {parsed.size} commands, expected {file.commands.size}"
  for (expected, actual) in file.commands.zip parsed do
    if let some (expected, actual) := syntaxDifference expected.raw actual then
      return some s!"rendered source parses differently: expected\n{expected}\nbut got\n{actual}"
  return none

/-- Whether an input file states laws. -/
private def hasLaws (entry : Json) : Except String Bool := do
  let contents ← arr entry "contents"
  contents.anyM fun content => return (← str content "kind") == "theorem"

/-- Laws also import their translated dependencies for evaluation, which loads
their compiled code, so `lynx_counterexample` can run the program in the
interpreter. The runtime is compiled into the runner. -/
private def lawImports (imports : Array Import) : Array Import :=
  imports.filterMap fun imported =>
    if runtimeImports.any (·.module == imported.module) then none
    else some { module := imported.module, isExported := false, isMeta := true }

private def cachedArtifacts (directory : System.FilePath) : ImportArtifacts :=
  let path := directory / "module.olean"
  .ofArrays #[#[path, path.withExtension "olean.server", path.withExtension "olean.private"],
    #[path.withExtension "ir.sig", path.withExtension "ir"]]

private def cachedDiagnostics (directory : System.FilePath) : IO (Option (Array Json)) := do
  try
    let metadata ← IO.ofExcept <| Json.parse (← IO.FS.readFile (directory / "result.json"))
    unless (← IO.ofExcept (str metadata "version")) == "1" do return none
    return some (← IO.ofExcept (arr metadata "diagnostics"))
  catch _ => return none

/-- Lake's artifact hashes identify the compiled runner and runtime, including local changes. -/
private def runtimeFingerprint : IO UInt64 := do
  let runner ← findOLean `Lynx.Runner
  let directory := runner.parent.get!
  let root := directory.parent.get!
  -- Include Lynx's root-module hashes beside the Lynx/ directory.
  let rootHashes := (← root.readDir).filter (·.fileName.startsWith "Lynx.")
  let paths := (← directory.walkDir) ++ rootHashes.map (·.path)
  let paths := paths.filter (·.toString.endsWith ".hash")
    |>.qsort (fun a b => a.toString < b.toString)
  let mut result := hash ("lynx-cache-1" : String)
  for path in paths do
    result := mixHash result (hash (path.toString.drop (root.toString.length + 1) |>.toString,
      ← IO.FS.readFile path))
  return result

/-- Publish complete, successfully audited entries atomically on the cache filesystem. -/
private def writeCached (directory : System.FilePath) (env : Lean.Environment)
    (diagnostics : Array Json) : IO Unit := do
  let parent := directory.parent.getD directory
  IO.FS.createDirAll parent
  let temporary := parent / s!".tmp-{hash (← IO.getRandomBytes 16)}"
  IO.FS.createDir temporary
  try
    writeModule env (temporary / "module.olean")
    IO.FS.writeFile (temporary / "result.json")
      (Json.mkObj [("version", toJson ("1" : String)), ("diagnostics", .arr diagnostics)]).compress
    if (← cachedDiagnostics directory).isSome then return
    if ← directory.pathExists then
      if (← cachedDiagnostics directory).isSome then return
      IO.FS.removeDirAll directory
    IO.FS.rename temporary directory
  catch error =>
    -- Another verifier may have published the same entry concurrently.
    unless (← cachedDiagnostics directory).isSome do throw error
  finally
    if ← temporary.pathExists then IO.FS.removeDirAll temporary

/-- The file, first line, line count, and span length of each prelude block. -/
private def preludeRanges (file : DecodedFile) : Array (Option String × Nat × Nat × Nat) :=
  file.preludes.map fun block =>
    let positions := (arr block "span").toOption.getD #[]
    let start := (positions[0]?.bind (·.getNat?.toOption)).getD 1
    let lines := ((str block "source").toOption.getD "").splitOn "\n" |>.length
    ((str block "file").toOption, start, lines, positions.size)

/-- Preserve the location precision supplied by a prelude block. -/
private def preludeLocation (ranges : Array (Option String × Nat × Nat × Nat)) (message : Message) :
    Location := Id.run do
  for (origin, start, lines, precision) in ranges do
    if origin != some message.fileName then continue
    if start ≤ message.pos.line && message.pos.line < start + lines then
      if precision ≥ 2 then return .column message.pos
      if precision == 1 then return .line message.pos.line
      return .unknown
  return .unknown

/-- A prelude block's source, padded so positions match the block's original span. -/
private def preludeSource (block : Json) : Except String (String × String) := do
  fields block ["source", "file", "span", "indentation"]
  let origin ← str block "file"
  let source ← str block "source"
  let indentation ← (← field block "indentation").getNat?
  let span ← arr block "span"
  let line ← if let some line := span[0]? then line.getNat? else pure 1
  let column ← if let some column := span[1]? then column.getNat? else pure 1
  let lines := source.splitOn "\n"
  let source := String.ofList (List.replicate (line - 1) '\n') ++
    String.ofList (List.replicate (column - 1) ' ') ++
    String.intercalate ("\n" ++ String.ofList (List.replicate indentation ' ')) lines
  pure (origin, source)

/-- The module header the first prelude block begins with, parsed by Lean. -/
private def preludeHeader (block : Json) :
    IO (Parser.InputContext × Elab.HeaderSyntax × Parser.ModuleParserState × MessageLog) := do
  let (origin, source) ← IO.ofExcept (preludeSource block)
  let input := Parser.mkInputContext source origin (normalizeLineEndings := false)
  let (header, state, messages) ← Parser.parseHeader input
  return (input, header, state, messages)

/-- The imports a prelude declares in its header. -/
private def preludeImports (entry : Json) : IO (Array Import) := do
  let preludes := (arr entry "preludes").toOption.getD #[]
  let some first := preludes[0]? | return #[]
  let (_, header, _, _) ← preludeHeader first
  return header.imports (includeInit := false)

/-- Elaborate one prelude block without waiting for the proofs elaborating in the background:
the final command state, whose environment may still be checking proofs, and the snapshot tree
that reports their diagnostics. -/
private partial def processBlock (input : Parser.InputContext) (parserState : Parser.ModuleParserState)
    (state : Elab.Command.State) : IO (Elab.Command.State × Language.SnapshotTree) := do
  let initial := (← Language.Lean.processCommands input parserState state).get
  let rec last (snap : Language.Lean.CommandParsedSnapshot) : Language.Lean.CommandParsedSnapshot :=
    match snap.nextCmdSnap? with
    | some next => last next.task.get
    | none => snap
  let final := last initial
  return (final.elabSnap.resultSnap.get.cmdState, Language.toSnapshotTree initial)

/-- Elaborate a prelude as one module: the first block begins with its header, and
blocks follow in order, so each command can extend the parser for later commands.
The frontend retains the sigils' original positions. -/
private def elaboratePreludes (env : Lean.Environment) (file : DecodedFile) :
    IO (Elab.Command.State × Array (Message × Option Name) × Array Json) := do
  let (initial, _, _) ← elaborateFile env file.fileName file.fileMap #[] #[] (async := true)
  let mut state := initial
  let mut messages : Array (Message × Option Name) := #[]
  let mut trees : Array Language.SnapshotTree := #[]
  let mut first := true
  for block in file.preludes do
    let (input, parserState) ← if first then
        let (input, header, parserState, headerMessages) ← preludeHeader block
        for message in headerMessages.toList do
          messages := messages.push (message, none)
        unless header.isModule do
          let message : Message := {
            fileName := input.fileName, pos := ⟨1, 0⟩, severity := .error,
            data := "a prelude must begin with a module header" }
          messages := messages.push (message, none)
        pure (input, parserState)
      else
        let (origin, source) ← IO.ofExcept (preludeSource block)
        pure (Parser.mkInputContext source origin (normalizeLineEndings := false), {})
    first := false
    let (next, tree) ← processBlock input parserState { state with messages := {} }
    state := next
    trees := trees.push tree
  -- Proofs of all blocks elaborate in parallel; report their diagnostics once they finish.
  for tree in trees do
    for snapshot in tree.getAll do
      for message in snapshot.diagnostics.msgLog.toList do
        messages := messages.push (message, none)
  return ({ state with messages := {} }, messages, #[])

/-- Copy compiled modules into `root` by module path, such as `Erlang/json.olean`, so
tools that load modules by name through `LEAN_PATH` can use them. -/
private def layoutArtifacts (root : System.FilePath) (modules : Array Name)
    (artifacts : NameMap ImportArtifacts) : IO Unit := do
  for module in modules do
    let some paths := artifacts.find? module | continue
    for file in paths.toArrays.flatten do
      -- Artifacts are named `module.<extension>`, such as `module.olean.private`.
      let some name := file.fileName | continue
      unless ← file.pathExists do continue
      let target := modToFilePath root module (name.drop "module.".length).toString
      IO.FS.createDirAll (target.parent.getD root)
      IO.FS.writeBinFile target (← IO.FS.readBinFile file)

/-- Export the declarations of the given modules, with everything they depend on, using
the toolchain's `leanexport`. Modules are imported with their private data so the
export includes proofs. Unsafe and partial declarations, such as compiled
`_unsafe_rec` helpers, cannot be used by safe ones, and meta declarations do not
contribute to proofs, so they are skipped. -/
private def exportModules (path : System.FilePath) (modules : Array Name)
    (artifacts : NameMap ImportArtifacts) (temporary : System.FilePath) : IO Unit := do
  unsafe enableInitializersExecution
  let env ← importModules (modules.map ({ module := · })) {} (loadExts := true) (arts := artifacts)
  let constants := env.constants.toList.filterMap fun (name, info) => do
    let index ← env.getModuleIdxFor? name
    guard (modules.contains env.header.moduleNames[index.toNat]!)
    guard !(info.isUnsafe || info.isPartial || isMarkedMeta env name)
    pure name
  -- `leanexport` finds modules by name, so lay out the artifacts as a search path.
  let root := temporary / "export"
  layoutArtifacts root modules artifacts
  let searchPath := (← IO.getEnv "LEAN_PATH").map (System.SearchPath.separator.toString ++ ·)
  let output ← IO.Process.output {
    cmd := ((← findSysroot) / "bin" / "leanexport").toString
    args := (modules.map toString) ++ #["--"] ++ constants.toArray.map toString
    env := #[("LEAN_PATH", some (root.toString ++ searchPath.getD ""))]
  }
  unless output.exitCode == 0 do
    throw (IO.userError s!"leanexport failed: {output.stderr}")
  IO.FS.writeFile path output.stdout

/-- What debugging writes. Sources are always written; `olean` adds compiled modules. -/
private inductive DebugMode where
  | lean
  | olean

/-- Where and when to write the rendered sources of a request. -/
private structure Debug where
  dir : System.FilePath
  /-- Write even when every file verifies. -/
  always : Bool
  mode : DebugMode

/-- Write rendered sources by module path, as Lean lays out modules. -/
private def writeSources (dir : System.FilePath) (sources : Array (Name × String)) : IO Unit := do
  for (module, source) in sources do
    let path := modToFilePath dir module "lean"
    IO.FS.createDirAll (path.parent.getD dir)
    IO.FS.writeFile path source

/-- Verify against explicit imports, reusing only successfully audited module artifacts. -/
private def verify (files : Array Json) (options : Array (TSyntax `command)) (runtime : Runtime)
    (cacheDirectory : System.FilePath) (export? : Option System.FilePath)
    (debug? : Option Debug) (checkSource : Bool) (emit : Json → IO Unit) : IO Unit := do
  IO.FS.withTempDir fun temporary => do
    let mut artifacts : NameMap ImportArtifacts := {}
    let mut sources : Array (Name × String) := #[]
    let mut exported : Array Name := #[]
    let mut verified : Std.HashSet String := {}
    let mut uncached : Std.HashSet String := {}
    for entry in files do
      let started ← IO.monoMsNow
      let moduleString ← IO.ofExcept (str entry "module")
      let origin ← IO.ofExcept (str entry "file")
      let names ← IO.ofExcept (inputImports files entry runtime.env)
      let reexport := !(← IO.ofExcept (arr entry "contents")).isEmpty ||
        !((arr entry "preludes").toOption.getD #[]).isEmpty
      let mut imports := runtimeImports
      let mut missingImport := false
      let mut diagnostics := #[]
      let mut cacheHit := false
      let mut theorems := #[]
      for name in names do
        let moduleName ← IO.ofExcept <| (identifier name).run runtime.env |>.run' {}
        let moduleName := moduleName.getId
        if files.any (fun other => (str other "module").toOption == some name) &&
            !verified.contains name then
          missingImport := true
          diagnostics := diagnostics.push (diagnostic origin moduleString "error"
            s!"import '{name}' must precede this file and verify successfully")
        unless imports.any (·.module == moduleName) do
          imports := imports.push { module := moduleName, isExported := reexport }
      if ← IO.ofExcept (hasLaws entry) then
        imports := imports ++ lawImports imports
      -- A prelude declares its own imports in its header.
      for declared in ← preludeImports entry do
        unless imports.any (·.module == declared.module) do
          imports := imports.push declared
      -- Syntax extensions are available only after importing this file's declared
      -- dependencies. Never decode all proofs against the bare runtime up front.
      let env ← if missingImport then pure runtime.env else importFile runtime imports artifacts
      let file ← decodeFile files entry env options
      let source ← renderFile file env
      let sourceModule ← IO.ofExcept <| (identifier file.moduleName).run runtime.env |>.run' {}
      sources := sources.push (sourceModule.getId, source)
      let mut fileFailed := !file.proofDiagnostics.isEmpty
      diagnostics := diagnostics ++ parsingDiagnostics file
      if checkSource && file.preludes.isEmpty then
        if let some message ← checkRendered file source env then
          fileFailed := true
          diagnostics := diagnostics.push (diagnostic file.fileName file.moduleName "error" message)
      unless missingImport do
        let moduleName ← IO.ofExcept <| (identifier file.moduleName).run runtime.env |>.run' {}
        let mainModule := moduleName.getId
        let key := if file.imports.any uncached.contains then none else file.cacheKey
        let directory := key.map (cacheDirectory / ·) |>.getD (temporary / toString (hash mainModule))
        if let some saved ← if fileFailed || key.isNone then pure none else cachedDiagnostics directory then
          diagnostics := saved
          cacheHit := true
        else
          let (state, messages, timings) ← if file.preludes.isEmpty then
            elaborateFile (env.setMainModule mainModule)
              file.fileName file.fileMap file.commands (file.theorems.map Prod.fst) file.theorems.isEmpty
            else elaboratePreludes (env.setMainModule mainModule) file
          theorems := timings
          let ranges := preludeRanges file
          for (msg, declarationName) in messages do
            if msg.severity == .error then fileFailed := true
            let (origin, location) := if file.preludes.isEmpty then
              messageLocation file.fileMap file.spans msg
              else (some msg.fileName, preludeLocation ranges msg)
            diagnostics := diagnostics.push (diagnostic (origin.getD file.fileName) file.moduleName
              msg.severity.toString
              (← msg.data.toString) location declarationName)
          -- Audit local laws and the precomputed axiom dependencies of imported declarations.
          unless fileFailed do
            let audit : CoreM (Array Json) := do
              let mut errors := #[]
              let namespaceId ← IO.ofExcept <| (identifier file.moduleName).run (← getEnv) |>.run' {}
              for (name, info) in file.theorems do
                for axiomName in ← collectAxioms (namespaceId.getId ++ name) do
                  unless #[``propext, ``Classical.choice, ``Quot.sound].contains axiomName do
                    errors := errors.push (diagnostic file.fileName file.moduleName "error"
                      s!"unexpected axiom: {axiomName}" info.location (some name))
              return errors
            let errors ← (audit.run' { fileName := file.fileName, fileMap := file.fileMap }
              { env := state.env }).toIO (fun _ => IO.userError "law axiom audit failed")
            if !errors.isEmpty then fileFailed := true
            diagnostics := diagnostics ++ errors
          unless fileFailed do
            if key.isSome then
              writeCached directory state.env diagnostics
            else
              IO.FS.createDirAll directory
              writeModule state.env (directory / "module.olean")
        unless fileFailed do
          artifacts := artifacts.insert mainModule (cachedArtifacts directory)
          exported := exported.push mainModule
          verified := verified.insert file.moduleName
          if key.isNone then uncached := uncached.insert file.moduleName
      let elapsed := (← IO.monoMsNow) - started
      let status := if missingImport then "skipped" else if fileFailed then "error" else "ok"
      emit (Json.mkObj [
        ("status", toJson status),
        ("file", toJson file.fileName), ("module", toJson file.moduleName),
        ("time_ms", toJson elapsed),
        ("cached", toJson cacheHit), ("theorems", .arr theorems),
        ("diagnostics", .arr diagnostics)])
    if let some path := export? then
      if exported.size == files.size then
        exportModules path exported artifacts temporary
    if let some debug := debug? then
      if debug.always || exported.size != files.size then
        writeSources debug.dir sources
      if debug.mode matches .olean then
        layoutArtifacts debug.dir exported artifacts

private def runFiles (j : Json) (cache : IO.Ref (Option Runtime)) (emit : Json → IO Unit) : IO Unit := do
  let (files, options) ← IO.ofExcept do
    fields j ["command", "version", "files", "cache_dir", "options", "export", "debug_dir", "debug",
      "check_source"]
    pure (← arr j "files", ← optionCommands j)
  let directory := System.FilePath.mk (← IO.ofExcept (str j "cache_dir"))
  let export? := (str j "export").toOption.map System.FilePath.mk
  let debug? ← IO.ofExcept (ε := String) do
    let .ok dir := str j "debug_dir" | pure none
    match (str j "debug").toOption.getD "" with
    | "" => pure (some { dir, always := false, mode := .lean : Debug })
    | "lean" => pure (some { dir, always := true, mode := .lean : Debug })
    | "olean" => pure (some { dir, always := true, mode := .olean : Debug })
    | mode => throw s!"unsupported debug mode '{mode}'"
  let checkSource := (field j "check_source" >>= (·.getBool?)).toOption.getD false
  unless files.isEmpty do
    let runtime ← getRuntime cache
    -- Options change elaboration, so artifacts are cached per set of options.
    let optionKey := if options.isEmpty then "" else
      s!"-{hash ((j.getObjValD "options").compress)}"
    let directory ← if files.any (fun file => (field file "cache_key").isOk) then
      pure (directory / s!"lean-{Lean.versionString}-{← runtimeFingerprint}{optionKey}")
      else pure directory
    verify files options runtime directory export? debug? checkSource emit

private def run (request : String) (cache : IO.Ref (Option Runtime)) (emit : Json → IO Unit) : IO Unit := do
  try
    let j ← IO.ofExcept (Json.parse request)
    let command ← IO.ofExcept (str j "command")
    let version ← IO.ofExcept (str j "version")
    unless version == "1.0" do throw (IO.userError "unsupported version")
    unless command == "verify" do throw (IO.userError s!"unsupported runner command '{command}'")
    runFiles j cache emit
    emit (Json.mkObj [("status", toJson "done")])
  catch err =>
    emit (Json.mkObj [("status", toJson "failure"), ("message", toJson err.toString)])

end Lynx.Runner

/-- Process newline-delimited JSON requests until stdin closes. -/
public def main (args : List String) : IO UInt32 := do
  match args with
  | [] =>
    Lean.initSearchPath (← Lean.findSysroot)
    let cache ← IO.mkRef (none : Option Lynx.Runner.Runtime)
    let stdin ← IO.getStdin
    let stdout ← IO.getStdout
    let emit := fun payload : Lean.Json => do
      stdout.putStrLn payload.compress
      stdout.flush
    -- Requests run in order on a dedicated thread while this one keeps reading
    -- stdin, so the runner exits once it closes, even during an evaluation that
    -- never checks for it.
    let mut pending : Task (Except IO.Error Unit) := .pure (.ok ())
    repeat
      let request ← stdin.getLine
      if request.isEmpty then break
      pending ← IO.bindTask pending (fun _ => IO.asTask (Lynx.Runner.run request cache emit) .dedicated)
    IO.Process.exit 0
  | _ =>
    IO.println (Lean.Json.mkObj [("status", Lean.toJson "failure"),
      ("message", Lean.toJson "usage: Runner.lean")]).compress
    return 2
