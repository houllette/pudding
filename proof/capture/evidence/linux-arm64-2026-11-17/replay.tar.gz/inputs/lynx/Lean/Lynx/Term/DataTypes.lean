module

public import Lynx.Term.FiniteFloat
public import Lynx.Term.Bitstring

private instance : Repr ByteArray where
  reprPrec bytes prec := reprPrec bytes.data prec

public section

namespace Lynx

/-- Process identifiers are paths from the process that started the run, which
is `[]`. A process's `n`-th child extends its parent's path with `n`, so
allocation does not depend on how processes interleave. -/
abbrev PID := List Nat

open _root_.Lynx.Term.Bitstring.Measure in
inductive Term where
  | integer : Int → Term
  | float : _root_.Lynx.Term.FiniteFloat → Term
  | atom : String → Term
  /-- Reference identity: the allocating process's PID extended with its own
  allocation count, unique across the run. -/
  | reference : List Nat → Term
  /-- The module, name, and arity the compiler gave a function, and its captured
  values. Comparison orders them in turn. -/
  | function (module name : String) (arity : Nat) (captures : Array Term) : Term
  | pid : PID → Term
  | tuple : Array Term → Term
  | map : List (Term × Term) → Term
  | nil : Term
  | cons : Term → Term → Term
  /-- Packed bits, with `0` denoting whole bytes and `1`–`7` denoting
  the used high bits of the last byte. Empty storage must use `0`, and
  unused low bits must be zero. -/
  | bitstring (bytes : ByteArray) (lastBits : Fin 8)
      (valid : _root_.Lynx.Term.Bitstring.Valid bytes lastBits := by
        first
        | assumption
        | exact _root_.Lynx.Term.Bitstring.valid_aligned _
        | decide) : Term
deriving Repr

namespace Term

/-- A proper list of the given elements. -/
@[expose, reducible] def list : List Term → Term
  | [] => .nil
  | head :: tail => .cons head (list tail)

@[simp] theorem list_nil : list [] = .nil := rfl

@[simp] theorem list_cons (head : Term) (tail : List Term) :
    list (head :: tail) = .cons head (list tail) := rfl

end Term

inductive Exception where
  | error : Term → Exception
  | throw : Term → Exception
  | exit : Term → Exception
  /-- The computation does not return: it reached a translation cutoff, diverged
  in a partial fixed point, or exceeded the dynamic-call depth. This is not an
  Erlang exception. Handlers never receive it, so no Erlang code observes it, and
  it is the least element of the order used by partial fixed points. -/
  | exhausted : Exception
deriving Repr

instance : Inhabited Exception := ⟨.exhausted⟩

namespace Exception

/-- Handlers never receive `exhausted`, so its class is never observed. -/
@[expose] def classTerm : Exception → Term
  | .error _ => .atom "error"
  | .throw _ => .atom "throw"
  | .exit _ => .atom "exit"
  | .exhausted => .atom "exhausted"

/-- Handlers never receive `exhausted`, so its reason is never observed. -/
@[expose] def reason : Exception → Term
  | .error value | .throw value | .exit value => value
  | .exhausted => .atom "exhausted"

/-- Raw Core exception tokens retain their class when re-raised. -/
@[expose] def withReason : Exception → Term → Exception
  | .error _, value => .error value
  | .throw _, value => .throw value
  | .exit _, value => .exit value
  | .exhausted, _ => .exhausted

/-- Stack frames are not recorded by the runtime model. -/
@[expose] def stacktrace (_ : Exception) : Term := .nil

end Exception

/-- Scheduler decisions, consumed after each step of a process other than an
environment access. They are supplied to the runner, not stored in the
environment processes observe. Signals in transit arrive before any choice.
No remaining choice defaults to the current process when runnable. `swap pid`
prefers the named process; blocked or finished processes yield automatically.
Positive receive durations are abstract: timeout choices express expiry
order, without measuring or waiting for elapsed time. Blocking also consumes
choices; when no process can run, a finite receive expires automatically, and
otherwise the oldest timer fires. -/
inductive ScheduleChoice where
  | current
  /-- Prefer this runnable process; unavailable choices fall back to the current/first runnable process. -/
  | swap : PID → ScheduleChoice
  /-- Expire a positive-timeout receive belonging to this PID, if it has no
  matching message. Unavailable choices fall back to ordinary scheduling. -/
  | timeout : PID → ScheduleChoice
deriving Repr

instance : Inhabited ScheduleChoice := ⟨.current⟩

/-- What a running process observes and may replace. Mailboxes and other
processes belong to the scheduler, so a process cannot change them, and
replacing `currentPid` does not change which process is running. -/
structure Environment where
  /-- PID of the process running the current computation. -/
  currentPid : PID := []
  /-- Number of references the process running the current computation allocated.
  Once processes run concurrently, a process cannot lower it. -/
  refCounter : Nat := 0
  /-- Process dictionary of the process running the current computation. -/
  pdict : List (Term × Term) := []
deriving Repr, Inhabited

/-- How a run ended. The final environment is returned separately by the
low-level runners, so laws and callers of `Lynx.sequential` compare outcomes alone. -/
inductive Outcome (α : Type) where
  | ok : α → Outcome α
  /-- An uncaught exception. `Exception.exhausted` means some process did not
  return, which ends the whole run. -/
  | error : Exception → Outcome α
  /-- No modeled process can proceed. This is not an Erlang exception. -/
  | deadlock : Outcome α
deriving Repr

/-- Receive durations are validated before entering the process operation.
Positive durations share one mode: expiry order is chosen by the scheduler. -/
inductive ReceiveTimeout where
  | infinity
  | immediate
  | finite
deriving Repr, Inhabited

/-- How a spawn relates the parent to its child. -/
structure SpawnOptions where
  /-- Link the parent and the child. -/
  link : Bool := false
  /-- Monitor the child, allocating the monitor's reference from the parent's
  counter. -/
  monitor : Bool := false
deriving Repr, Inhabited

/-- A request about other processes, which the scheduler answers with a term. -/
inductive Request where
  /-- Monitor a process, replying with the monitor's reference. An alias also
  makes the reference a destination for the requester until the monitor ends. -/
  | monitor (target : PID) (alias : Bool)
  /-- End a monitor. Flushing an inactive monitor removes the oldest
  `{_, Reference, _, _, _}` message from the mailbox. Replies whether the
  monitor was active. -/
  | demonitor (reference : List Nat) (flush : Bool)
  /-- Link to a process. Replies `true`, or `noproc` when the process does not
  exist and the requester does not trap exits. -/
  | link (target : PID)
  /-- Remove a link. Replies `true`. -/
  | unlink (target : PID)
  /-- Send an exit signal. Replies `true`. -/
  | exit (target : PID) (reason : Term)
  /-- Set whether exit signals arrive as messages. Replies the previous value. -/
  | trapExit (enabled : Bool)
  /-- Reply whether a process is alive. -/
  | alive (target : PID)
  /-- Send to an alias, discarding the message once the alias is inactive.
  Replies the message. -/
  | sendAlias (alias : List Nat) (message : Term)
  /-- Start a timer sending a message to a process, replying its reference. A
  timer for a process that is not alive never fires. -/
  | startTimer (destination : PID) (message : Term) (duration : Nat)
  /-- Cancel a timer by its reference. Replies the milliseconds it had left, or
  `false` once it fired, was canceled, or its destination exited. A fired
  timer's message may still be in transit. -/
  | cancelTimer (reference : List Nat)
deriving Repr

/-- A resumable process computation. Bind stores continuations so scheduling
does not require translated functions to use continuation-passing style. -/
inductive Result : (α : Type := Term) → Type 1 where
  | ok {α : Type} : α → Result α
  | error {α : Type} : Exception → Result α
  | get {α : Type} : (Environment → Result α) → Result α
  | set {α : Type} : Environment → Result α → Result α
  /-- A spawned child process, then the continuation receiving its PID. -/
  | schedule {α : Type} : SpawnOptions → Result Term → (PID → Result α) → Result α
  /-- Local asynchronous send. The message is in transit, and the sender continues at once. -/
  | send {α : Type} : PID → Term → Result α → Result α
  /-- A receive with an already validated timeout. Select the oldest matching
  message and schedule before executing its body. `some` carries clause bindings;
  `none` resumes the timeout body. No match without expiry suspends the process. -/
  | receive {α β : Type} : ReceiveTimeout → (Environment → Term → Option β) → (Option β → Result α) → Result α
  /-- A request about other processes, then the continuation receiving the reply. -/
  | request {α : Type} : Request → (Term → Result α) → Result α

/-- Validate before scanning, including when a matching message is queued.
Positive durations are abstract scheduler events, not elapsed milliseconds. -/
@[expose] def ReceiveTimeout.ofTerm : Term → Result ReceiveTimeout
  | .atom "infinity" => .ok .infinity
  | .integer n =>
      if n < 0 || n > 4294967295 then .error (.error (.atom "timeout_value"))
      else if n == 0 then .ok .immediate else .ok .finite
  | _ => .error (.error (.atom "timeout_value"))

namespace Result

@[expose] protected def bind (computation : Result α) (next : α → Result β) : Result β :=
  match computation with
  | .ok value => next value
  | .error exception => .error exception
  | .get continuation => .get fun env => Result.bind (continuation env) next
  | .set env continuation => .set env (Result.bind continuation next)
  | Result.schedule options child continuation =>
      Result.schedule options child fun pid => Result.bind (continuation pid) next
  | .send pid message continuation => .send pid message (Result.bind continuation next)
  | .receive timeout select continuation =>
      .receive timeout select fun reply => Result.bind (continuation reply) next
  | .request query continuation => .request query fun reply => Result.bind (continuation reply) next

instance : Monad @Result where
  pure := .ok
  bind := Result.bind

/-- Validate once before receiving. Every consumed message and timeout is a
scheduler boundary before its continuation, including queued matches. -/
@[expose] def receiveWith (timeout : Term) (select : Environment → Term → Option β)
    (next : Option β → Result α) : Result α := do
  let duration ← ReceiveTimeout.ofTerm timeout
  .receive duration select next

/-- Normalize a successful monadic return without unfolding the `Monad` instance. -/
@[simp] theorem pure_eq_ok (value : α) : (pure value : Result α) = .ok value := rfl

instance : MonadStateOf Environment @Result where
  get := .get .ok
  set env := .set env (.ok .unit)
  modifyGet update := .get fun env =>
    let (value, next) := update env
    .set next (.ok value)

/-- Handle exceptions raised by the computation. `exhausted` is not an Erlang
exception, so it propagates without reaching the handler. -/
@[expose] protected def handle (computation : Result α) (handler : Exception → Result α) : Result α :=
  match computation with
  | .ok value => .ok value
  | .error .exhausted => .error .exhausted
  | .error exception => handler exception
  | .get continuation => .get fun env => Result.handle (continuation env) handler
  | .set env continuation => .set env (Result.handle continuation handler)
  | Result.schedule options child continuation =>
      Result.schedule options child fun pid => Result.handle (continuation pid) handler
  | .send pid message continuation => .send pid message (Result.handle continuation handler)
  | .receive timeout select continuation =>
      .receive timeout select fun reply => Result.handle (continuation reply) handler
  | .request query continuation =>
      .request query fun reply => Result.handle (continuation reply) handler

/-- Catch only the protected computation. Exceptions raised by either
continuation propagate to an enclosing handler. -/
@[expose] def tryWith (computation : Result α) (next : α → Result β)
    (handler : Exception → Result β) : Result β :=
  Result.bind
    (Result.handle (Result.bind computation (fun value => .ok (Except.ok value)))
      (fun exception => .ok (Except.error exception)))
    (fun reply => match reply with
      | .ok value => next value
      | .error exception => handler exception)

@[simp] theorem tryWith_ok (value : α) (next : α → Result β)
    (handler : Exception → Result β) :
    Result.tryWith (.ok value) next handler = next value := rfl

@[simp] theorem tryWith_error (exception : Exception) (next : α → Result β)
    (handler : Exception → Result β) (raised : exception ≠ .exhausted) :
    Result.tryWith (.error exception) next handler = handler exception := by
  cases exception <;> first | rfl | contradiction

@[simp] theorem tryWith_exhausted (next : α → Result β) (handler : Exception → Result β) :
    Result.tryWith (.error .exhausted) next handler = .error .exhausted := rfl

/-- Erlang `orelse`, or Elixir's strict `or` when `badbool`. The right operand is
selected only after the left one returns `false`; other values raise `badarg`,
or `badbool` for Elixir. Like `||`, compiled code inlines it so that the right
operand is not evaluated before the choice. -/
@[expose, macro_inline] def orElse (left right : Result) (badbool : Bool := false) : Result :=
  Result.bind left fun value => match value with
    | .atom "true" => .ok (.atom "true")
    | .atom "false" => right
    | other => .error (.error (if badbool then .tuple #[.atom "badbool", .atom "or", other]
        else .tuple #[.atom "badarg", other]))

/-- Erlang `andalso`, or Elixir's strict `and` when `badbool`. The right operand
is selected only after the left one returns `true`; other values raise `badarg`,
or `badbool` for Elixir. Like `&&`, compiled code inlines it so that the right
operand is not evaluated before the choice. -/
@[expose, macro_inline] def andAlso (left right : Result) (badbool : Bool := false) : Result :=
  Result.bind left fun value => match value with
    | .atom "true" => right
    | .atom "false" => .ok (.atom "false")
    | other => .error (.error (if badbool then .tuple #[.atom "badbool", .atom "and", other]
        else .tuple #[.atom "badarg", other]))

/-- Proofs see the case on the left operand that Core's lowering produces. -/
@[simp] theorem orElse_eq (left right : Result) (badbool : Bool) :
    orElse left right badbool = left >>= fun value => match value with
      | .atom "true" => .ok (.atom "true")
      | .atom "false" => right
      | other => .error (.error (if badbool then .tuple #[.atom "badbool", .atom "or", other]
          else .tuple #[.atom "badarg", other])) := rfl

/-- Proofs see the case on the left operand that Core's lowering produces. -/
@[simp] theorem andAlso_eq (left right : Result) (badbool : Bool) :
    andAlso left right badbool = left >>= fun value => match value with
      | .atom "true" => right
      | .atom "false" => .ok (.atom "false")
      | other => .error (.error (if badbool then .tuple #[.atom "badbool", .atom "and", other]
          else .tuple #[.atom "badarg", other])) := rfl

instance : MonadExceptOf Exception @Result where
  throw := .error
  tryCatch := Result.handle

@[simp] theorem bind_ok (computation : Result α) :
    (computation >>= Result.ok) = computation := by
  change Result.bind computation .ok = computation
  induction computation with
  | ok | error => rfl
  | get continuation ih =>
      simp only [Result.bind]
      congr
      funext env
      exact ih env
  | set env continuation ih => simp [Result.bind, ih]
  | schedule options child continuation childIh continuationIh =>
      simp only [Result.bind]
      congr
      funext pid
      exact continuationIh pid
  | send pid message continuation ih => simp [Result.bind, ih]
  | receive timeout select continuation ih =>
      simp only [Result.bind]
      congr
      funext value
      exact ih value
  | request query continuation ih =>
      simp only [Result.bind]
      congr
      funext reply
      exact ih reply

private theorem bind_assoc_proof (computation : Result α)
    (next : α → Result β) (final : β → Result γ) :
    Result.bind (Result.bind computation next) final =
      Result.bind computation fun value => Result.bind (next value) final := by
  induction computation with
  | ok | error => rfl
  | get continuation ih =>
      simp only [Result.bind]
      congr
      funext env
      exact ih env next
  | set env continuation ih => simp [Result.bind, ih next]
  | schedule options child continuation childIh continuationIh =>
      simp only [Result.bind]
      congr
      funext pid
      exact continuationIh pid next
  | send pid message continuation ih => simp [Result.bind, ih next]
  | receive timeout select continuation ih =>
      simp only [Result.bind]
      congr
      funext value
      exact ih value next
  | request query continuation ih =>
      simp only [Result.bind]
      congr
      funext reply
      exact ih reply next

instance : LawfulMonad @Result := LawfulMonad.mk' _
  (id_map := fun computation => bind_ok computation)
  (pure_bind := fun _ _ => rfl)
  (bind_assoc := bind_assoc_proof)

/-- A pure computation is already terminal and therefore independent of runtime state. -/
@[expose] def IsPure : Result α → Prop
  | .ok _ | .error _ => True
  | _ => False

@[simp] theorem isPure_ok (value : α) : IsPure (.ok value) := trivial
@[simp] theorem isPure_error (exception : Exception) : IsPure (.error exception : Result α) := trivial

@[simp] theorem not_isPure_get (next : Environment → Result α) :
    ¬ IsPure (.get next) := by simp [IsPure]
@[simp] theorem not_isPure_set (env : Environment) (next : Result α) :
    ¬ IsPure (.set env next) := by simp [IsPure]

@[simp] theorem not_isPure_schedule (options : SpawnOptions) (child : Result Term)
    (next : PID → Result α) :
    ¬ IsPure (Result.schedule options child next) := by simp [IsPure]

@[simp] theorem not_isPure_send (pid : PID) (message : Term) (next : Result α) :
    ¬ IsPure (.send pid message next) := by simp [IsPure]
@[simp] theorem not_isPure_receive (timeout : ReceiveTimeout) (select : Environment → Term → Option β)
    (next : Option β → Result α) :
    ¬ IsPure (.receive timeout select next) := by simp [IsPure]
@[simp] theorem not_isPure_request (query : Request) (next : Term → Result α) :
    ¬ IsPure (.request query next) := by simp [IsPure]

end Result

-- Receives validate their timeout before making a request.
@[simp↓] theorem ReceiveTimeout.ofTerm_pure (timeout : Term) :
    Result.IsPure (ReceiveTimeout.ofTerm timeout) := by
  cases timeout <;> simp [ReceiveTimeout.ofTerm] <;>
    split <;> simp_all <;> split <;> simp_all

namespace Result

/-- Prove a shared fallthrough once, then reason about both bodies with related
abstract continuations instead of copying the fallthrough into every branch. -/
theorem rel_shared (rel : Result α → Result α → Prop)
    (leftNext rightNext : Unit → Result α)
    (leftBody rightBody : (Unit → Result α) → Result α)
    (next : ∀ token, rel (leftNext token) (rightNext token))
    (body : ∀ left right, (∀ token, rel (left token) (right token)) →
      rel (leftBody left) (rightBody right)) :
    rel (leftBody leftNext) (rightBody rightNext) :=
  body leftNext rightNext next

/-- Prove a shared continuation once, then use its purity throughout the body. -/
theorem IsPure.shared (next : α → Result β) (body : (α → Result β) → Result γ)
    (nextPure : ∀ value, IsPure (next value))
    (bodyPure : ∀ next, (∀ value, IsPure (next value)) → IsPure (body next)) :
    IsPure (body next) := bodyPure next nextPure

@[simp↓] theorem IsPure.handle (computation : Result α) (handler : Exception → Result α)
    (computationPure : IsPure computation) (handlerPure : ∀ exception, IsPure (handler exception)) :
    IsPure (Result.handle computation handler) := by
  cases computation <;> try (rename_i exception; cases exception)
  all_goals simp_all [IsPure, Result.handle]

@[simp↓] theorem IsPure.bind (computation : Result α) (next : α → Result β)
    (computationPure : IsPure computation) (nextPure : ∀ value, IsPure (next value)) :
    IsPure (computation >>= next) := by
  change IsPure (Result.bind computation next)
  cases computation <;> simp_all [IsPure, Result.bind]

/-- The explicit bind spelling emitted by the translator has a separate simp index. -/
@[simp↓] theorem IsPure.bind_explicit (computation : Result α) (next : α → Result β)
    (computationPure : IsPure computation) (nextPure : ∀ value, IsPure (next value)) :
    IsPure (Result.bind computation next) :=
  IsPure.bind computation next computationPure nextPure

@[simp↓] theorem IsPure.tryWith (computation : Result α) (next : α → Result β)
    (handler : Exception → Result β) (protectedPure : IsPure computation)
    (nextPure : ∀ value, IsPure (next value))
    (handlerPure : ∀ exception, IsPure (handler exception)) :
    IsPure (Result.tryWith computation next handler) := by
  cases computation <;> try (rename_i exception; cases exception)
  all_goals simp_all [IsPure, Result.tryWith, Result.bind, Result.handle]

@[simp↓] theorem IsPure.orElse (left right : Result) (badbool : Bool) (leftPure : IsPure left)
    (rightPure : IsPure right) : IsPure (Result.orElse left right badbool) := by
  apply IsPure.bind_explicit _ _ leftPure
  intro value
  split <;> simp_all [IsPure]

@[simp↓] theorem IsPure.andAlso (left right : Result) (badbool : Bool) (leftPure : IsPure left)
    (rightPure : IsPure right) : IsPure (Result.andAlso left right badbool) := by
  apply IsPure.bind_explicit _ _ leftPure
  intro value
  split <;> simp_all [IsPure]

/-- A guard may read its process environment, but cannot modify it, schedule,
or make unresolved calls. Every environment read must eventually terminate. -/
@[expose] def IsReadOnly : Result α → Prop
  | .ok _ | .error _ => True
  | .get next => ∀ env, IsReadOnly (next env)
  | _ => False

@[simp↓] theorem IsPure.readOnly (computation : Result α) (pure : IsPure computation) :
    IsReadOnly computation := by
  cases computation <;> simp_all [IsPure, IsReadOnly]

@[simp] theorem isReadOnly_get (next : Environment → Result α) :
    IsReadOnly (.get next) ↔ ∀ env, IsReadOnly (next env) := Iff.rfl

@[simp↓] theorem IsReadOnly.bind (computation : Result α) (next : α → Result β)
    (readOnly : IsReadOnly computation) (nextReadOnly : ∀ value, IsReadOnly (next value)) :
    IsReadOnly (Result.bind computation next) := by
  induction computation with
  | get continuation ih =>
      exact fun env => ih env next (readOnly env) nextReadOnly
  | ok value => exact nextReadOnly value
  | error exception => trivial
  | _ =>
      exact False.elim readOnly

@[simp↓] theorem IsReadOnly.bind_monadic (computation : Result α) (next : α → Result β)
    (readOnly : IsReadOnly computation) (nextReadOnly : ∀ value, IsReadOnly (next value)) :
    IsReadOnly (computation >>= next) := IsReadOnly.bind computation next readOnly nextReadOnly

@[simp↓] theorem IsReadOnly.handle (computation : Result α) (handler : Exception → Result α)
    (readOnly : IsReadOnly computation) (handlerReadOnly : ∀ exception, IsReadOnly (handler exception)) :
    IsReadOnly (Result.handle computation handler) := by
  induction computation with
  | get continuation ih => exact fun env => ih env handler (readOnly env) handlerReadOnly
  | ok value => trivial
  | error exception =>
      cases exception
      all_goals first | trivial | exact handlerReadOnly _
  | _ =>
      exact False.elim readOnly

@[simp↓] theorem IsReadOnly.tryWith (computation : Result α) (next : α → Result β)
    (handler : Exception → Result β) (readOnly : IsReadOnly computation)
    (nextReadOnly : ∀ value, IsReadOnly (next value))
    (handlerReadOnly : ∀ exception, IsReadOnly (handler exception)) :
    IsReadOnly (Result.tryWith computation next handler) := by
  unfold Result.tryWith
  apply IsReadOnly.bind
  · apply IsReadOnly.handle
    · apply IsReadOnly.bind computation _ readOnly
      intro value
      trivial
    · intro exception
      trivial
  · intro reply
    cases reply with
    | ok value => exact nextReadOnly value
    | error exception => exact handlerReadOnly exception

@[simp↓] theorem IsReadOnly.orElse (left right : Result) (badbool : Bool)
    (leftReadOnly : IsReadOnly left) (rightReadOnly : IsReadOnly right) :
    IsReadOnly (Result.orElse left right badbool) := by
  apply IsReadOnly.bind _ _ leftReadOnly
  intro value
  split <;> simp_all

@[simp↓] theorem IsReadOnly.andAlso (left right : Result) (badbool : Bool)
    (leftReadOnly : IsReadOnly left) (rightReadOnly : IsReadOnly right) :
    IsReadOnly (Result.andAlso left right badbool) := by
  apply IsReadOnly.bind _ _ leftReadOnly
  intro value
  split <;> simp_all

/-- Evaluate a proven read-only computation without invoking the scheduler. -/
@[expose] def toExceptRead (computation : Result α) (env : Environment)
    (readOnly : IsReadOnly computation) : Except Exception α :=
  match computation with
  | .ok value => .ok value
  | .error exception => .error exception
  | .get next => toExceptRead (next env) env (readOnly env)
  | .set .. | .schedule .. | .send .. | .receive .. | .request .. =>
      False.elim readOnly

@[simp] theorem ok_bind (value : α) (next : α → Result β) :
    (Result.ok value >>= next) = next value := by rfl
@[simp] theorem error_bind (exception : Exception) (next : α → Result β) :
    (Result.error exception >>= next) = .error exception := by rfl

@[simp] theorem get_bind (continuation : Environment → Result α) (next : α → Result β) :
    (Result.get continuation >>= next) =
      .get (fun env => continuation env >>= next) := by rfl
@[simp] theorem set_bind (env : Environment) (continuation : Result α)
    (next : α → Result β) :
    (Result.set env continuation >>= next) = .set env (continuation >>= next) := by rfl
@[simp] theorem schedule_bind (options : SpawnOptions) (child : Result Term)
    (continuation : PID → Result α) (next : α → Result β) :
    (Result.schedule options child continuation >>= next) =
      Result.schedule options child (fun pid => continuation pid >>= next) := by rfl

@[simp] theorem request_bind (query : Request) (continuation : Term → Result α)
    (next : α → Result β) :
    (Result.request query continuation >>= next) =
      .request query (fun reply => continuation reply >>= next) := rfl

@[simp] theorem send_bind (pid : PID) (message : Term) (continuation : Result α)
    (next : α → Result β) :
    (Result.send pid message continuation >>= next) =
      .send pid message (continuation >>= next) := rfl

@[simp] theorem receive_bind (timeout : ReceiveTimeout) (select : Environment → Term → Option γ)
    (continuation : Option γ → Result α) (next : α → Result β) :
    (Result.receive timeout select continuation >>= next) =
      .receive timeout select (fun reply => continuation reply >>= next) := rfl

@[simp] theorem throw_eq (exception : Exception) :
    (throw exception : Result α) = .error exception := rfl

end Result

end Lynx

namespace Lynx.Term

/-- Executable implementation of a function term. Arguments use a Lean array,
avoiding Erlang-list encoding at internal call sites. -/
public abbrev Fun := Array Term → Result

/-- Completed pure calls cannot contain runtime requests. -/
public abbrev PureFun := Array Term → Except Exception Term

end Lynx.Term

namespace Lynx

/-- Calls function values through the program table. Translated definitions that
are not pure receive it as their first parameter, so calls to function values
are ordinary calls rather than runtime requests. -/
public structure Dispatcher where
  /-- Call from a computation returning `Except`. Entries that are not pure apart
  from their own calls to function values do not return. -/
  pure : Term → Array Term → Except Exception Term
  /-- Call from a computation returning `Result`. -/
  call : Term → Array Term → Result Term
  /-- The function value named `Module:Name/Arity`, when the program has one. -/
  resolve : Term → Term → Nat → Option Term := fun _ _ _ => none
  /-- The dispatcher one call depth down, which receives run with, or `none`
  once the depth is exhausted. Recursion through a receive decreases it. -/
  inner : Option Dispatcher := none

end Lynx

namespace Lynx.Term

/-- Purity is enforced by the callable's return type, rather than a boolean.
Entries that dispatch further receive the dispatcher for the remaining call depth.
Each entry receives the captured values before the invocation arguments. -/
public inductive FunEntry where
  | pure (body : Array Term → PureFun)
  /-- Pure apart from calling function values. -/
  | apply (body : Dispatcher → Array Term → PureFun)
  | effectful (body : Dispatcher → Array Term → Fun)

/-- A function of the program, named by the module, name, and arity the
compiler gave it, which function values name. -/
public structure FunDef where
  module : String
  name : String
  arity : Nat
  entry : FunEntry

/-- The program's functions, sorted by their names. -/
public abbrev FunTable := List FunDef

end Lynx.Term

namespace Lynx.Result

/-- Embed a completed call in a resumable computation. -/
@[expose] public def ofExcept (reply : Except Exception α) : Result α :=
  match reply with
  | .ok value => .ok value
  | .error exception => .error exception

/-- Extract a completed call using a kernel-checked purity proof. -/
@[expose] public def toExcept (computation : Result α) (pure : IsPure computation) : Except Exception α :=
  match computation with
  | .ok value => .ok value
  | .error exception => .error exception
  | .get .. | .set .. | .schedule .. | .send .. | .receive .. | .request .. => False.elim pure

/-- Read-only evaluation agrees with pure extraction when there are no reads. -/
@[simp] public theorem toExceptRead_pure (computation : Result α) (env : Environment)
    (readOnly : IsReadOnly computation) (pure : IsPure computation) :
    toExceptRead computation env readOnly = toExcept computation pure := by
  cases computation <;> first | rfl | exact False.elim pure

/-- Embedding a completed pure call preserves its result, including exceptions. -/
@[simp] public theorem ofExcept_toExcept (computation : Result α) (pure : IsPure computation) :
    ofExcept (toExcept computation pure) = computation := by
  cases computation <;> first | rfl | exact False.elim pure

end Lynx.Result
