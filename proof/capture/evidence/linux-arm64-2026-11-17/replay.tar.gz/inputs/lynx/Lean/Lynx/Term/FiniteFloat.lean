module

import Lynx.Term.FiniteFloat.Rounding

namespace Lynx.Term

/-- A finite IEEE binary64 value, stored in its canonical encoded fields.
Exponent 2047 is reserved for infinities and NaNs and is unrepresentable here. -/
public structure FiniteFloat where
  negative : Bool
  exponent : Fin 2047
  fraction : Fin (2 ^ 52)
deriving DecidableEq, Repr

namespace FiniteFloat

private def toModel (value : FiniteFloat) : Float.Model :=
  Float.Model.ofBits (UInt64.ofNat
    ((if value.negative then 2 ^ 63 else 0) +
      value.exponent.val * 2 ^ 52 + value.fraction.val))

/-- Exponent 2047 rejects both infinities and NaNs. -/
private def ofModel (value : Float.Model) : Option FiniteFloat :=
  let bits := value.toBits.toNat
  let exponent := bits / 2 ^ 52 % 2048
  if h : exponent < 2047 then
    some ⟨bits / 2 ^ 63 != 0, ⟨exponent, h⟩,
      ⟨bits % 2 ^ 52, Nat.mod_lt _ (by decide)⟩⟩
  else none

/-- Convert with binary64 rounding, failing if the integer overflows. -/
@[expose] public def ofInt (value : Int) : Option FiniteFloat :=
  let bits := (Float.Model.ofInt value).toBits.toNat
  let exponent := bits / 2 ^ 52 % 2048
  if h : exponent < 2047 then
    some ⟨bits / 2 ^ 63 != 0, ⟨exponent, h⟩,
      ⟨bits % 2 ^ 52, Nat.mod_lt _ (by decide)⟩⟩
  else none

/-- IEEE binary16, which Lean's float model does not predefine. -/
public abbrev binary16 : Float.Model.Format where
  mantissaBitsWithoutImplicit := 10
  exponentBits := 5

/-- Round to the encoding of a narrower IEEE format, to nearest with ties to
even. Values beyond the format's range overflow to infinity. -/
@[expose] public def narrow (spec : Float.Model.Format) (value : FiniteFloat) : Nat :=
  let sign : Float.Model.UnpackedFloat.Sign := if value.negative then .negative else .positive
  let rounded : Float.Model.UnpackedFloat :=
    if value.exponent.val = 0 then
      if value.fraction.val = 0 then .zero sign
      else .round spec sign value.fraction.val (-1074)
    else .round spec sign (2 ^ 52 + value.fraction.val) (Int.ofNat value.exponent.val - 1075)
  (Float.Model.UnpackedFloat.pack spec rounded).toNat

/-- Round an integer directly to the encoding of an IEEE format, overflowing to
infinity. Zero is positive. -/
@[expose] public def narrowInt (spec : Float.Model.Format) (value : Int) : Nat :=
  (Float.Model.UnpackedFloat.pack spec (.ofInt spec value)).toNat

/-- Convert an encoding of a narrower IEEE format exactly to binary64, failing
on infinities and NaNs. -/
@[expose] public def widen (spec : Float.Model.Format) (bits : Nat) : Option FiniteFloat :=
  let unpacked := Float.Model.UnpackedFloat.unpack spec (BitVec.ofNat _ bits)
  let packed : Option Float.Model.UnpackedFloat := match unpacked with
    | .zero sign => some (.zero sign)
    | .finite sign mantissa exponent _ => some (.round .binary64 sign mantissa exponent)
    | _ => none
  packed.bind fun packed =>
    let bits := (Float.Model.UnpackedFloat.pack .binary64 packed).toNat
    let exponent := bits / 2 ^ 52 % 2048
    if h : exponent < 2047 then
      some ⟨bits / 2 ^ 63 != 0, ⟨exponent, h⟩,
        ⟨bits % 2 ^ 52, Nat.mod_lt _ (by decide)⟩⟩
    else none

/-- Round `mantissa * 10 ^ exponent` to binary64 with the given sign, failing on
overflow. -/
public def ofScientific (negative : Bool) (mantissa : Nat) (exponent : Int) :
    Option FiniteFloat :=
  let value := Float.Model.ofScientific mantissa exponent
  ofModel (if negative then value.neg else value)

/-- IEEE binary64 addition, failing on any non-finite result. -/
public def add (left right : FiniteFloat) : Option FiniteFloat :=
  ofModel (left.toModel + right.toModel)

/-- IEEE binary64 multiplication, failing on any non-finite result. -/
public def mul (left right : FiniteFloat) : Option FiniteFloat :=
  ofModel (left.toModel * right.toModel)

/-- Multiplying a float by one below one in magnitude, that is, with a biased
exponent below 1023, never overflows. -/
public theorem mul_isSome (left right : FiniteFloat) (small : right.exponent.val < 1023) :
    (left.mul right).isSome := by
  have bits (value : FiniteFloat) :
      (UInt64.ofNat ((if value.negative then 2 ^ 63 else 0) + value.exponent.val * 2 ^ 52 +
        value.fraction.val)).toNat / 2 ^ 52 % 2048 = value.exponent.val := by
    have := value.exponent.isLt
    have := value.fraction.isLt
    simp only [UInt64.toNat_ofNat']
    split <;> omega
  have finite := Rounding.ofBits_mul_finite _ _
    (by rw [bits]; exact left.exponent.isLt) (by rw [bits]; exact small)
  simp only [mul, ofModel, toModel]
  simp only [finite, ↓reduceDIte, Option.isSome_some]

/-- IEEE binary64 subtraction, failing on any non-finite result. -/
public def sub (left right : FiniteFloat) : Option FiniteFloat :=
  ofModel (left.toModel - right.toModel)

/-- IEEE binary64 division, failing on zero divisors and non-finite results. -/
public def div (left right : FiniteFloat) : Option FiniteFloat :=
  ofModel (left.toModel / right.toModel)

/-- The nonnegative mathematical magnitude of a finite binary64 value. -/
@[expose] public def magnitude (value : FiniteFloat) : Rat :=
  if value.exponent.val = 0 then
    if value.fraction.val = 0 then 0
    else (value.fraction.val : Rat) * (2 : Rat) ^ (-1074 : Int)
  else
    ((2 ^ 52 + value.fraction.val : Nat) : Rat) *
      (2 : Rat) ^ (Int.ofNat value.exponent.val - 1075)

/-- The exact mathematical value represented by this binary64 encoding.
Positive and negative zero have the same value but remain distinct structures. -/
@[expose] public def toRat (value : FiniteFloat) : Rat :=
  if value.negative then -value.magnitude else value.magnitude

@[simp] public theorem toRat_zero (negative : Bool) :
    toRat ⟨negative, 0, 0⟩ = 0 := by
  cases negative <;> rfl

public theorem toRat_eq_zero (value : FiniteFloat) :
    value.toRat = 0 ↔ value.exponent.val = 0 ∧ value.fraction.val = 0 := by
  have magnitude_zero : value.magnitude = 0 ↔ value.exponent.val = 0 ∧ value.fraction.val = 0 := by
    by_cases exp0 : value.exponent.val = 0
    · by_cases frac0 : value.fraction.val = 0
      · simp [Lynx.Term.FiniteFloat.magnitude, exp0, frac0]
      · have nonzero : (value.fraction.val : Rat) * (2 : Rat) ^ (-1074 : Int) ≠ 0 :=
          Rat.ne_of_gt (Rat.mul_pos (Rat.natCast_pos.mpr (by omega)) (Rat.zpow_pos (by decide)))
        simp only [Lynx.Term.FiniteFloat.magnitude, ite_eq_left exp0, ite_eq_right frac0]
        exact ⟨fun h => False.elim (nonzero h), fun h => False.elim (frac0 h.2)⟩
    · have nonzero : ((2 ^ 52 + value.fraction.val : Nat) : Rat) *
          (2 : Rat) ^ ((value.exponent.val : Int) - 1075) ≠ 0 :=
        Rat.ne_of_gt (Rat.mul_pos (Rat.natCast_pos.mpr (by omega)) (Rat.zpow_pos (by decide)))
      simp only [Lynx.Term.FiniteFloat.magnitude, ite_eq_right exp0]
      exact ⟨fun h => False.elim (nonzero h), fun h => False.elim (exp0 h.1)⟩
  unfold Lynx.Term.FiniteFloat.toRat
  cases hn : value.negative
  · simpa only [hn, Bool.false_eq_true, ↓reduceIte] using magnitude_zero
  · simp only [↓reduceIte]
    have neg_zero : -value.magnitude = 0 ↔ value.magnitude = 0 := by
      constructor
      · intro h
        have := congrArg Neg.neg h
        simpa only [Rat.neg_neg, Rat.neg_zero] using this
      · intro h; rw [h, Rat.neg_zero]
    exact neg_zero.trans magnitude_zero

/-- A binary64 value with no fractional bit positions represents an integer. -/
public theorem toRat_integral_of_exponent (value : FiniteFloat) (large : 1075 ≤ value.exponent.val) :
    ∃ n : Int, value.toRat = (n : Rat) := by
  let n : Nat := (2 ^ 52 + value.fraction.val) * 2 ^ (value.exponent.val - 1075)
  have exp0 : value.exponent.val ≠ 0 := by omega
  have exponent : (value.exponent.val : Int) - 1075 = ((value.exponent.val - 1075 : Nat) : Int) := by omega
  have magnitude : value.magnitude = (n : Rat) := by
    simp [Lynx.Term.FiniteFloat.magnitude, exp0, exponent, n, Rat.natCast_mul,
      Rat.natCast_pow, Rat.zpow_natCast]
  cases sign : value.negative
  · exact ⟨n, by simp [Lynx.Term.FiniteFloat.toRat, sign, magnitude, Rat.intCast_natCast]⟩
  · exact ⟨-(n : Int), by simp [Lynx.Term.FiniteFloat.toRat, sign, magnitude, Rat.intCast_natCast, Rat.intCast_neg]⟩

private theorem ofModel_bits {value : Float.Model} {n : Nat} (bits : value.toBits.toNat = n)
    (finite : n / 2 ^ 52 % 2048 < 2047) :
    ofModel value = some ⟨n / 2 ^ 63 != 0, ⟨n / 2 ^ 52 % 2048, finite⟩,
      ⟨n % 2 ^ 52, Nat.mod_lt _ (by decide)⟩⟩ := by
  unfold ofModel
  simp only [bits]
  rw [dite_eq_left finite]

/-- Converting `mantissa * 10 ^ exponent` depends only on its value. -/
public theorem ofScientific_congr {negative : Bool} {m₁ m₂ : Nat} {e₁ e₂ : Int}
    (h : (m₁ : Rat) * 10 ^ e₁ = m₂ * 10 ^ e₂) :
    ofScientific negative m₁ e₁ = ofScientific negative m₂ e₂ := by
  simp only [ofScientific, Rounding.model_ofScientific_congr h]

/-- A negative sign negates the converted value. -/
public theorem ofScientific_neg {m : Nat} {e : Int} {value : FiniteFloat}
    (h : ofScientific false m e = some value) :
    ofScientific true m e = some { value with negative := !value.negative } := by
  simp only [ofScientific, Bool.false_eq_true, ite_false, ite_true] at h ⊢
  generalize Float.Model.ofScientific m e = model at h ⊢
  have lt := model.toBits.toNat_lt
  generalize bits : model.toBits.toNat = n at lt
  by_cases finite : n / 2 ^ 52 % 2048 < 2047
  · rw [ofModel_bits bits finite] at h
    cases h
    have neg := Rounding.toNat_neg model (by rw [bits]; exact finite)
    rw [bits] at neg
    rw [ofModel_bits neg (by omega)]
    simp only [Option.some.injEq, FiniteFloat.mk.injEq]
    refine ⟨?_, Fin.ext (by simp; omega), Fin.ext (by simp; omega)⟩
    by_cases high : n / 2 ^ 63 = 0
    · have : (n + 2 ^ 63) % 2 ^ 64 / 2 ^ 63 = 1 := by omega
      simp [this, high]
    · have : (n + 2 ^ 63) % 2 ^ 64 / 2 ^ 63 = 0 := by omega
      simp [this, high]
  · unfold ofModel at h
    simp only [bits] at h
    rw [dite_eq_right finite] at h
    cases h

/-- Converting the exact value of a finite float gives the float back. -/
public theorem ofScientific_magnitude (value : FiniteFloat) {m : Nat} {e : Int}
    (h : (m : Rat) * 10 ^ e = value.magnitude) : ofScientific value.negative m e = some value := by
  obtain ⟨negative, ⟨exponent, elt⟩, ⟨fraction, flt⟩⟩ := value
  have positive : ofScientific false m e = some ⟨false, ⟨exponent, elt⟩, ⟨fraction, flt⟩⟩ := by
    simp only [ofScientific, Bool.false_eq_true, ite_false]
    simp only [magnitude] at h
    by_cases e0 : exponent = 0
    · subst e0
      by_cases f0 : fraction = 0
      · subst f0
        simp only [ite_true] at h
        have m0 : m = 0 := by
          have p : (0 : Rat) < 10 ^ e := Rat.zpow_pos (by decide)
          rcases Rat.mul_eq_zero.mp h with z | z
          · exact_mod_cast z
          · exact absurd z (Rat.ne_of_gt p)
        subst m0
        rw [ofModel_bits (Rounding.toNat_ofScientific_zero e) (by decide)]
        rfl
      · simp only [ite_true, ite_eq_right f0] at h
        rw [ofModel_bits (Rounding.toNat_ofScientific_subnormal (by omega) flt h) (by omega)]
        simp only [Option.some.injEq, FiniteFloat.mk.injEq]
        refine ⟨by simp; omega, Fin.ext (by simp; omega), Fin.ext (by simp; omega)⟩
    · simp only [ite_eq_right e0] at h
      have toNat := Rounding.toNat_ofScientific_normal (F := 2 ^ 52 + fraction)
        (E := (exponent : Int) - 1075) (by omega) (by omega) (by omega) (by omega) h
      rw [ofModel_bits toNat (by omega)]
      simp only [Option.some.injEq, FiniteFloat.mk.injEq]
      refine ⟨by simp; omega, Fin.ext (by simp; omega), Fin.ext (by simp; omega)⟩
  cases negative
  · exact positive
  · exact ofScientific_neg positive

end FiniteFloat
end Lynx.Term
