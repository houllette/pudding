module

public import Lynx.Term.DataTypes

namespace Lynx

/-- Structural induction derived from `Term.rec`, with hypotheses for cons heads
and tails, closure captures, tuple elements, and both keys and values of every
stored map binding. Map hypotheses concern raw entries, including shadowed ones. -/
@[induction_eliminator] public protected theorem Term.induct {motive : Term → Prop} (t : Term)
    (integer : ∀ n, motive (.integer n))
    (float : ∀ n, motive (.float n))
    (atom : ∀ s, motive (.atom s))
    (reference : ∀ id, motive (.reference id))
    (function : ∀ module name arity captures, (∀ x ∈ captures, motive x) →
      motive (.function module name arity captures))
    (pid : ∀ pid, motive (.pid pid))
    (tuple : ∀ xs, (∀ x ∈ xs, motive x) → motive (.tuple xs))
    (map : ∀ entries, (∀ k v, (k, v) ∈ entries → motive k ∧ motive v) →
      motive (.map entries))
    (nil : motive .nil)
    (cons : ∀ x xs, motive x → motive xs → motive (.cons x xs))
    (bitstring : ∀ bytes lastBits (valid : Term.Bitstring.Valid bytes lastBits),
      motive (.bitstring bytes lastBits valid)) : motive t := by
  refine Term.rec (motive_2 := fun xs => ∀ x ∈ xs, motive x)
    (motive_3 := fun entries => ∀ k v, (k, v) ∈ entries → motive k ∧ motive v)
    (motive_4 := fun xs => ∀ x ∈ xs, motive x)
    (motive_5 := fun entry => motive entry.1 ∧ motive entry.2)
    integer float atom reference function pid tuple map nil cons bitstring ?_ ?_ ?_ ?_ ?_ ?_ t
  · intro xs ih x hx
    exact ih x (by simpa using hx)
  · simp
  · intro entry entries ih ihs k v h
    rcases List.mem_cons.mp h with h | h
    · cases h; exact ih
    · exact ihs k v h
  · simp
  · intro x xs ihx ihxs y hy
    rcases List.mem_cons.mp hy with rfl | hy
    · exact ihx
    · exact ihxs y hy
  · intro k v hk hv; exact ⟨hk, hv⟩

end Lynx
