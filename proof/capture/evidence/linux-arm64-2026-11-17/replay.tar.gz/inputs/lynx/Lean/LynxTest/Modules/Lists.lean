module

import Lynx.Modules.Erlang.lists
meta import LynxTest.ProofAudit

namespace LynxTest.Modules.Lists
open Lynx Erlang.lists

theorem reverse_empty (tail : Term) : «reverse/2» .nil tail = .ok tail := rfl

theorem reverse_onto_tail (a b tail : Term) :
    «reverse/2» (.cons a (.cons b .nil)) tail = .ok (.cons b (.cons a tail)) := by
  simp [«reverse/2»]

theorem reverse_improper (a tail : Term) :
    «reverse/2» (.cons a (.atom "improper")) tail = .error (.error (.atom "badarg")) := by
  simp [«reverse/2»]

theorem keymember_finds_tuples :
    «keymember/3» (.atom "b") (.integer 1)
        (.cons (.atom "skipped") (.cons (.tuple #[.atom "b", .integer 2]) .nil)) = .ok Term.true ∧
    «keymember/3» (.atom "c") (.integer 1) (.cons (.tuple #[.atom "a"]) .nil) = .ok Term.false ∧
    «keymember/3» (.atom "c") (.integer 0) .nil = .error (.error (.atom "badarg")) := by
  refine ⟨?_, ?_, ?_⟩ <;> cbv

theorem reverse_non_list (tail : Term) :
    «reverse/2» (.integer 1) tail = .error (.error (.atom "badarg")) := rfl

theorem member_found (a : Term) :
    «member/2» (.atom "b") (.cons a (.cons (.atom "b") (.atom "improper"))) = .ok Term.true := by
  cases a <;> simp [«member/2»]

private def floatOne : Term.FiniteFloat :=
  ⟨false, 1023, 0⟩

/-- Membership uses exact equality, so an integer does not match an equal float. -/
theorem member_exact :
    «member/2» (.integer 1) (.cons (.float floatOne) .nil) = .ok Term.false := by
  simp [«member/2»]

theorem member_improper :
    «member/2» (.atom "c") (.cons (.atom "a") (.atom "b")) = .error (.error (.atom "badarg")) := by
  simp [«member/2»]

theorem member_non_list :
    «member/2» (.atom "a") (.atom "foo") = .error (.error (.atom "badarg")) := rfl

run_cmd do
  LynxTest.ProofAudit.checkModule `Lynx.Modules.Erlang.lists
  LynxTest.ProofAudit.checkModule `LynxTest.Modules.Lists

end LynxTest.Modules.Lists
