module

import Lynx.Modules.Erlang.maps
import Lynx.Modules.Erlang.erlang
meta import LynxTest.ProofAudit
import Lynx
import all Lynx.Term.Compare
import all Std
import all Init.Data.List.Basic
import all Init.Data.List.Control
import all Init.Data.Ord.String

namespace LynxTest.Modules.Maps
open Lynx

theorem get_after_put (m k v : Term)
    (hm : ∃ entries, m = .map entries) :
    (Erlang.maps.«put/3» k v m >>= Erlang.maps.«get/2» k) = .ok v := by
  exact Erlang.maps.get_after_put m k v hm

theorem merge_associative (a b c : Term)
    (ha : ∃ entries, a = .map entries) (hb : ∃ entries, b = .map entries) (hc : ∃ entries, c = .map entries) :
    (Erlang.maps.«merge/2» a b >>= fun ab => Erlang.maps.«merge/2» ab c) =
    (Erlang.maps.«merge/2» b c >>= Erlang.maps.«merge/2» a) := by
  exact Erlang.maps.merge_associative a b c ha hb hc

private def a : Term := .atom "a"
private def b : Term := .atom "b"
private def one : Term := .integer 1
private def two : Term := .integer 2
private def floatOne : Term.FiniteFloat :=
  ⟨false, 1023, 0⟩

theorem new_and_get :
    Erlang.maps.«new/0» = .ok (Term.map []) ∧
    Erlang.maps.«get/2» a (.map [(a, one)]) = .ok one := by
  repeat' first | apply And.intro | rfl

theorem missing_key (key : Term) :
    Erlang.maps.«get/2» key (Term.map []) = .error (.error (.tuple #[.atom "badkey", key])) := rfl

theorem numeric_key_types_are_distinct :
    Erlang.maps.«get/2» (.integer 1) (.map [(.float floatOne, a)]) =
      .error (.error (.tuple #[.atom "badkey", .integer 1])) ∧
    Erlang.maps.«get/2» (.float floatOne) (.map [(.integer 1, a)]) =
      .error (.error (.tuple #[.atom "badkey", .float floatOne])) := by
  exact ⟨rfl, rfl⟩

theorem put_overwrites :
    (Erlang.maps.«put/3» a one (Term.map []) >>= Erlang.maps.«put/3» a two) = .ok (.map [(a, two), (a, one)]) := by
  repeat' first | apply And.intro | rfl

theorem merge_bindings :
    Erlang.maps.«merge/2» (.map [(a, one)]) (.map [(b, two)]) = .ok (.map [(b, two), (a, one)]) ∧
    Erlang.maps.«merge/2» (.map [(a, one)]) (.map [(a, two)]) = .ok (.map [(a, two), (a, one)]) ∧
    Erlang.maps.«merge/2» (.map [(a, two)]) (.map [(a, one)]) = .ok (.map [(a, one), (a, two)]) := by
  repeat' first | apply And.intro | rfl

/-- Only nonmaps raise badmap, preserving the offending argument. -/
theorem bad_maps : ∀ bad ∈ [one, .nil, .tuple #[]],
    Erlang.maps.«get/2» a bad = .error (.error (.tuple #[.atom "badmap", bad])) ∧
    Erlang.maps.«put/3» a one bad = .error (.error (.tuple #[.atom "badmap", bad])) ∧
    Erlang.maps.«merge/2» bad (Term.map []) = .error (.error (.tuple #[.atom "badmap", bad])) ∧
    Erlang.maps.«merge/2» (Term.map []) bad = .error (.error (.tuple #[.atom "badmap", bad])) := by
  intro bad h
  simp only [List.mem_cons, List.not_mem_nil, or_false] at h
  rcases h with rfl | rfl | rfl <;> simp [Erlang.maps.«get/2», Erlang.maps.«put/3», Erlang.maps.«merge/2», one]

theorem update_existing :
    Erlang.maps.«update/3» a two (.map [(a, one)]) = .ok (.map [(a, two), (a, one)]) := rfl

theorem update_missing (key value : Term) :
    Erlang.maps.«update/3» key value (.map []) =
      .error (.error (.tuple #[.atom "badkey", key])) := rfl

theorem update_numeric_keys :
    Erlang.maps.«update/3» (.integer 1) two (.map [(.float floatOne, one)]) =
      .error (.error (.tuple #[.atom "badkey", .integer 1])) := rfl

theorem mixed_same_key :
    (Erlang.maps.«put/3» a one (.map []) >>= Erlang.maps.«update/3» a two) =
      .ok (.map [(a, two), (a, one)]) ∧
    (Erlang.maps.«update/3» a one (.map []) >>= Erlang.maps.«put/3» a two) =
      .error (.error (.tuple #[.atom "badkey", a])) := ⟨rfl, rfl⟩

theorem update_badmap (n : Int) :
    Erlang.maps.«update/3» a one (.integer n) =
      .error (.error (.tuple #[.atom "badmap", .integer n])) := rfl

theorem update_lookup (m key value old : Term)
    (present : Erlang.maps.«get/2» key m = .ok old) :
    (Erlang.maps.«update/3» key value m >>= Erlang.maps.«get/2» key) = .ok value :=
  Erlang.maps.get_after_update m key value old present

theorem update_other_lookup (entries : List (Term × Term)) (key other value old : Term)
    (present : Erlang.maps.«get/2» key (.map entries) = .ok old)
    (distinct : Term.compareExact (Term.fuel other key) other key ≠ .eq) :
    (Erlang.maps.«update/3» key value (.map entries) >>= Erlang.maps.«get/2» other) =
      Erlang.maps.«get/2» other (.map entries) :=
  Erlang.maps.get_after_update_other entries key other value old present distinct

theorem is_map_guard (entries : List (Term × Term)) :
    Erlang.erlang.«is_map/1» (.map entries) = .ok Term.true ∧
    Erlang.erlang.«is_map/1» one = .ok Term.false := ⟨rfl, rfl⟩

/-- Later pairs shadow earlier ones; anything but a proper list of pairs is badarg. -/
theorem from_list_pairs :
    Erlang.maps.«from_list/1» .nil = .ok (.map []) ∧
    (Erlang.maps.«from_list/1» (.cons (.tuple #[a, one]) (.cons (.tuple #[a, two]) .nil)) >>=
      Erlang.maps.«get/2» a) = .ok two ∧
    Erlang.maps.«from_list/1» (.cons (.tuple #[a, one]) one) = .error (.error (.atom "badarg")) ∧
    Erlang.maps.«from_list/1» (.cons (.tuple #[a]) .nil) = .error (.error (.atom "badarg")) ∧
    Erlang.maps.«from_list/1» one = .error (.error (.atom "badarg")) := by
  repeat' first | apply And.intro | rfl

/-- Map enumeration has no specified order, but keeps each visible binding once. -/
theorem enumeration_lookup (entries : List (Term × Term)) (key : Term) :
    Term.mapLookup (Term.mapEntries entries) key = Term.mapLookup entries key ∧
    (Term.mapEntries entries).Pairwise (fun x y => Term.compareExact (Term.fuel x.1 y.1) x.1 y.1 ≠ .eq) :=
  ⟨Term.mapLookup_mapEntries entries key, Term.mapEntries_distinct entries⟩

theorem enumeration_shadowed :
    Term.mapLookup (Term.mapEntries [(a, two), (a, one)]) a = some two := by
  rw [Term.mapLookup_mapEntries]
  rfl

/-- Listing a map yields its visible bindings as pairs. -/
theorem to_list_pairs (entries : List (Term × Term)) :
    Erlang.maps.«to_list/1» (.map entries) =
      .ok (Term.list ((Term.mapEntries entries).map fun entry => .tuple #[entry.1, entry.2])) ∧
    Erlang.maps.«to_list/1» (Term.map []) = .ok .nil ∧
    Erlang.maps.«to_list/1» one = .error (.error (.tuple #[.atom "badmap", one])) :=
  ⟨rfl, by simp [Erlang.maps.«to_list/1»], rfl⟩

private def folder : Term := .function "test" "fold" 3 #[]

private def fold : Term → Term → Term → Except Exception Term :=
  Erlang.maps.«fold/3» (Dispatcher.ofTable [] 0)

theorem fold_inputs :
    fold folder one (Term.map []) = .ok one ∧
    fold folder one .nil = .ok one ∧
    fold folder one (.atom "none") = .ok one ∧
    fold folder one one = .error (.error (.tuple #[.atom "badmap", one])) ∧
    fold (.function "test" "fold" 2 #[]) one (Term.map []) = .error (.error (.atom "badarg")) := by
  refine ⟨?_, rfl, rfl, rfl, rfl⟩
  simp [fold, Erlang.maps.«fold/3», folder]

/-- Iterators list the visible bindings as `to_list/1` does, and each step
returns the remaining bindings. -/
theorem iterator_steps (entries : List (Term × Term)) :
    Erlang.maps.«iterator/1» (.map entries) = Erlang.maps.«to_list/1» (.map entries) ∧
    Erlang.maps.«next/1» (Term.list [.tuple #[a, one], .tuple #[b, two]]) =
      .ok (.tuple #[a, one, Term.list [.tuple #[b, two]]]) ∧
    Erlang.maps.«next/1» .nil = .ok (.atom "none") ∧
    Erlang.maps.«next/1» one = .error (.error (.atom "badarg")) ∧
    Erlang.maps.«iterator/1» one = .error (.error (.tuple #[.atom "badmap", one])) :=
  ⟨rfl, rfl, rfl, rfl, rfl⟩

/-- A single binding is enumerated as itself, so its iteration is determined. -/
theorem singleton_iteration (key value : Term) :
    (Erlang.maps.«iterator/1» (.map [(key, value)]) >>= Erlang.maps.«next/1») =
      .ok (.tuple #[key, value, .nil]) := by
  simp [Erlang.maps.«iterator/1», Erlang.maps.«next/1»]

/-- Pair lists simplify, so maps built from literal pairs reduce. -/
theorem from_literal_pairs (key value : Term) :
    Erlang.maps.«from_list/1» (Term.list [.tuple #[key, value]]) = .ok (.map [(key, value)]) := by
  simp [Erlang.maps.«from_list/1», Term.pairList?]

/-- Maps with bindings differ from the empty map and from atoms. -/
theorem nonempty_map_equality (key value : Term) :
    Erlang.erlang.«==/2» (.map [(key, value)]) (Term.map []) = .ok Term.false ∧
    Erlang.erlang.«==/2» (.map [(key, value)]) (.atom "term") = .ok Term.false := by
  simp [Erlang.erlang.«==/2», Term.false]

private def combiner : Term := .function "test" "fold" 3 #[]

private def mergeWith : Term → Term → Term → Except Exception Term :=
  Erlang.maps.«merge_with/3» (Dispatcher.ofTable [] 0)

private def intersectWith : Term → Term → Term → Except Exception Term :=
  Erlang.maps.«intersect_with/3» (Dispatcher.ofTable [] 0)

/-- Merging with an empty map calls no combiner, and arguments are checked
as on the BEAM: the combiner first, then each map. -/
theorem combine_inputs :
    mergeWith combiner (.map [(a, one)]) (Term.map []) = .ok (.map [(a, one)]) ∧
    intersectWith combiner (.map [(a, one)]) (Term.map []) = .ok (Term.map []) ∧
    mergeWith one (Term.map []) (Term.map []) = .error (.error (.atom "badarg")) ∧
    mergeWith combiner one (Term.map []) = .error (.error (.tuple #[.atom "badmap", one])) ∧
    intersectWith combiner (Term.map []) one = .error (.error (.tuple #[.atom "badmap", one])) := by
  refine ⟨?_, ?_, rfl, rfl, rfl⟩ <;> simp [mergeWith, intersectWith, Erlang.maps.«merge_with/3»,
    Erlang.maps.«intersect_with/3», combiner, List.reduceOption, Term.mapLookup]

end LynxTest.Modules.Maps

run_cmd do
  LynxTest.ProofAudit.checkModule `Lynx.Modules.Erlang.maps
  LynxTest.ProofAudit.checkModule `LynxTest.Modules.Maps
