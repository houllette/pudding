defmodule Lynx.Case do
  @moduledoc """
  Define callable laws alongside ExUnit tests.

  Add `use Lynx.Case` after `use ExUnit.Case`, then group laws to verify together:

      use ExUnit.Case, async: true
      use Lynx.Case

      laws "identity" do
        law identity(value), requires: value, expects: value,
          proof: ~LEAN"exact requires"
      end

  Each group registers one ExUnit test of type `:laws`. Run groups with
  `mix test --only laws`.

  Set `LYNX_DEBUG=lean` to print each translated module's reported
  verification time in milliseconds, status, and whether it was cached,
  as well as the elaboration time of any law. The translated .lean files are
  also written by module path to `tmp/<test module>/<group>/` for inspection.
  Set `LYNX_DEBUG=olean` to also write the compiled `.olean` files of every
  verified module next to its source, so Lean tools such as profilers can load
  the translated modules by adding the directory to `LEAN_PATH`.

  Set `LYNX_CACHE=0` to disable the verification cache.

  Lean's warnings and information messages are printed with their locations
  whenever a group verifies, including from cached results.

  Set `LYNX_EXPORT=dir` to write each group's elaborated declarations to
  `dir/<test module>/<group>.ndjson` for independent kernel checks, as
  described in `Lynx`. Exporting bypasses the verification cache.

  Lean's own environment variables reach the Lean processes that verify each group.
  For example, set `LEAN_NUM_THREADS=n` to elaborate the proofs of a translated
  module on at most `n` threads, instead of one per core. Groups verify
  concurrently, each in its own process with its own threads.
  """

  @lean_dir Path.expand("../../Lean", __DIR__)

  defmacro __using__(_opts) do
    quote do
      Lynx.Case.__register__(__MODULE__)

      import Lynx.Case,
        only: [
          law: 2,
          laws: 2,
          laws: 3,
          postlude: 1,
          termination_suffix: 2,
          termination_suffix: 3,
          cutoff: 1,
          dynamic: 1,
          prelude: 1
        ]

      import Lynx.Lean, only: [sigil_LEAN: 2]
    end
  end

  @doc false
  def __register__(module) do
    unless Module.has_attribute?(module, :ex_unit_tests) do
      raise ArgumentError, "you must Lynx.Case after use ExUnit.Case"
    end

    ExUnit.plural_rule("laws", "laws")

    # Retain bytecode before ExUnit's callback makes async tests runnable.
    callbacks = Module.delete_attribute(module, :after_compile)
    Module.put_attribute(module, :after_compile, __MODULE__)

    for callback <- Enum.reverse(callbacks) do
      Module.put_attribute(module, :after_compile, callback)
    end

    Module.put_attribute(module, :compile, :debug_info)
    Lynx.Laws.__register__(module)
  end

  @doc """
  Defines a callable law and includes it in the current laws group.

  The must be explicitly declared in a `laws/2` block.

  ## Options

    * `:requires` (optional) — the precondition expression. Defaults to `true`.
    * `:expects` (required) — the expression to prove.
    * `:proof` (optional) — a `Lynx.Lean` value. Defaults to `rfl`.

  ## Executable definition

  Besides defining a law, `law/2` also defines a public function that you can
  invoke passing Elixir values. Elixir will then validate said values against the
  given `:requires`, the given `:expects`, and return true when both predicates
  succeed, otherwise it will raise. This is useful to provide counter examples.
  """
  defmacro law(call, opts) do
    {name, definition} = Lynx.Laws.__law__(__CALLER__, call, opts)

    quote do
      Lynx.Case.__law__(__MODULE__, unquote(Macro.escape(name)))
      unquote(definition)
    end
  end

  @doc false
  def __law__(module, name) do
    case Module.get_attribute(module, :lynx_laws) do
      nil ->
        raise ArgumentError, "law must be defined inside a laws group"

      group_laws ->
        Module.put_attribute(module, :lynx_laws, [name | group_laws])
    end
  end

  @doc """
  Attaches a Lean termination suffix to a translated function for this laws group.

      termination_suffix &:calendar.mod/2, ~LEAN"partial_fixpoint"

  The source is a `Lynx.Lean` value. It is parsed as part of the function's
  declaration, after its body. The suffix does not change the function's purity
  (see the purity model in `Lynx`). With `partial_fixpoint`, inputs on which
  the function diverges raise `Lynx.Exception.exhausted`.
  Raises if the target function is not translated by the group's laws.

  Pass `recur: true` to also attach the suffix to the functions mutually
  recursive with the target that have no suffix of their own. Lean requires
  every function in a mutually recursive group to be a partial fixpoint once
  one of them is:

      termination_suffix &Module.Types.Descr.unfold/1, ~LEAN"partial_fixpoint", recur: true

  A function with `partial_fixpoint` also gets a `fixpoint_induct` principle,
  which proves properties of every successful return without a termination
  measure, as returns on divergent inputs never happen. For a pure function of
  `n` arguments, `Lynx.Except.admissible_returnsN` discharges its admissibility
  goal:

      apply «mod/2».fixpoint_induct
        (motive := fun f => ∀ a b v, f a b = .ok v → post a b v)
      · exact Lynx.Except.admissible_returns2 _
      · intro f ih a b v returned
        ...
  """
  defmacro termination_suffix(target, source, opts \\ []) do
    mfa =
      case target do
        {:&, _, [{:/, _, [{{:., _, [module, name]}, _, []}, arity]}]}
        when is_atom(name) and is_integer(arity) and arity >= 0 ->
          module = Macro.expand(module, __CALLER__)

          if not is_atom(module),
            do: raise(ArgumentError, "expected a module in termination_suffix")

          {module, name, arity}

        _ ->
          raise ArgumentError, "termination_suffix expects &Module.function/arity"
      end

    quote do
      Lynx.Case.__termination_suffix__(
        __MODULE__,
        unquote(Macro.escape(mfa)),
        unquote(source),
        unquote(opts)
      )
    end
  end

  @doc false
  def __termination_suffix__(module, {target, name, arity} = mfa, %Lynx.Lean{} = source, opts) do
    opts = Keyword.validate!(opts, recur: false)

    case Module.get_attribute(module, :lynx_termination_suffixes) do
      nil ->
        raise ArgumentError, "termination_suffix must be defined inside a laws group"

      suffixes ->
        if Map.has_key?(suffixes, mfa),
          do:
            raise(
              ArgumentError,
              "duplicate termination_suffix for #{Exception.format_mfa(target, name, arity)}"
            )

        Module.put_attribute(
          module,
          :lynx_termination_suffixes,
          Map.put(suffixes, mfa, {source, opts})
        )
    end
  end

  @doc ~S'''
  Adds Lean declarations to the prelude for this laws group.

      prelude ~LEAN"""
      module
      public import Lynx
      public section

      open Lean Elab Tactic
      elab "finish" : tactic => do evalTactic (← `(tactic| rfl))
      """

  Blocks are joined in order into one Lean module, so the first block begins
  with its header, such as `module` and its imports, which may include runtime
  modules like `Lynx.Modules.Erlang.erlang`. Later blocks continue the module.
  Every translated module imports the prelude before its proofs and termination
  suffixes are parsed, along with the prelude's public imports. Definitions,
  lemmas, macros, and elaborators may be declared; namespaces are chosen by the
  source. Meta helper definitions must use Lean's `meta` modifier as usual.

  The prelude cannot refer to translated definitions, which do not exist yet.
  It does not leak into other groups, and its source participates in verification
  cache keys. Proofs retain kernel checking and axiom audits.

  A file path may be given instead, relative to the directory of the calling
  file, to load its contents with `Lynx.Lean.from_file!/1`:

      prelude "tactics.lean"
  '''
  defmacro prelude(source) do
    quote do
      Lynx.Case.__prelude__(__MODULE__, unquote(source), __DIR__)
    end
  end

  @doc false
  def __prelude__(module, path, dir) when is_binary(path),
    do: __prelude__(module, Lynx.Lean.from_file!(Path.expand(path, dir)), dir)

  def __prelude__(module, %Lynx.Lean{} = source, _dir) do
    case Module.get_attribute(module, :lynx_preludes) do
      nil ->
        raise ArgumentError, "prelude must be defined inside a laws group"

      preludes ->
        Module.put_attribute(module, :lynx_preludes, [source | preludes])
    end
  end

  def __prelude__(_module, _source, _dir),
    do: raise(ArgumentError, "prelude expects a Lynx.Lean value or a file path")

  @doc ~S'''
  Adds Lean declarations about translated definitions to this laws group.

      postlude ~LEAN"""
      namespace MyTest

      theorem double_integer (n : Int) : «double/1» (.integer n) = .ok (.integer (n + n)) := by
        simp [«double/1»]

      end MyTest
      """

  Blocks are joined in order into one Lean module, which imports every module
  translated for the group, including the prelude, and which the laws import.
  Unlike preludes, postludes may refer to translated definitions, so they can
  share lemmas about the translated code between the proofs of several laws.
  Lynx writes the module header, so blocks contain only declarations, which are
  public and expose their bodies. Namespaces are chosen by the source: the
  test module's namespace, such as `MyTest` above, makes declarations available
  to law proofs without qualification.

  Postludes do not translate anything themselves: the laws must reach every
  definition they mention. They do not leak into other groups, and their source
  participates in verification cache keys. Proofs retain kernel checking and
  axiom audits.

  As with `prelude/1`, a file path may be given instead, relative to the
  directory of the calling file.
  '''
  defmacro postlude(source) do
    quote do
      Lynx.Case.__postlude__(__MODULE__, unquote(source), __DIR__)
    end
  end

  @doc false
  def __postlude__(module, path, dir) when is_binary(path),
    do: __postlude__(module, Lynx.Lean.from_file!(Path.expand(path, dir)), dir)

  def __postlude__(module, %Lynx.Lean{} = source, _dir) do
    case Module.get_attribute(module, :lynx_postludes) do
      nil ->
        raise ArgumentError, "postlude must be defined inside a laws group"

      postludes ->
        Module.put_attribute(module, :lynx_postludes, [source | postludes])
    end
  end

  def __postlude__(_module, _source, _dir),
    do: raise(ArgumentError, "postlude expects a Lynx.Lean value or a file path")

  @doc """
  Leaves a function untranslated in this laws group.

      cutoff &Float.invalid_precision_message/1

  The function's body becomes `Lynx.Except.cutoff`, which raises
  `Lynx.Exception.exhausted`: not a return value or an Erlang exception, and
  no handler catches it. A successful-return proof must establish that the
  cutoff is never reached. This supports proofs whose unreachable error paths
  depend on libraries outside the model; it makes no claim about executing those
  paths. The function remains pure (see the purity model in `Lynx`).

  Functions built into Lean cannot be cut off.
  """
  defmacro cutoff(target) do
    mfa = mfa!(target, "cutoff", __CALLER__)

    quote do
      Lynx.Case.__declare__(__MODULE__, :lynx_cutoffs, unquote(Macro.escape(mfa)))
    end
  end

  @doc """
  Declares a function that calls by name may reach in this laws group.

      dynamic &:erlang.apply/2

  Calls whose module or function is computed, such as `apply(mod, fun, args)`
  or `mod.fun(x)`, and computed references, such as `&mod.fun/1`, are resolved
  when the program runs. Lean cannot load code at that point, so they reach
  only the declared functions and those the program captures by name, such as
  `&Module.function/arity`. Calls to other functions raise
  `Lynx.Exception.exhausted`, like a `cutoff`, so a successful-return proof must
  establish that they are not reached. Declared functions are translated with
  the program.
  """
  defmacro dynamic(target) do
    mfa = mfa!(target, "dynamic", __CALLER__)

    quote do
      Lynx.Case.__declare__(__MODULE__, :lynx_dynamic, unquote(Macro.escape(mfa)))
    end
  end

  defp mfa!(target, macro, caller) do
    case target do
      {:&, _, [{:/, _, [{{:., _, [module, name]}, _, []}, arity]}]}
      when is_atom(name) and is_integer(arity) and arity >= 0 ->
        module = Macro.expand(module, caller)
        if not is_atom(module), do: raise(ArgumentError, "expected a module in #{macro}")
        {module, name, arity}

      _ ->
        raise ArgumentError, "#{macro} expects &Module.function/arity"
    end
  end

  @doc false
  def __declare__(module, attribute, mfa) do
    case Module.get_attribute(module, attribute) do
      nil ->
        macro = if attribute == :lynx_cutoffs, do: "cutoff", else: "dynamic"
        raise ArgumentError, "#{macro} must be defined inside a laws group"

      mfas ->
        Module.put_attribute(module, attribute, MapSet.put(mfas, mfa))
    end
  end

  @doc """
  Registers a group of laws as one ExUnit test.

  The test translates the laws and their callees, verifies their proofs,
  and fails if they do not pass.

  Each group has the `:laws` test type and tag. Run only law groups with
  `mix test --only laws`.

  ## Options

    * `:options` (optional) — a keyword list of Lean options, such as
      `[maxHeartbeats: 1_000_000, maxRecDepth: 10_000]`, set at the top of every
      translated module of the group, including its laws. Names are passed to
      Lean as given. Proofs remain kernel-checked.

  ## Example

      laws "checked" do
        law checked(value),
          requires: value,
          expects: value,
          proof: ~LEAN"exact requires"
      end

  If verifying the laws fail, the error report includes the path to folder with
  all `.lean` files. Use this to debug and guide your proofs.
  """
  defmacro laws(description, opts \\ [], do: block) do
    definition =
      quote unquote: false do
        def unquote(name)(_context) do
          Lynx.Case.__verify__(
            __MODULE__,
            unquote(name),
            unquote(group_laws),
            unquote(Macro.escape(translation)),
            unquote(Macro.escape(options))
          )
        end
      end

    quote do
      {name, group_laws, translation, options} =
        Lynx.Case.__laws__(
          __MODULE__,
          unquote(__CALLER__.file),
          unquote(__CALLER__.line),
          unquote(description),
          unquote(opts),
          fn -> unquote(block) end
        )

      unquote(definition)
    end
  end

  @doc false
  def __laws__(module, file, line, description, opts, fun) do
    if Module.get_attribute(module, :lynx_laws) do
      raise ArgumentError, "laws groups cannot be nested"
    end

    if not Keyword.keyword?(opts) do
      raise ArgumentError, "laws options must be a keyword list, got: #{inspect(opts)}"
    end

    options = Keyword.get(opts, :options, [])

    for key <- Keyword.keys(opts), key != :options do
      raise ArgumentError, "unknown laws option #{inspect(key)}"
    end

    for option <- options do
      case option do
        {name, value}
        when is_atom(name) and (is_integer(value) or is_boolean(value) or is_binary(value)) ->
          :ok

        _ ->
          raise ArgumentError,
                "laws options must be Lean option names with integer, boolean, " <>
                  "or string values, got: #{inspect(option)}"
      end
    end

    Module.put_attribute(module, :lynx_laws, [])
    Module.put_attribute(module, :lynx_termination_suffixes, %{})
    Module.put_attribute(module, :lynx_cutoffs, MapSet.new())
    Module.put_attribute(module, :lynx_dynamic, MapSet.new())
    Module.put_attribute(module, :lynx_preludes, [])
    Module.put_attribute(module, :lynx_postludes, [])

    try do
      fun.()
      group_laws = module |> Module.get_attribute(:lynx_laws) |> Enum.reverse()

      if group_laws == [] do
        raise CompileError, file: file, line: line, description: "laws group must contain a law"
      end

      name = ExUnit.Case.register_test(module, file, line, :laws, description, [:laws])

      translation = [
        termination_suffixes: Module.get_attribute(module, :lynx_termination_suffixes),
        cutoffs: Module.get_attribute(module, :lynx_cutoffs),
        dynamic: Module.get_attribute(module, :lynx_dynamic),
        preludes: Enum.reverse(Module.get_attribute(module, :lynx_preludes)),
        postludes: Enum.reverse(Module.get_attribute(module, :lynx_postludes))
      ]

      {name, group_laws, translation, options}
    after
      Module.delete_attribute(module, :lynx_laws)
      Module.delete_attribute(module, :lynx_termination_suffixes)
      Module.delete_attribute(module, :lynx_cutoffs)
      Module.delete_attribute(module, :lynx_dynamic)
      Module.delete_attribute(module, :lynx_preludes)
      Module.delete_attribute(module, :lynx_postludes)
    end
  end

  @doc false
  def __after_compile__(env, beam) do
    # ExUnit compiles .exs modules in memory, so there is no BEAM on the code path.
    # Recompiling a module replaces its retained binary.
    Lynx.Bytecode.put(env.module, beam)
  end

  @doc false
  def __verify__(module, name, laws, translation, options) do
    export =
      case System.get_env("LYNX_EXPORT") do
        nil -> []
        "" -> []
        dir -> [export: Path.join(group_path(dir, module, name)) <> ".ndjson"]
      end

    # Cached modules are not elaborated, so exports always verify from scratch.
    cache = export == [] and System.get_env("LYNX_CACHE") != "0"

    debug =
      case System.get_env("LYNX_DEBUG", "") do
        "" -> []
        "lean" -> [debug: :lean]
        "olean" -> [debug: :olean]
        other -> raise ArgumentError, "LYNX_DEBUG must be lean or olean, got: #{inspect(other)}"
      end

    # The runner writes the translated sources here when a law fails, or always when debugging.
    dir = Path.join(group_path("tmp", module, name))
    File.rm_rf!(dir)

    files =
      Lynx.Translation.new(translation)
      |> Lynx.Translation.add(Lynx.Bytecode.fetch!(module))
      |> Lynx.Translation.verify(module, laws)
      |> Lynx.Translation.assemble(cache: cache)

    signatures =
      for file <- files,
          %{"kind" => "theorem", "name" => name, "params" => params} <- file["contents"],
          into: %{} do
        {{file["module"], "#{name}/#{length(params)}"}, "#{name}(#{Enum.join(params, ", ")})"}
      end

    reports =
      Lynx.Commands.verify!(
        @lean_dir,
        files,
        [options: options, debug_dir: dir] ++ debug ++ export
      )

    if debug != [] do
      for report <- reports do
        prefix =
          case report.status do
            :ok -> "Checked"
            :error -> "Failed to check"
            :skipped -> "Skipped"
          end

        cached = if report.cached, do: ", cached", else: ""
        IO.puts("#{prefix} #{report.module} in #{report.time_ms}ms (#{report.status}#{cached})")

        last_index = length(report.theorems) - 1

        for {theorem, index} <- Enum.with_index(report.theorems) do
          branch = if index == last_index, do: "└─", else: "├─"
          IO.puts("#{branch} #{theorem.name} (#{theorem.time_ms}ms)")
        end
      end

      IO.puts("Translated .lean files written to #{dir}")
    end

    # Cached reports keep their warnings, so they are printed on every run.
    for report <- reports,
        diagnostic <- report.diagnostics,
        diagnostic.severity != :error do
      message = "#{diagnostic.message}\n└─ #{diagnostic_location(diagnostic)}"

      case diagnostic.severity do
        :warning -> IO.warn(message, [])
        :information -> IO.puts("info: " <> message)
      end
    end

    errors =
      for report <- reports,
          report.status != :ok,
          diagnostic <- report.diagnostics,
          diagnostic.severity == :error do
        location = diagnostic_location(diagnostic)

        message =
          case Map.fetch(signatures, {diagnostic.module, diagnostic.declaration}) do
            {:ok, signature} ->
              "#{location} proof for law #{signature} failed\n\n#{diagnostic.message}"

            _ ->
              "#{location} #{diagnostic.message}"
          end

        try do
          ExUnit.Assertions.flunk(message)
        rescue
          error in ExUnit.AssertionError -> {:error, error, __STACKTRACE__}
        end
      end

    if errors != [] do
      errors =
        List.update_at(errors, -1, fn {kind, error, stack} ->
          message = error.message <> "\n\nThe translated .lean files are available at #{dir}"
          {kind, %{error | message: message}, stack}
        end)

      raise ExUnit.MultiError, errors: errors
    end

    :ok
  end

  defp diagnostic_location(diagnostic) do
    Exception.format_file_line_column(
      Path.relative_to_cwd(diagnostic.file),
      diagnostic[:line],
      diagnostic[:column]
    )
  end

  # Match ExUnit's tmp_dir path sanitization.
  @escape Enum.map(~c" [~#%&*{}\\:<>?/+|\"]", &<<&1::utf8>>)

  defp group_path(dir, module, name) do
    [
      dir,
      String.replace(inspect(module), @escape, "-"),
      String.replace(to_string(name), @escape, "-")
    ]
  end
end
