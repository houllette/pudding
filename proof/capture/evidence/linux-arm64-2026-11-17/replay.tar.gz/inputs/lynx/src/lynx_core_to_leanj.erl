-module(lynx_core_to_leanj).

-export([module_name/1, to_definitions/1, called_protocol/1, translate/10,
         fun_table/2, join_purity/2, with_purity/2]).

%% Purity levels, ordered by what running a definition requires: `pure` needs
%% nothing, `apply` needs a dispatcher to call function values, `sequential`
%% also needs an environment, and `concurrent` also needs scheduler choices.
%% Pure definitions may still not return, such as cutoffs. Definitions record
%% their purity apart from calls to function values, and separately whether they
%% dispatch such calls: those depend on the complete program table, so the runner
%% raises dispatching definitions to the program's `dispatcher_purity`.
-type purity() :: pure | apply | sequential | concurrent.

-include_lib("compiler/src/core_parse.hrl").

%% Anonymous functions use integer keys; named functions use {Module, {Name, Arity}}.
%% anonymous counts the funs of the definition without a compiler name.
%% size_facts maps variables to the parameter they equal or are strictly
%% smaller than; size_calls records what each local call passes, so groups
%% of recursive definitions can be given termination measures. dispatch holds
%% the protocol an implementation calls, whose dispatch it copies, see
%% local_dispatch/3.
-record(state, {module, name, defs, translated, laws = #{}, funs = #{}, dispatch = none,
                local_calls = #{}, purity = pure, dispatches = false, remote, next_var = 0,
                anonymous = 0,
                labels = #{},
                local_funs = #{}, size_facts = #{}, size_calls = [], suffixed = [],
                dynamic = [], literals = #{}, binds = [], pattern = false}).

-spec module_name(module()) -> binary().
module_name(Module) ->
    case atom_to_binary(Module, utf8) of
        <<"Elixir.", _/binary>> = Name -> Name;
        Name -> <<"Erlang.", Name/binary>>
    end.

-spec to_definitions(cerl:c_module()) ->
    #{{atom(), arity()} => {function, cerl:c_fun()} | {law, map()}} |
    {error, list(), binary()}.
to_definitions(#c_module{name = #c_literal{val = Module}, defs = Defs, attrs = Attrs}) ->
    try
        Definitions = definitions(Defs ++ Attrs, #{}),
        case [Key || {#c_literal{val = '__protocol__'} = Key, _} <- Attrs] of
            [] -> Definitions;
            _ -> protocol_definitions(Module, Definitions)
        end
    catch
        throw:{error, Core, Reason} -> {error, cerl:get_ann(Core), Reason}
    end.

definitions([{#c_var{name = Name}, #c_fun{} = Fun} | Rest], Definitions) ->
    definitions(Rest, Definitions#{Name => {function, Fun}});
definitions([{#c_literal{val = law}, #c_literal{val = [#{proof := _}]} = LawNode} | Rest], Definitions) ->
    {Name, Law} = law(LawNode, embedded_proof(LawNode)),
    definitions(Rest, Definitions#{Name => {law, Law}});
definitions([{#c_literal{val = law}, LawNode},
             {#c_literal{val = proof}, ProofNode} | Rest], Definitions) ->
    {Name, Law} = law(LawNode, attribute_proof(ProofNode)),
    definitions(Rest, Definitions#{Name => {law, Law}});
definitions([{#c_literal{val = law}, Core} | _], _) ->
    core_error(Core, ~"proof must immediately follow law");
definitions([{#c_literal{val = proof}, Core} | _], _) ->
    core_error(Core, ~"proof without preceding law");
definitions([_ | Rest], Definitions) -> definitions(Rest, Definitions);
definitions([], Definitions) -> Definitions.

law(#c_literal{val = [#{name := {Name, Params}, ensures := Ensures} = Law]} = Core, Proof)
        when is_atom(Name), is_list(Params), is_atom(Ensures) ->
    case lists:all(fun erlang:is_atom/1, Params) of
        true -> ok;
        false -> core_error(Core, ~"law parameters must be atoms")
    end,
    case length(lists:usort(Params)) =:= length(Params) of
        true -> ok;
        false -> core_error(Core, ~"law parameters must be unique")
    end,
    Arity = length(Params),
    case maps:find(requires, Law) of
        error -> ok;
        {ok, Requires} when is_atom(Requires) -> ok;
        _ -> core_error(Core, ~"law requires must be a function name")
    end,
    Anno = case maps:find(span, Law) of
        error -> cerl:get_ann(Core);
        {ok, Span} ->
            case span([Span]) of
                [] -> core_error(Core, ~"law span must be a line or {line, column}");
                _ -> [Span | cerl:get_ann(Core)]
            end
    end,
    {{Name, Arity}, Law#{anno => Anno, proof => Proof}};
law(Core, _) -> core_error(Core, ~"law must contain name {atom, parameters} and ensures function name").

embedded_proof(#c_literal{val = [#{proof := #{source := Proof, indentation := Indentation, span := Span}}]} = Core)
        when is_binary(Proof), is_integer(Indentation), Indentation >= 0 ->
    case span([Span]) of
        [] -> core_error(Core, ~"embedded proof span must be a line or {line, column}");
        ProofSpan -> #{~"source" => Proof, ~"indentation" => Indentation, ~"span" => ProofSpan}
    end;
embedded_proof(Core) ->
    core_error(Core, ~"embedded proof requires a binary, nonnegative indentation and span").

attribute_proof(#c_literal{val = [Proof]} = Core) when is_binary(Proof) ->
    %% Erlang multiline strings begin on the line after the proof attribute.
    ProofSpan = case span(cerl:get_ann(Core)) of
        [Line | _] -> [Line + 1];
        [] -> []
    end,
    #{~"source" => Proof, ~"indentation" => 0, ~"span" => ProofSpan};
attribute_proof(Core) -> core_error(Core, ~"proof must be a binary").

%% Consolidated protocols dispatch through tuples of function values, which
%% proofs could only follow through the program's function table. Instead,
%% impl_for/1 returns the implementation module, and each protocol function
%% matches it to call that implementation directly, so implementations can be
%% cut off individually. Other definitions are kept, since some protocols
%% define their own functions, and only reachable ones are translated.
protocol_definitions(Protocol, #{{'__protocol__', 1} := {function, Info}} = Definitions) ->
    Types = case protocol_info(Info, impls) of
        {consolidated, Consolidated} -> Consolidated;
        _ -> core_error(Info, <<"cannot translate protocol ", (atom_to_binary(Protocol))/binary,
                                " because it is not consolidated">>)
    end,
    Impls = [protocol_impl(Protocol, Type) || Type <- Types],
    Dispatches = #{Function => {function, protocol_dispatch(Function, Impls, protocol_fun(Definitions, Function, Info))}
                   || Function <- protocol_info(Info, functions)},
    maps:merge(Definitions, Dispatches#{
        {impl_for, 1} => {function, impl_for(Protocol, Types, protocol_fun(Definitions, {impl_for, 1}, Info))},
        {'impl_for!', 1} => {function, impl_for_bang(Protocol, Types, protocol_fun(Definitions, {'impl_for!', 1}, Info))}
    }).

%% The literal __protocol__/1 returns for the given key.
protocol_info(#c_fun{body = Body} = Fun, Key) ->
    Clauses = case Body of
        #c_case{clauses = CaseClauses} -> CaseClauses;
        _ -> []
    end,
    Values = [cerl:concrete(Literal) || #c_clause{pats = [#c_literal{val = Pat}], body = Value} <- Clauses,
                                        Pat =:= Key,
                                        Literal <- [cerl:fold_literal(Value)],
                                        cerl:is_literal(Literal)],
    case Values of
        [Value] -> Value;
        _ -> core_error(Fun, <<"cannot find ", (atom_to_binary(Key))/binary, " in __protocol__/1">>)
    end.

%% The generated definitions keep the parameters and annotations of the originals.
protocol_fun(Definitions, {Name, Arity}, Info) ->
    case Definitions of
        #{{Name, Arity} := {function, #c_fun{} = Fun}} -> Fun;
        _ -> core_error(Info, <<"cannot find protocol function ", (atom_to_binary(Name))/binary,
                                "/", (integer_to_binary(Arity))/binary>>)
    end.

%% Mirrors Protocol.__concat__/2.
protocol_impl(Protocol, Type) ->
    Suffix = case atom_to_binary(Type) of
        <<"Elixir.", Rest/binary>> -> Rest;
        Rest -> Rest
    end,
    binary_to_atom(<<(atom_to_binary(Protocol))/binary, ".", Suffix/binary>>).

%% Built-in types and their guards, in the order consolidation checks them.
protocol_built_ins() ->
    [{'Elixir.Tuple', is_tuple}, {'Elixir.Atom', is_atom}, {'Elixir.List', is_list},
     {'Elixir.Map', is_map}, {'Elixir.BitString', is_bitstring}, {'Elixir.Integer', is_integer},
     {'Elixir.Float', is_float}, {'Elixir.Function', is_function}, {'Elixir.PID', is_pid},
     {'Elixir.Port', is_port}, {'Elixir.Reference', is_reference}].

%% Built-in types are disjoint, so each implemented one is matched by its
%% constructor, which lists have two of. Structs are matched among maps, so
%% they select their own implementation, or the fallback, but never the one
%% for maps.
impl_for(Protocol, Types, #c_fun{anno = Anno, vars = [Data]} = Fun) ->
    Atom = fun(Value) -> cerl:ann_c_atom(Anno, Value) end,
    Impl = fun(Type) -> Atom(protocol_impl(Protocol, Type)) end,
    Fallback = case lists:member('Elixir.Any', Types) of
        true -> Impl('Elixir.Any');
        false -> Atom(nil)
    end,
    Other = cerl:ann_c_var(Anno, 'Other'),
    Guarded = fun(Name, Arg, Pattern, Body) ->
        cerl:ann_c_clause(Anno, [Pattern], cerl:ann_c_call(Anno, Atom(erlang), Atom(Name), [Arg]), Body)
    end,
    StructPattern = fun(Value) ->
        cerl:ann_c_map_pattern(Anno, [cerl:ann_c_map_pair(Anno, Atom(exact), Atom('__struct__'), Value)])
    end,
    BuiltIns = protocol_built_ins(),
    Structs = [Type || Type <- Types, Type =/= 'Elixir.Any', not lists:keymember(Type, 1, BuiltIns)],
    MapImpl = case lists:member('Elixir.Map', Types) of
        true -> Impl('Elixir.Map');
        false -> Fallback
    end,
    Struct = cerl:ann_c_var(Anno, 'Struct'),
    Map = cerl:ann_c_var(Anno, 'Map'),
    MapBody = cerl:ann_c_case(Anno, Data,
        [cerl:ann_c_clause(Anno, [StructPattern(Atom(Type))], Impl(Type)) || Type <- Structs] ++
        [Guarded(is_atom, Struct, StructPattern(Struct), Fallback), cerl:ann_c_clause(Anno, [Map], MapImpl)]),
    Clauses = lists:flatmap(fun
        ({'Elixir.Map', is_map}) when Structs =/= []; MapImpl =/= Fallback ->
            [Guarded(is_map, Data, Other, MapBody)];
        ({'Elixir.List' = Type, is_list}) ->
            [cerl:ann_c_clause(Anno, [Pattern], Impl(Type))
             || lists:member(Type, Types),
                Pattern <- [cerl:ann_c_nil(Anno),
                            cerl:ann_c_cons(Anno, cerl:ann_c_var(Anno, '_Head'), cerl:ann_c_var(Anno, '_Tail'))]];
        ({Type, Name}) ->
            [Guarded(Name, Data, Other, Impl(Type)) || Type =/= 'Elixir.Map', lists:member(Type, Types)]
    end, BuiltIns),
    Fun#c_fun{body = cerl:ann_c_case(Anno, Data, Clauses ++ [cerl:ann_c_clause(Anno, [Other], Fallback)])}.

%% Without a fallback, values without an implementation raise
%% Protocol.UndefinedError, built here as its exception/1 would.
impl_for_bang(Protocol, Types, #c_fun{anno = Anno, vars = [Data]} = Fun) ->
    ImplFor = cerl:ann_c_apply(Anno, cerl:ann_c_fname(Anno, impl_for, 1), [Data]),
    Body = case lists:member('Elixir.Any', Types) of
        true ->
            ImplFor;
        false ->
            Impl = cerl:ann_c_var(Anno, 'Impl'),
            Fields = [{'__struct__', cerl:ann_c_atom(Anno, 'Elixir.Protocol.UndefinedError')},
                      {'__exception__', cerl:ann_c_atom(Anno, true)},
                      {protocol, cerl:ann_c_atom(Anno, Protocol)},
                      {value, Data},
                      {description, cerl:ann_abstract(Anno, <<>>)}],
            Error = cerl:ann_c_map(Anno, [cerl:ann_c_map_pair(Anno, cerl:ann_c_atom(Anno, assoc), cerl:ann_c_atom(Anno, Key), Value)
                                          || {Key, Value} <- Fields]),
            Raise = cerl:ann_c_call(Anno, cerl:ann_c_atom(Anno, erlang), cerl:ann_c_atom(Anno, error), [Error]),
            cerl:ann_c_case(Anno, ImplFor,
                            [cerl:ann_c_clause(Anno, [cerl:ann_c_atom(Anno, nil)], Raise),
                             cerl:ann_c_clause(Anno, [Impl], Impl)])
    end,
    Fun#c_fun{body = Body}.

protocol_dispatch({Name, _Arity}, Impls, #c_fun{anno = Anno, vars = [Data | _] = Vars} = Fun) ->
    ImplFor = cerl:ann_c_apply(Anno, cerl:ann_c_fname(Anno, 'impl_for!', 1), [Data]),
    Impl = cerl:ann_c_var(Anno, 'Impl'),
    Clauses =
        [cerl:ann_c_clause(Anno, [cerl:ann_c_atom(Anno, Module)],
                           cerl:ann_c_call(Anno, cerl:ann_c_atom(Anno, Module), cerl:ann_c_atom(Anno, Name), Vars))
         || Module <- Impls] ++
        [cerl:ann_c_clause(Anno, [Impl],
                           cerl:ann_c_primop(Anno, cerl:ann_c_atom(Anno, match_fail),
                                             [cerl:ann_c_tuple(Anno, [cerl:ann_c_atom(Anno, case_clause), Impl])]))],
    Fun#c_fun{body = cerl:ann_c_case(Anno, ImplFor, Clauses)}.

%% The protocol an implementation calls, which then dispatches locally, and
%% the functions of it the implementation calls.
-spec called_protocol(cerl:c_module()) -> {module(), [{atom(), arity()}]} | nil.
called_protocol(#c_module{defs = Defs, attrs = Attrs}) ->
    Protocols = [Protocol || {#c_literal{val = '__impl__'}, Value} <- Attrs,
                             {protocol, Protocol} <- lists:flatten([cerl:concrete(Value)])],
    Called = fun(Protocol) ->
        lists:usort(lists:append([cerl_trees:fold(fun
            (#c_call{module = #c_literal{val = Module}, name = #c_literal{val = Name}, args = Args},
             Found) when Module =:= Protocol ->
                [{Name, length(Args)} | Found];
            (_, Found) ->
                Found
        end, [], Fun) || {_, Fun} <- Defs]))
    end,
    case [{Protocol, Calls} || Protocol <- Protocols, Calls <- [Called(Protocol)], Calls =/= []] of
        [Called0] -> Called0;
        [] -> nil
    end.

%% Implementations calling their own protocol, such as streams of streams,
%% would form a module cycle through it. Instead, they call local copies of
%% the protocol's dispatch, which call the implementation's own functions
%% locally and other implementations directly. Functions of the protocol that
%% are cut off are not copied, and calls to them stay calls to the protocol.
local_dispatch(none) ->
    none;
local_dispatch({Protocol, #{{'__protocol__', 1} := {function, Info}} = Definitions, Cut}) ->
    Functions = [Function || Function <- [{impl_for, 1}, {'impl_for!', 1} | protocol_info(Info, functions)],
                             not lists:member(Function, Cut)],
    Prefix = case atom_to_binary(Protocol) of
        <<"Elixir.", Rest/binary>> -> Rest;
        Name -> Name
    end,
    Local = maps:from_list([{Function, {binary_to_atom(<<Prefix/binary, ".", (atom_to_binary(Name))/binary>>), Arity}}
                            || {Name, Arity} = Function <- Functions]),
    {Protocol, Local, #{LocalName => Function || Function := LocalName <- Local}, Definitions, Cut}.

%% The local copy of a function of the protocol, calling the other copies.
dispatch_copy(LocalName, {Protocol, Local, Originals, Definitions, Cut}) ->
    #{LocalName := Function} = Originals,
    #{Function := {function, Fun}} = Definitions,
    {function, cerl_trees:map(fun
        (#c_var{name = {_, _} = Name} = Var) when is_map_key(Name, Local) ->
            Var#c_var{name = map_get(Name, Local)};
        (#c_apply{anno = Anno, op = #c_var{name = {Name, Arity} = Called}, args = Args} = Node) ->
            case lists:member(Called, Cut) of
                true when length(Args) =:= Arity ->
                    cerl:ann_c_call(Anno, cerl:ann_c_atom(Anno, Protocol), cerl:ann_c_atom(Anno, Name), Args);
                _ ->
                    Node
            end;
        (Node) ->
            Node
    end, Fun)}.

-spec fun_table(map(), map()) -> [map()].
fun_table(Funs, Modules) ->
    Entries = [begin
        #{Module := #{translations := #{Name := Translated}}} = Modules,
        #{translation := Definition} = Translated,
        {Key, Module, Fun, Definition, purity_of(Translated)}
    end || Key := #{module := Module, name := Name} = Fun <- Funs],
    [fun_entry(Entry) || Entry <- lists:sort(Entries)].

%% Entries are sorted and named by the module, name, and arity the compiler
%% gave their function, which function values carry.
fun_entry({{FunModule, FunName, _}, Module, #{arity := Arity},
           #{~"params" := Params, ~"name" := Name}, Purity}) ->
    Captures = [var_node(<<"cap", (integer_to_binary(I))/binary>>, [])
                || I <- lists:seq(1, length(Params) - Arity)],
    Args = [var_node(<<"arg", (integer_to_binary(I))/binary>>, [])
            || I <- lists:seq(1, Arity)],
    Body = remote_call_node(module_name(Module), Name, Captures ++ Args, Purity, []),
    Entry = #{~"module" => atom_to_binary(FunModule, utf8), ~"name" => atom_to_binary(FunName, utf8),
              ~"body" => Body, ~"captures" => Captures, ~"args" => Args, ~"span" => []},
    with_purity(Entry, Purity).

%% A translated definition's purity, and whether it calls function values.
purity_of(#{purity := Purity, dispatches := Dispatches}) -> {Purity, Dispatches}.

%% Nodes record calls to function values only when they make them.
-spec with_purity(map(), {purity(), boolean()}) -> map().
with_purity(Node, {Purity, Dispatches}) ->
    Node1 = Node#{~"purity" => atom_to_binary(Purity)},
    case Dispatches of
        true -> Node1#{~"dispatches" => true};
        false -> Node1
    end.

-spec join_purity(purity(), purity()) -> purity().
join_purity(Left, Right) ->
    case purity_rank(Left) >= purity_rank(Right) of
        true -> Left;
        false -> Right
    end.

purity_rank(pure) -> 0;
purity_rank(apply) -> 1;
purity_rank(sequential) -> 2;
purity_rank(concurrent) -> 3.

%% Translate the requested functions and laws, plus their reachable local callees.
%% Laws are returned separately from definitions, keyed by name.
%% The supplied maps contain this module's definitions, its literal pool, and the
%% program-wide function registry.
%% Suffixed functions have user termination suffixes, which refer to Core's parameter names.
%% Dynamic lists the {Module, Function, Arity} targets that calls by name may reach,
%% such as apply(M, F, Args), in addition to the function values the program creates.
%% The callback returns the remote callee's purity and whether it calls function values.
%% Local purity is propagated by Lynx.Translation.
%% Unsupported constructs return their annotations and pretty-printed Core as a UTF-8 binary.
%% Dispatch is `none`, or the protocol the module implements and calls, its
%% definitions, and those of its functions that are cut off.
-spec translate(module(), #{{atom(), arity()} => {function | cutoff, cerl:c_fun()} | {law, map()}}, [{atom(), arity()}], map(),
                #{term() => binary()}, map(), [{atom(), arity()}], [mfa()],
                {term(), fun((term(), module(), atom(), arity(), list(), map()) ->
                    {{purity(), boolean()}, map(), term()} | local)},
                none | {module(), map(), [{atom(), arity()}]}) ->
    {ok, map(), map(), map(), map(), term()} | {error, list(), binary()}.
translate(Module, Definitions, Names, Translated, Literals, Funs, Suffixed, Dynamic, Remote, Dispatch) ->
    try
        State = #state{
          module = Module,
          defs = Definitions,
          dispatch = local_dispatch(Dispatch),
          translated = Translated,
          literals = Literals,
          funs = Funs,
          suffixed = Suffixed,
          dynamic = lists:usort(Dynamic),
          remote = Remote
        },

        #state{
          translated = NewTranslated,
          literals = NewLiterals,
          laws = Laws,
          funs = NewFuns,
          remote = {NewContext, _Callback}
        } = lists:foldl(fun translate_def/2, State, Names),

        {ok, NewTranslated, NewLiterals, Laws, NewFuns, NewContext}
    catch
        throw:{error, Core, Reason} -> {error, cerl:get_ann(Core), Reason}
    end.

translate_def(Name, #state{translated = Translated, laws = Laws} = State) ->
    case maps:is_key(Name, Translated) orelse maps:is_key(Name, Laws) of
        true -> State;
        false -> translate_def(Name, definition(Name, State), State)
    end.

definition(Name, #state{defs = Definitions, dispatch = Dispatch}) ->
    case Definitions of
        #{Name := Definition} -> Definition;
        #{} -> dispatch_copy(Name, Dispatch)
    end.

translate_def(Name, {function, #c_fun{anno = Anno, vars = Vars0, body = Body0}}, State) ->
    {Vars, Body} = case lists:member(Name, State#state.suffixed) of
        true -> {Vars0, Body0};
        false -> rename_parameters(Vars0, Body0)
    end,
    try translate_definition(Name, Anno, Vars, {function, Body}, State)
    catch
        throw:{error, Core, Reason} ->
            %% Compiler-generated primops may have no source position.
            %% Fall back to the innermost function containing the expression.
            case span(cerl:get_ann(Core)) of
                [] -> core_error(cerl:set_ann(Core, cerl:get_ann(Core) ++ Anno), Reason);
                _ -> core_error(Core, Reason)
            end
    end;
translate_def(Name, {cutoff, #c_fun{anno = Anno, vars = Vars}}, State) ->
    translate_definition(Name, Anno, Vars, cutoff, State);
translate_def(Name, {law, #{name := {_, Params}, anno := Anno, ensures := Ensures, proof := Proof} = Law}, State0) ->
    {_, Arity} = Name,
    {Requirement, State1} = case maps:find(requires, Law) of
        error -> {#{}, State0};
        {ok, Helper} -> {#{~"requires" => atom_to_binary(Helper, utf8)},
                         translate_def({Helper, Arity}, State0)}
    end,
    State2 = translate_def({Ensures, Arity}, State1),
    Theorem = node(~"theorem", Anno, Requirement#{
        ~"name" => function_name(Name), ~"params" => [atom_to_binary(Param, utf8) || Param <- Params],
        ~"ensures" => atom_to_binary(Ensures, utf8), ~"proof" => Proof
    }),
    State2#state{laws = (State2#state.laws)#{Name => Theorem}}.

%% Core names parameters _0, _1, ... and binds them again in every clause of the
%% body's case, as in case <_0, _1> of <[H | T], Acc> -> ... When every clause binds
%% a parameter to a variable, the parameter takes the first source name and the
%% rebinding is dropped, keeping readable names without matching on it.
rename_parameters(Vars, #c_case{arg = Arg, clauses = Clauses} = Case) ->
    Scrutinees = case Arg of
        #c_values{es = Elements} -> Elements;
        _ -> [Arg]
    end,
    Params = [Param || #c_var{name = Param} <- Vars],
    Positions = lists:seq(1, length(Scrutinees)),
    {Renames, Dropped} = lists:foldl(fun(Position, {RenamesAcc, DroppedAcc}) ->
        case {lists:nth(Position, Scrutinees), clause_variables(Clauses, Position)} of
            {#c_var{name = Param}, [_ | _] = Bound} ->
                case lists:member(Param, Params) of
                    true ->
                        Name = case [Source || Source <- Bound, is_atom(Source)] of
                            [Source | _] -> Source;
                            [] -> Param
                        end,
                        Used = maps:values(RenamesAcc),
                        %% Guards type-testing the variable refine its pattern instead.
                        Free = lists:all(fun({#c_clause{guard = Guard} = Clause, Var}) ->
                            (Var =:= Name orelse
                                not lists:member(Name, cerl_trees:variables(Clause))) andalso
                                not lists:any(fun(Referenced) -> lists:member(Referenced, [Var, Param]) end,
                                              cerl_trees:free_variables(Guard))
                        end, lists:zip(Clauses, Bound)),
                        case Free andalso not lists:member(Name, Used) andalso
                                (Name =:= Param orelse not lists:member(Name, Params)) of
                            true -> {RenamesAcc#{Param => Name}, [Position | DroppedAcc]};
                            false -> {RenamesAcc, DroppedAcc}
                        end;
                    false ->
                        {RenamesAcc, DroppedAcc}
                end;
            _ ->
                {RenamesAcc, DroppedAcc}
        end
    end, {#{}, []}, Positions),
    case Dropped of
        [] ->
            {Vars, Case};
        _ ->
            Kept = [Position || Position <- Positions, not lists:member(Position, Dropped)],
            NewClauses = [begin
                #c_clause{pats = Patterns} = Clause,
                Substitution = maps:from_list(
                    [{Param, Name} || Param := Name <- Renames] ++
                    [{Var, maps:get(Param, Renames)} ||
                        Position <- Dropped,
                        #c_var{name = Param} <- [lists:nth(Position, Scrutinees)],
                        #c_var{name = Var} <- [lists:nth(Position, Patterns)]]),
                Renamed = rename_variables(Clause, Substitution),
                Renamed#c_clause{pats = [lists:nth(Position, cerl:clause_pats(Renamed)) || Position <- Kept]}
            end || Clause <- Clauses],
            NewScrutinees = [lists:nth(Position, Scrutinees) || Position <- Kept],
            NewArg = case Arg of
                #c_values{} -> Arg#c_values{es = NewScrutinees};
                _ when NewScrutinees =:= [] -> cerl:c_values([]);
                _ -> hd(NewScrutinees)
            end,
            NewVars = [case Renames of
                           #{Param := Name} -> Var#c_var{name = Name};
                           #{} -> Var
                       end || #c_var{name = Param} = Var <- Vars],
            {NewVars, Case#c_case{arg = NewArg, clauses = NewClauses}}
    end;
rename_parameters(Vars, Body) ->
    {Vars, Body}.

%% The variable each clause binds at a position, or [] unless every clause binds one.
clause_variables(Clauses, Position) ->
    Bound = [case lists:nth(Position, Patterns) of
                 #c_var{name = Name} -> Name;
                 _ -> none
             end || #c_clause{pats = Patterns} <- Clauses],
    case lists:member(none, Bound) of
        true -> [];
        false -> Bound
    end.

rename_variables(Tree, Substitution) ->
    cerl_trees:map(fun(#c_var{name = Name} = Var) ->
        case Substitution of
            #{Name := New} -> Var#c_var{name = New};
            #{} -> Var
        end;
    (Node) -> Node
    end, Tree).

translate_definition(Name, Anno, Vars, Definition, State0) ->
    Facts = maps:from_list([{Var, {Index, eq}} ||
        {#c_var{name = Var}, Index} <- lists:zip(Vars, lists:seq(0, length(Vars) - 1))]),
    State1 = State0#state{name = Name, local_calls = #{}, purity = pure, dispatches = false,
                          next_var = 0, anonymous = 0, labels = #{},
                          size_facts = Facts, size_calls = [],
                          translated = (State0#state.translated)#{Name => pending}},
    {Def, State2} = case Definition of
        cutoff ->
            {node(~"def", Anno, #{
                ~"name" => function_name(Name),
                ~"params" => [variable(Var) || Var <- Vars],
                ~"body" => node(~"cutoff", Anno, #{})
            }), State1};
        {function, Body} ->
            {Translated, Next} = expression(Body, State1),
            TranslatedBody = lists:foldr(fun(Size, Acc) ->
                node(~"nonzero_width", Anno, #{~"size" => variable(Size), ~"body" => Acc})
            end, Translated, proplists:get_value(lynx_nonzero_widths, Anno, [])),
            {node(~"def", Anno, #{
                ~"name" => function_name(Name),
                ~"params" => [variable(Var) || Var <- Vars],
                ~"body" => TranslatedBody
            }), Next}
    end,
    Entry = #{translation => Def, local_calls => maps:keys(State2#state.local_calls),
              size_calls => lists:reverse(State2#state.size_calls),
              purity => State2#state.purity, dispatches => State2#state.dispatches},
    State0#state{translated = (State2#state.translated)#{Name => Entry},
                 literals = State2#state.literals, funs = State2#state.funs,
                 remote = State2#state.remote}.

%% Core expects values in arguments and constructors, but the optimizer may
%% nest computations in their place, such as when inlining lists:foldl/3.
%% value/2 binds those to generated variables, which are bound in evaluation
%% order before the expression that uses them.
expression(Core, State0) ->
    {Translated, State1} = computation(Core, State0#state{binds = []}),
    Bound = lists:foldl(fun({Var, Computation}, Body) ->
        node(~"bind", cerl:get_ann(Core), #{~"vars" => [Var],
            ~"computation" => Computation, ~"body" => Body})
    end, Translated, State1#state.binds),
    {Bound, State1#state{binds = State0#state.binds}}.

%% OTP lowers receive to a local scan/wait loop. Recover the operation before
%% translating ordinary expressions; loop identity is checked structurally,
%% never inferred from the compiler's generated function spelling.
computation(#c_letrec{anno = Anno, defs = [{#c_var{name = Loop},
             #c_fun{vars = [], body = #c_let{arg = #c_primop{
                 name = #c_literal{val = ReceiveOp}}} = LoopBody}}],
             body = #c_apply{op = #c_var{name = Loop}, args = []}} = Core, State0)
        when ReceiveOp =:= recv_peek_message; ReceiveOp =:= recv_wait_timeout ->
    {Message, Clauses, Timeout, Action} = receive_parts(LoopBody, Loop, Core),
    {TranslatedMessage, State1} = case Message of
        none ->
            {var_node(#{~"generated" => State0#state.next_var}, Anno),
             State0#state{next_var = State0#state.next_var + 1}};
        _ -> {variable(Message), State0}
    end,
    {TranslatedTimeout, State2} = value(Timeout, State1),
    {TranslatedClauses, State3} = lists:mapfoldl(fun receive_clause/2, State2, Clauses),
    {TranslatedAction, State4} = case Timeout of
        #c_literal{val = infinity} ->
            {node(~"return", Anno, #{~"values" => [node(~"atom", Anno, #{~"value" => ~"true"})]}), State3};
        _ -> expression(Action, State3)
    end,
    {node(~"receive", Anno, #{~"message" => TranslatedMessage,
        ~"cases" => TranslatedClauses, ~"timeout" => TranslatedTimeout,
        ~"after" => TranslatedAction}), State4#state{purity = concurrent}};
%% Preserve nonrecursive compiler labels; Lean renders the shared continuation.
computation(#c_letrec{anno = Anno, defs = [{#c_var{name = Label},
             #c_fun{vars = [], body = Fallback}}], body = Body} = Core, State0) ->
    case lists:member(letrec_goto, Anno) andalso
            not lists:member(Label, cerl_trees:free_variables(Fallback)) of
        true ->
            {TranslatedFallback, State1} = expression(Fallback, State0),
            {TranslatedBody, State2} = expression(Body,
                State1#state{labels = (State1#state.labels)#{Label => true}}),
            {node(~"label", Anno, #{~"label" => function_name(Label),
                ~"continuation" => TranslatedFallback, ~"body" => TranslatedBody}),
             State2#state{labels = State0#state.labels}};
        false -> computation_local_function(Core, State0)
    end;
%% Named local functions, including comprehension loops, use the same call path.
computation(#c_letrec{defs = [{#c_var{}, #c_fun{}}]} = Core, State0) ->
    computation_local_function(Core, State0);
%% Core try catches only the protected expression, not its success continuation.
computation(#c_try{anno = Anno, arg = Arg, vars = Vars, body = Body,
                  evars = EVars, handler = Handler}, State0) ->
    {TranslatedArg, State1} = expression(Arg, State0),
    {TranslatedBody, State2} = expression(Body, State1),
    {TranslatedHandler, State3} = expression(Handler, State2),
    {node(~"try", Anno, #{~"computation" => TranslatedArg,
        ~"vars" => [variable(V) || V <- Vars], ~"body" => TranslatedBody,
        ~"exception_vars" => [variable(V) || V <- EVars],
        ~"handler" => TranslatedHandler}), State3};
%% Multiple Core return values are internal Lean products, not Erlang tuples.
computation(#c_values{anno = Anno, es = Values}, State0) ->
    {Translated, State1} = lists:mapfoldl(fun value/2, State0, Values),
    {node(~"return", Anno, #{~"values" => Translated}), State1};
%% Erlang: case X of [] -> 0; Other -> 1 end
%% Lean:
%%   match vX with
%%   | Lynx.Term.nil => Lynx.Result.ok (Lynx.Term.integer 0)
%%   | vOther => Lynx.Result.ok (Lynx.Term.integer 1)
%% Erlang: A orelse B
%% Lean: Lynx.Result.orElse a b
computation(#c_case{anno = Anno} = Case, State0) ->
    case short_circuit(Case) of
        {Kind, Badbool, _} ->
            Operands = operands(Kind, Badbool, Case),
            Chain = case Kind of
                ~"orelse" -> membership(Operands);
                ~"andalso" -> Operands
            end,
            short_circuit_chain(Kind, Badbool, Anno, Chain, State0);
        none -> computation_case(Case, State0)
    end;
%% Elixir's and/or associate to the left, so Core binds the left chain before
%% the case on it, either as the result or as the next binding. Matching on the
%% chain directly keeps a single expression, evaluated at the same point.
%% Elixir: (a and b) and c
%% Lean: Lynx.Except.andAlso (Lynx.Except.andAlso a b) c
computation(#c_let{vars = [#c_var{name = Name}], arg = Arg,
                   body = #c_case{arg = #c_var{name = Name}} = Case} = Let, State0) ->
    case left_operand(Name, Case#c_case{arg = Arg}, []) of
        true -> computation(Case#c_case{arg = Arg}, State0);
        false -> let_bind(Let, State0)
    end;
computation(#c_let{vars = [#c_var{name = Name}], arg = Arg,
                   body = #c_let{arg = #c_case{arg = #c_var{name = Name}} = Case, body = Rest} = Next} = Let,
            State0) ->
    case left_operand(Name, Case#c_case{arg = Arg}, [Rest]) of
        true -> computation(Next#c_let{arg = Case#c_case{arg = Arg}}, State0);
        false -> let_bind(Let, State0)
    end;
%% Erlang: Y = f(X), g(Y)
%% Lean: Lynx.Result.bind («f/1» vX) fun vY => «g/1» vY
computation(#c_let{} = Let, State0) ->
    let_bind(Let, State0);
%% Erlang: f(X), g(X)
%% Lean: do let _ ← «f/1» vX; «g/1» vX
computation(#c_seq{anno = Anno, arg = Arg, body = Body}, State0) ->
    {TranslatedArg, State1} = expression(Arg, State0),
    {TranslatedBody, State2} = expression(Body, State1),
    {node(~"bind", Anno, #{~"vars" => [node(~"wildcard", Anno, #{})],
        ~"computation" => TranslatedArg, ~"body" => TranslatedBody}), State2};
%% Erlang: f(X, Y)
%% Lean: «f/2» vX vY
computation(#c_apply{anno = Anno, op = #c_var{name = {_, _} = Name}, args = Args} = Core, State0) ->
    case maps:find(Name, State0#state.local_funs) of
        {ok, {Lifted, _, Captures}} ->
            expression(#c_apply{anno = Anno, op = #c_var{name = Lifted},
                               args = Args ++ Captures},
                       State0);
        error -> computation_apply(Core, State0)
    end;
%% Erlang: F(X, Y)
%% Lean: Lynx.Dispatcher.pure lynxDispatch vF #[vX, vY], or Lynx.Dispatcher.call
%% in computations returning Result
computation(#c_apply{anno = Anno, op = Op, args = Args}, State0) ->
    {Function, State1} = value(Op, State0),
    {TranslatedArgs, State2} = lists:mapfoldl(fun value/2, State1, Args),
    {node(~"fun_call", Anno, #{~"function" => Function, ~"args" => TranslatedArgs}),
     State2#state{dispatches = true}};
%% Erlang: error(Reason)
%% Lean: Lynx.Result.error (Lynx.Exception.error reason)
computation(#c_call{anno = Anno, module = #c_literal{val = erlang},
                   name = #c_literal{val = Class}, args = [Reason]}, State0)
        when Class =:= error; Class =:= throw; Class =:= exit ->
    {TranslatedReason, State1} = value(Reason, State0),
    {node(~"raise", Anno, #{~"class" => atom_to_binary(Class, utf8), ~"reason" => TranslatedReason}), State1};
%% Erlang: apply(M, F, Args) or make_fun(M, F, Arity)
%% Lean: Erlang.erlang.«apply/3» dispatcher vM vF vArgs
%% The compiler folds literal references, such as &Foo.bar/1, into function
%% literals and literal applies into calls, so these remain when computed.
%% They reach function values through the program table, which includes the
%% dynamic targets.
computation(#c_call{anno = Anno, module = #c_literal{val = erlang},
                   name = #c_literal{val = Name}, args = [_, _, _]} = Core, State0)
        when Name =:= apply; Name =:= make_fun ->
    State1 = lists:foldl(fun({Module, Function, Arity}, Acc) ->
        {_, Next} = external_function_value(Module, Function, Arity, Anno, Acc),
        Next
    end, State0, State0#state.dynamic),
    remote_computation(Core, State1);
%% Erlang: spawn(M, F, [A1, ..., An]), with literal M and F
%% Lean: Erlang.erlang.«spawn/1» applied to a function value calling M:F(A1, ..., An)
%% The arguments are values, so they are evaluated by the caller, as in Erlang.
%% spawn_link/3 and spawn_monitor/3 are translated the same way.
computation(#c_call{anno = Anno, module = #c_literal{val = erlang},
                   name = #c_literal{val = Spawn},
                   args = [#c_literal{val = Module}, #c_literal{val = Function}, Args]} = Core,
            State)
        when (Spawn =:= spawn orelse Spawn =:= spawn_link orelse Spawn =:= spawn_monitor),
             is_atom(Module), is_atom(Function) ->
    case spawn_arguments(Args) of
        {ok, Values} ->
            %% The compiler names the fun as other funs without a name.
            Fun = #c_fun{anno = Anno, vars = [], body = #c_call{anno = Anno,
                module = #c_literal{val = Module}, name = #c_literal{val = Function},
                args = Values}},
            computation(Core#c_call{args = [Fun]}, State);
        error ->
            core_error(Core, <<"spawning with arguments that are not a list of values "
                               "is not supported">>)
    end;
%% Erlang: other:f(X)
%% Lean: Erlang.other.«f/1» vX
%% Erlang: ?MODULE:f(X) (non-builtin)
%% Lean: «f/1» vX
computation(#c_call{module = #c_literal{val = Module}, name = #c_literal{val = Name}} = Core,
            State)
        when is_atom(Module), is_atom(Name) ->
    remote_computation(Core, State);
%% Erlang: M:F(A1, ..., An), with a computed module or function
%% Lean: as apply(M, F, [A1, ..., An])
computation(#c_call{anno = Anno, module = Module, name = Name, args = Args}, State) ->
    List = lists:foldr(fun(Arg, Tail) -> #c_cons{anno = Anno, hd = Arg, tl = Tail} end,
        #c_literal{anno = Anno, val = []}, Args),
    computation(#c_call{anno = Anno, module = #c_literal{val = erlang},
        name = #c_literal{val = apply}, args = [Module, Name, List]}, State);
computation(#c_primop{anno = Anno, name = #c_literal{val = Op}, args = Args}, State) ->
    prim_op(Op, Anno, Args, State);
%% Integer construction is a computation: invalid values or sizes raise badarg.
computation(#c_binary{anno = Anno, segments = Segments}, State0) ->
    {Translated, State1} = lists:mapfoldl(fun binary_segment/2, State0, Segments),
    {node(~"bitstring_constructor", Anno, #{~"segments" => Translated}), State1};
%% Construction remains a value; updates may fail and are computations.
computation(#c_map{arg = #c_literal{val = Base}, is_pat = false} = Map, State0)
        when is_map(Base), map_size(Base) =:= 0 ->
    case lists:all(fun(#c_map_pair{op = #c_literal{val = assoc}}) -> true;
                     (_) -> false end, Map#c_map.es) of
        true ->
            {Translated, State1} = value(Map, State0),
            {node(~"return", Map#c_map.anno, #{~"values" => [Translated]}), State1};
        false -> map_update(Map, State0)
    end;
computation(#c_map{is_pat = false} = Map, State0) ->
    map_update(Map, State0);
%% Everything else (literals, cons, etc)
%% Lean: Lynx.Result.ok (Lynx.Term.integer 0)
computation(Value, State0) when is_record(Value, c_literal); is_record(Value, c_var);
                                is_record(Value, c_fun); is_record(Value, c_cons);
                                is_record(Value, c_tuple) ->
    {Translated, State1} = value(Value, State0),
    {node(~"return", cerl:get_ann(Value), #{~"values" => [Translated]}), State1};
computation(Core, _State) ->
    unsupported(Core).

%% Calls with a literal module and function, to builtins, other modules, or
%% this module.
remote_computation(#c_call{anno = Anno, module = #c_literal{val = Module},
                           name = #c_literal{val = Name}, args = Args}, State0) ->
    Arity = length(Args),
    case State0#state.dispatch of
        {Module, #{{Name, Arity} := Local}, _, _, _} ->
            expression(#c_apply{anno = Anno, op = #c_var{name = Local}, args = Args}, State0);
        _ ->
            remote_call(Module, Name, Args, Anno, State0)
    end.

remote_call(Module, Name, Args, Anno, State0) ->
    Arity = length(Args),
    {Context, Callback} = State0#state.remote,
    case Callback(Context, Module, Name, Arity, Anno, State0#state.funs) of
        local when Module =:= State0#state.module ->
            expression(#c_apply{anno = Anno, op = #c_var{name = {Name, Arity}}, args = Args},
                State0);
        {Callee, NewFuns, NewContext} ->
            {TranslatedArgs, State1} = lists:mapfoldl(fun value/2,
                State0#state{funs = NewFuns, remote = {NewContext, Callback}}, Args),
            Call = remote_call_node(module_name(Module), atom_to_binary(Name, utf8),
                TranslatedArgs, Callee, Anno),
            {Call, call_purity(Callee, State1)}
    end.

%% Core lowers orelse and andalso to a case on the left operand, raising badarg
%% on other values unless the compiler knows the operand is a Boolean. Elixir
%% lowers its strict and/or the same way, matching false first and raising
%% {badbool, Op, Value} instead. When Elixir's operators nest to the left, the
%% outer cases raise case_clause, which cannot happen for Boolean operands. The
%% combinators keep the short circuit: the right operand is selected only after
%% the left one returns.
short_circuit(#c_case{arg = #c_values{}}) ->
    none;
short_circuit(#c_case{clauses = [
        #c_clause{pats = [#c_literal{val = FirstVal}], guard = #c_literal{val = true}, body = FirstBody} = First,
        #c_clause{pats = [#c_literal{val = SecondVal}], guard = #c_literal{val = true}, body = SecondBody}
        | Rest]} = Case) when {FirstVal, SecondVal} =:= {true, false}; {FirstVal, SecondVal} =:= {false, true} ->
    {OnTrue, OnFalse} = case FirstVal of
        true -> {FirstBody, SecondBody};
        false -> {SecondBody, FirstBody}
    end,
    Raises = case Rest of
        [] ->
            case lists:member(compiler_generated, cerl:get_ann(First)) of
                true -> any;
                false -> none
            end;
        [#c_clause{pats = [#c_var{name = Var}], guard = #c_literal{val = true}, body = Raise}] ->
            fallback_raise(Raise, Var);
        _ -> none
    end,
    Badbool = case Raises of
        any -> false;
        badarg -> false;
        {badbool, Op} -> Op;
        case_clause ->
            case boolean(cerl:case_arg(Case)) of
                true -> false;
                false -> none
            end;
        none -> none
    end,
    case {Badbool, OnTrue, OnFalse} of
        {none, _, _} -> none;
        {_, #c_literal{val = true}, Right} when Badbool =/= 'and' ->
            {~"orelse", Badbool =:= 'or', Right};
        {_, Right, #c_literal{val = false}} when Badbool =/= 'or' ->
            {~"andalso", Badbool =:= 'and', Right};
        _ -> none
    end;
short_circuit(_) ->
    none.

%% The operands of a right-nested chain of the same operator and error.
operands(Kind, Badbool, Expression) ->
    case short_circuit(Expression) of
        {Kind, Badbool, Right} -> [cerl:case_arg(Expression) | operands(Kind, Badbool, Right)];
        _ -> [Expression]
    end.

short_circuit_chain(_Kind, _Badbool, _Anno, [Last], State) ->
    operand(Last, State);
short_circuit_chain(Kind, Badbool, Anno, [Left | Rest], State0) ->
    {TranslatedLeft, State1} = operand(Left, State0),
    {TranslatedRight, State2} = short_circuit_chain(Kind, Badbool, Anno, Rest, State1),
    Fields = #{~"left" => TranslatedLeft, ~"right" => TranslatedRight},
    {node(Kind, Anno, case Badbool of
        true -> Fields#{~"badbool" => true};
        false -> Fields
    end), State2}.

operand({in, Anno, Var, Literals}, State0) ->
    {Value, State1} = value(Var, State0),
    {Elements, State2} = lists:mapfoldl(fun(Literal, Acc) -> value(cerl:abstract(Literal), Acc) end,
                                        State1, Literals),
    {node(~"in", Anno, #{~"value" => Value, ~"elements" => Elements}), State2};
operand(Expression, State) ->
    expression(Expression, State).

%% Runs of exact comparisons between one variable and literals, as expanded from
%% guard macros such as X =:= $1 orelse X =:= $2, become a single membership test
%% over a flat list of the literals, compared exactly. Neither form raises.
membership([]) ->
    [];
membership([Operand | Rest] = Operands) ->
    case literal_equality(Operand) of
        {Name, Var, _} ->
            {Run, After} = lists:splitwith(fun(Other) ->
                case literal_equality(Other) of
                    {Name, _, _} -> true;
                    _ -> false
                end
            end, Operands),
            case Run of
                [_, _ | _] ->
                    Literals = [Literal || Equality <- Run, {_, _, Literal} <- [literal_equality(Equality)]],
                    [{in, cerl:get_ann(Operand), Var, Literals} | membership(After)];
                _ ->
                    [Operand | membership(Rest)]
            end;
        none ->
            [Operand | membership(Rest)]
    end.

%% == only differs from =:= on numbers, so it is exact for atoms and bitstrings.
literal_equality(#c_call{module = #c_literal{val = erlang}, name = #c_literal{val = Op},
                         args = [Left, Right]}) when Op =:= '=:='; Op =:= '==' ->
    case {Left, Right} of
        {#c_var{name = Name} = Var, #c_literal{val = Literal}} -> exact_equality(Op, Name, Var, Literal);
        {#c_literal{val = Literal}, #c_var{name = Name} = Var} -> exact_equality(Op, Name, Var, Literal);
        _ -> none
    end;
literal_equality(_) ->
    none.

exact_equality('=:=', Name, Var, Literal) ->
    {Name, Var, Literal};
exact_equality('==', Name, Var, Literal) when is_atom(Literal); is_bitstring(Literal) ->
    {Name, Var, Literal};
exact_equality('==', _Name, _Var, _Literal) ->
    none.

fallback_raise(#c_call{module = #c_literal{val = erlang}, name = #c_literal{val = error},
                       args = [#c_tuple{es = [#c_literal{val = badarg}, #c_var{name = Var}]}]}, Var) ->
    badarg;
fallback_raise(#c_call{module = #c_literal{val = erlang}, name = #c_literal{val = error},
                       args = [#c_tuple{es = [#c_literal{val = badbool}, #c_literal{val = Op},
                                              #c_var{name = Var}]}]}, Var)
        when Op =:= 'and'; Op =:= 'or' ->
    {badbool, Op};
fallback_raise(#c_primop{name = #c_literal{val = match_fail},
                         args = [#c_tuple{es = [#c_literal{val = case_clause}, #c_var{name = Var}]}]},
               Var) ->
    case_clause;
fallback_raise(_, _) ->
    none.

%% Whether an expression returns a Boolean whenever it returns: comparisons,
%% type tests, and short circuits whose right operands are Booleans, including
%% after the bindings that compute their arguments.
boolean(#c_literal{val = Value}) ->
    is_boolean(Value);
boolean(#c_call{module = #c_literal{val = erlang}, name = #c_literal{val = Name}, args = Args}) ->
    erl_internal:comp_op(Name, length(Args)) orelse
        erl_internal:new_type_test(Name, length(Args)) orelse
        erl_internal:bool_op(Name, length(Args));
boolean(#c_let{body = Body}) ->
    boolean(Body);
boolean(#c_seq{body = Body}) ->
    boolean(Body);
boolean(#c_case{} = Case) ->
    case short_circuit(Case) of
        {_, _, Right} -> boolean(Right);
        none -> false
    end;
boolean(_) ->
    false.

%% Whether a short-circuit case is the only use of its bound left operand.
left_operand(Name, #c_case{clauses = Clauses} = Case, Others) ->
    short_circuit(Case) =/= none andalso
        not lists:any(fun(Tree) -> lists:member(Name, cerl_trees:free_variables(Tree)) end,
                      Clauses ++ Others).

let_bind(#c_let{anno = Anno, vars = Vars, arg = Arg, body = Body}, State0) ->
    {TranslatedArg, State1} = expression(Arg, State0),
    {TranslatedBody, State2} = expression(Body, State1),
    {node(~"bind", Anno, #{~"vars" => [variable(V) || V <- Vars],
        ~"computation" => TranslatedArg, ~"body" => TranslatedBody}), State2}.

computation_case(#c_case{anno = Anno, arg = Arg, clauses = Clauses0}, State0) ->
    Clauses = segment_patterns(Clauses0),
    {Translated, Next} = expression(Arg, State0),
    {Args, Bind, State1} = case Translated of
        #{~"kind" := ~"return", ~"values" := Values} ->
            {Values, none, Next};
        _ ->
            [#c_clause{pats = Patterns} | _] = Clauses,
            {Vars, BoundState} = lists:mapfoldl(fun(_, Acc) ->
                Var = var_node(#{~"generated" => Acc#state.next_var}, Anno),
                {Var, Acc#state{next_var = Acc#state.next_var + 1}}
            end, Next, lists:seq(1, length(Patterns))),
            {Vars, {Vars, Translated}, BoundState}
    end,
    Scrutinees = case Arg of
        #c_values{es = Elements} -> Elements;
        _ -> [Arg]
    end,
    {TranslatedClauses, State2} = lists:mapfoldl(fun(#c_clause{pats = Patterns} = Clause, Acc) ->
        Facts = Acc#state.size_facts,
        Bound = [Binding || {Scrutinee, Pattern} <- lists:zip(Scrutinees, Patterns, trim),
                            Fact <- [size_fact(Scrutinee, Facts)], Fact =/= unknown,
                            Binding <- pattern_facts(Pattern, Fact, false)],
        {TranslatedClause, ClauseState} =
            clause(Clause, Acc#state{size_facts = maps:merge(Facts, maps:from_list(Bound))}),
        {TranslatedClause, ClauseState#state{size_facts = Facts}}
    end, State1, Clauses),
    Match = node(~"match", Anno, #{~"expressions" => Args, ~"cases" => TranslatedClauses}),
    case Bind of
        none -> {Match, State2};
        {Binders, Computation} ->
            {node(~"bind", Anno, #{~"vars" => Binders,
                ~"computation" => Computation, ~"body" => Match}), State2}
    end.

%% Literal bitstring patterns become Lean constructor patterns, unless another
%% clause matches segments at the same position. Lean then extracts from that
%% position in every clause, rather than also matching it against a
%% constructor: functional induction cannot be derived for recursion over the
%% remaining bits when a constructor match on the input precedes extractions.
segment_patterns([#c_clause{pats = Patterns} | _] = Clauses) ->
    Positions = [Position || Position <- lists:seq(1, length(Patterns)),
        lists:any(fun(#c_clause{pats = Pats}) ->
            case lists:nth(Position, Pats) of
                #c_binary{segments = Segments} -> binary_pattern_literal(Segments, <<>>) =:= error;
                _ -> false
            end
        end, Clauses)],
    [Clause#c_clause{pats = [segment_pattern(Pattern, lists:member(Position, Positions)) ||
        {Position, Pattern} <- lists:enumerate(Pats)]} || #c_clause{pats = Pats} = Clause <- Clauses];
segment_patterns([]) ->
    [].

segment_pattern(#c_binary{anno = Anno} = Pattern, true) ->
    Pattern#c_binary{anno = [lynx_segments | Anno]};
segment_pattern(Pattern, _) ->
    Pattern.

computation_local_function(#c_letrec{anno = Anno, defs = [{#c_var{name = Loop},
             #c_fun{vars = Vars} = Fun}], body = Body}, State0) ->
    Captures = local_captures(Fun, State0, [Loop]),
    Name = local_function_name(map_size(State0#state.translated),
                              length(Captures) + length(Vars), State0#state.defs),
    %% A named fun and its self-references share one name.
    {Compiled, State0a} = compiled_name(Fun, State0),
    %% Keep recursive arguments first for structural purity proofs.
    LiftedFun = generator_widths(Anno, Fun#c_fun{vars = Vars ++ Captures}),
    State1 = State0a#state{
        local_funs = (State0a#state.local_funs)#{Loop => {Name, Compiled, Captures}},
        defs = (State0a#state.defs)#{Name => {function, LiftedFun}}},
    {TranslatedBody, State2} = expression(Body, State1),
    {TranslatedBody, State2#state{local_funs = State0#state.local_funs}}.

%% Erlang repeats a bitstring generator forever when its pattern consumes no
%% bits. Comprehensions raise badarg instead: patterns whose widths are all zero
%% literals always raise, and variable widths that may be zero are checked on
%% each iteration. The checks also give Lean the facts to prove that the loop
%% consumes bits.
generator_widths(Anno, #c_fun{body = #c_case{clauses = Clauses} = Case} = Fun) ->
    case lists:member(list_comprehension, Anno) of
        true ->
            Sizes = lists:usort([cerl:set_ann(Size, []) ||
                #c_clause{pats = Patterns} <- Clauses, #c_binary{segments = Segments} = Pattern <- Patterns,
                Consumed <- [generator_segments(Segments)], Consumed =/= [],
                not lists:any(fun consumes_bits/1, Consumed),
                #c_bitstr{size = Size} <- Consumed,
                not lists:member(cerl:set_ann(Size, []),
                                 [cerl:set_ann(Var, []) || Var <- cerl:pat_vars(Pattern)])]),
            case lists:partition(fun cerl:is_c_var/1, Sizes) of
                {[], []} ->
                    Fun;
                {Variables, []} ->
                    Fun#c_fun{anno = cerl:get_ann(Fun) ++ [{lynx_nonzero_widths, Variables}]};
                {_, _Literals} ->
                    %% Literal zero widths never consume bits, even from an empty input.
                    Fun#c_fun{body = cerl:ann_c_call(cerl:get_ann(Case), cerl:c_atom(erlang),
                                                     cerl:c_atom(error), [cerl:c_atom(badarg)])}
            end;
        false ->
            Fun
    end;
generator_widths(_Anno, Fun) ->
    Fun.

%% Segments matched before the remaining bits, which are passed to the next iteration.
generator_segments(Segments) ->
    case lists:reverse(Segments) of
        [#c_bitstr{size = #c_literal{val = all}} | Consumed] -> lists:reverse(Consumed);
        _ -> Segments
    end.

consumes_bits(#c_bitstr{type = #c_literal{val = Type}}) when Type =:= utf8; Type =:= utf16; Type =:= utf32 ->
    true;
consumes_bits(#c_bitstr{size = #c_literal{val = Size}}) ->
    is_integer(Size) andalso Size > 0;
consumes_bits(#c_bitstr{}) ->
    false.

local_function_name(Index, Arity, Definitions) ->
    Name = {list_to_atom("lynx_local_" ++ integer_to_list(Index)), Arity},
    case maps:is_key(Name, Definitions) of
        true -> local_function_name(Index + 1, Arity, Definitions);
        false -> Name
    end.

%% A closure calling an enclosing local function also needs that function's
%% captured environment, even when those variables are absent from its syntax.
local_captures(Fun, State, Ignored) ->
    Free = cerl_trees:free_variables(Fun) ++ pattern_size_variables(Fun),
    Indirect = lists:append([Captures || Name <- Free,
        not lists:member(Name, Ignored),
        {ok, {_, _, Captures}} <- [maps:find(Name, State#state.local_funs)]]),
    Names = lists:usort([V || V <- Free, not is_tuple(V)] ++
                        [V || #c_var{name = V} <- Indirect]),
    [#c_var{name = V} || V <- Names].

%% cerl_trees:free_variables/1 omits variables used as sizes in bitstring
%% patterns, such as N in <<X:N>>. Those bound outside the function are captures.
pattern_size_variables(Fun) ->
    {Sizes, Bound} = cerl_trees:fold(fun
        (#c_bitstr{size = #c_var{name = Name}}, {Sizes, Bound}) -> {[Name | Sizes], Bound};
        (#c_fun{vars = Vars}, {Sizes, Bound}) -> {Sizes, var_names(Vars) ++ Bound};
        (#c_let{vars = Vars}, {Sizes, Bound}) -> {Sizes, var_names(Vars) ++ Bound};
        (#c_try{vars = Vars, evars = EVars}, {Sizes, Bound}) ->
            {Sizes, var_names(Vars ++ EVars) ++ Bound};
        (#c_letrec{defs = Defs}, {Sizes, Bound}) ->
            {Sizes, var_names([Name || {Name, _} <- Defs]) ++ Bound};
        (#c_clause{} = Clause, {Sizes, Bound}) ->
            {Sizes, var_names(cerl:pat_list_vars(cerl:clause_pats(Clause))) ++ Bound};
        (_, Acc) -> Acc
    end, {[], []}, Fun),
    lists:usort(Sizes) -- Bound.

var_names(Vars) -> [Name || #c_var{name = Name} <- Vars].

computation_apply(#c_apply{anno = Anno, op = #c_var{name = Name}, args = Args} = Core, State0) ->
    case maps:is_key(Name, State0#state.labels) of
        true when Args =:= [] ->
            {node(~"jump", Anno, #{~"label" => function_name(Name)}), State0};
        true -> unsupported(Core);
        false ->
            {TranslatedArgs, State1} = lists:mapfoldl(fun value/2, State0, Args),
            State2 = translate_def(Name, State1),
            Calls = case State2#state.name of
                Name -> State2#state.local_calls;
                _ -> (State2#state.local_calls)#{Name => true}
            end,
            SizeCall = {Name, [size_fact(Arg, State2#state.size_facts) || Arg <- Args]},
            {local_call_node(function_name(Name), TranslatedArgs, Anno),
             State2#state{local_calls = Calls, size_calls = [SizeCall | State2#state.size_calls]}}
    end.

%% Erlang: f([]) -> ok.
%% Core inserts match_fail for arguments that match no function clause.
%% Lean (the generated fallback body):
%%   Lynx.Result.error (Lynx.Exception.error (Lynx.Term.atom "function_clause"))
%% The writable binary primop only preallocates storage; its Erlang value is empty.
prim_op(bs_init_writable, Anno, [#c_literal{}], State) ->
    expression(#c_literal{anno = Anno, val = <<>>}, State);
prim_op(match_fail, Anno, [#c_literal{val = {function_clause}}], State) ->
    {error_node(function_clause, Anno), State};
prim_op(match_fail, Anno, [#c_tuple{es = [#c_literal{val = function_clause} | _]}], State) ->
    {error_node(function_clause, Anno), State};
%% The runtime retains class and reason, but does not record stack frames.
prim_op(build_stacktrace, Anno, [Trace], State0) ->
    {Translated, State1} = value(Trace, State0),
    {node(~"stacktrace", Anno, #{~"exception" => Translated}), State1};
prim_op(raise, Anno, [Trace, Reason], State0) ->
    {TranslatedTrace, State1} = value(Trace, State0),
    {TranslatedReason, State2} = value(Reason, State1),
    {node(~"reraise", Anno, #{~"exception" => TranslatedTrace,
        ~"reason" => TranslatedReason}), State2};
prim_op(raw_raise, Anno, [Class, Reason, Trace], State0) ->
    {TranslatedClass, State1} = value(Class, State0),
    {TranslatedReason, State2} = value(Reason, State1),
    {TranslatedTrace, State3} = value(Trace, State2),
    {node(~"raise_dynamic", Anno, #{~"class" => TranslatedClass,
        ~"reason" => TranslatedReason, ~"exception" => TranslatedTrace}), State3};
prim_op(match_fail, Anno, [Reason], State0) ->
    {Translated, State1} = value(Reason, State0),
    {node(~"raise", Anno, #{~"class" => ~"error", ~"reason" => Translated}), State1};
prim_op(Op, Anno, Args, _State) ->
    unsupported(#c_primop{anno = Anno, name = #c_literal{val = Op}, args = Args}).

%% What is known about a value's size: equal to a parameter, strictly smaller
%% than one when bound inside a pattern matching it (bits when left after a
%% bitstring's segments), or unknown.
size_fact(#c_var{name = Name}, Facts) -> maps:get(Name, Facts, unknown);
size_fact(_, _Facts) -> unknown.

pattern_facts(#c_var{name = Name}, {Param, _} = Fact, Inside) ->
    [{Name, case Inside of true -> {Param, lt}; false -> Fact end}];
pattern_facts(#c_alias{var = Var, pat = Pattern}, Fact, Inside) ->
    pattern_facts(Var, Fact, Inside) ++ pattern_facts(Pattern, Fact, Inside);
pattern_facts(#c_cons{hd = Head, tl = Tail}, Fact, _Inside) ->
    pattern_facts(Head, Fact, true) ++ pattern_facts(Tail, Fact, true);
pattern_facts(#c_tuple{es = Elements}, Fact, _Inside) ->
    lists:append([pattern_facts(Element, Fact, true) || Element <- Elements]);
pattern_facts(#c_map{es = Pairs}, Fact, _Inside) ->
    lists:append([pattern_facts(Value, Fact, true) || #c_map_pair{val = Value} <- Pairs]);
%% A pattern of only the remaining bits, such as <<Rest/bits>>, is the whole bitstring.
pattern_facts(#c_binary{segments = [#c_bitstr{val = #c_var{} = Var, size = #c_literal{val = all}}]},
              Fact, Inside) ->
    pattern_facts(Var, Fact, Inside);
%% The bits left after a bitstring's segments are fewer than the bitstring's.
pattern_facts(#c_binary{segments = [_ | _] = Segments}, {Param, _}, _Inside) ->
    case lists:last(Segments) of
        #c_bitstr{val = #c_var{name = Name}, type = #c_literal{val = binary}}
                when length(Segments) > 1 ->
            [{Name, {Param, bits}}];
        _ ->
            []
    end;
pattern_facts(_Pattern, _Fact, _Inside) ->
    [].

clause(#c_clause{anno = Anno, pats = Patterns, guard = #c_literal{val = true}, body = Body}, State0) ->
    {Pats, State1} = lists:mapfoldl(fun pattern/2, State0, Patterns),
    {TranslatedBody, State2} = expression(Body, State1),
    {#{~"span" => span(Anno), ~"patterns" => Pats,
       ~"body" => TranslatedBody}, State2};
clause(#c_clause{anno = Anno, pats = Patterns, guard = Guard, body = Body}, State0) ->
    {Pats, State1} = lists:mapfoldl(fun pattern/2, State0, Patterns),
    {TranslatedGuard, State2} = expression(guard_test(Guard), State1),
    {TranslatedBody, State3} = expression(Body, State2),
    {#{~"span" => span(Anno), ~"patterns" => Pats,
       ~"guard" => TranslatedGuard,
       ~"body" => TranslatedBody}, State3};
clause(Core, _State) ->
    unsupported(Core).

%% Core wraps guards that may raise as
%% try (let V = Test in V =:= true) of Try -> Try catch _ -> false.
%% Guards already select their body only on true and fall through on exceptions,
%% so the test is enough.
guard_test(#c_try{arg = #c_let{vars = [#c_var{name = Value}], arg = Test,
                               body = #c_call{module = #c_literal{val = erlang},
                                              name = #c_literal{val = '=:='},
                                              args = [#c_var{name = Value}, #c_literal{val = true}]}},
                  vars = [#c_var{name = Try}], body = #c_var{name = Try},
                  handler = #c_literal{val = false}}) ->
    Test;
guard_test(Guard) ->
    Guard.

receive_parts(#c_let{vars = [#c_var{name = Available}, Message],
        arg = #c_primop{name = #c_literal{val = recv_peek_message}, args = []},
        body = #c_case{arg = #c_var{name = Available}, clauses = Branches}}, Loop, Core) ->
    {Scan, Wait} = receive_booleans(Branches, Core),
    {Timeout, Action} = receive_wait(Wait, Loop, Core),
    {Message, receive_clauses(Scan, Message, Loop, Core), Timeout, Action};
receive_parts(Wait, Loop, Core) ->
    {Timeout, Action} = receive_wait(Wait, Loop, Core),
    {none, [], Timeout, Action}.

receive_booleans([
        #c_clause{pats = [#c_literal{val = true}], guard = #c_literal{val = true}, body = Yes},
        #c_clause{pats = [#c_literal{val = false}], guard = #c_literal{val = true}, body = No}], _) ->
    {Yes, No};
receive_booleans(_, Core) -> unsupported(Core).

receive_wait(#c_let{vars = [#c_var{name = Expired}],
        arg = #c_primop{name = #c_literal{val = recv_wait_timeout}, args = [Timeout]},
        body = #c_case{arg = #c_var{name = Expired}, clauses = Branches}}, Loop, Core) ->
    case receive_booleans(Branches, Core) of
        {Action, #c_apply{op = #c_var{name = Loop}, args = []}} -> {Timeout, Action};
        _ -> unsupported(Core)
    end;
receive_wait(_, _, Core) -> unsupported(Core).

receive_clauses(#c_case{arg = #c_var{name = Message}, clauses = Clauses},
                #c_var{name = Message}, Loop, Core) ->
    receive_scan_clauses(Clauses, Loop, Core);
receive_clauses(Received, Message, _, Core) ->
    case received_body(Received) of
        {ok, Body} -> [#c_clause{pats = [Message], guard = #c_literal{val = true}, body = Body}];
        error -> unsupported(Core)
    end.

receive_scan_clauses([#c_clause{pats = [#c_var{}], guard = #c_literal{val = true},
        body = #c_seq{arg = #c_primop{name = #c_literal{val = recv_next}, args = []},
        body = #c_apply{op = #c_var{name = Loop}, args = []}}}], Loop, _) -> [];
receive_scan_clauses([#c_clause{body = Received} = Clause | Rest], Loop, Core) ->
    case received_body(Received) of
        {ok, Body} -> [Clause#c_clause{body = Body} | receive_scan_clauses(Rest, Loop, Core)];
        error -> unsupported(Core)
    end;
receive_scan_clauses([], _, _) -> [];
receive_scan_clauses(_, _, Core) -> unsupported(Core).

%% A matched clause removes its message before its body. When the receive's
%% value is unused, the compiler drops the body, so any value stands in for it.
received_body(#c_seq{arg = #c_primop{name = #c_literal{val = remove_message}, args = []},
                     body = Body}) ->
    {ok, Body};
received_body(#c_primop{name = #c_literal{val = remove_message}, args = []}) ->
    {ok, #c_literal{val = ok}};
received_body(_) ->
    error.

receive_clause(#c_clause{anno = Anno, pats = [Pattern], guard = Guard, body = Body}, State0) ->
    {Pat, State1} = pattern(Pattern, State0),
    {TranslatedGuard, State2} = expression(guard_test(Guard), State1),
    {TranslatedBody, State3} = expression(Body, State2),
    Bound = ordsets:intersection(cerl_trees:variables(Pattern), cerl_trees:free_variables(Body)),
    Vars = [variable(#c_var{name = Name}) || Name <- Bound],
    {#{~"span" => span(Anno), ~"pattern" => Pat, ~"vars" => Vars,
       ~"guard" => TranslatedGuard, ~"body" => TranslatedBody}, State3}.

%% Patterns share the syntax of values, but binaries in patterns match
%% segments rather than construct them, and patterns never nest computations.
pattern(Core, State0) ->
    {Translated, State1} = value(Core, State0#state{pattern = true}),
    {Translated, State1#state{pattern = State0#state.pattern}}.

%% The elements of a list of values, which can be evaluated before spawning.
spawn_arguments(#c_literal{val = List}) when is_list(List) ->
    {ok, [#c_literal{val = Value} || Value <- List]};
spawn_arguments(#c_cons{hd = Head, tl = Tail}) ->
    case cerl:is_c_var(Head) orelse cerl:is_literal(Head) of
        true ->
            case spawn_arguments(Tail) of
                {ok, Rest} -> {ok, [Head | Rest]};
                error -> error
            end;
        false -> error
    end;
spawn_arguments(_) -> error.

%% Core separates values from computations; only computations produce Result.
%% Computations the optimizer nests in values are bound by expression/2.
value(#c_fun{vars = Vars} = Fun, State0) ->
    Captures = local_captures(Fun, State0, []),
    %% Function values and their definitions take the name the compiler gave
    %% the fun, which erlang:fun_info_mfa/1 reports.
    {Compiled, State0a} = compiled_name(Fun, State0),
    Name = {Compiled, length(Captures) + length(Vars)},
    Key = {State0#state.module, Compiled, length(Vars)},
    Entry = #{module => State0#state.module, name => Name, arity => length(Vars),
              captures => Captures},
    State1 = State0a#state{funs = (State0a#state.funs)#{Key => Entry}},
    State2 = translate_def(Name, {function, Fun#c_fun{vars = Captures ++ Vars}}, State1),
    function_node(Key, Entry, cerl:get_ann(Fun), State2);
value(#c_var{anno = Anno, name = {_, Arity} = Name} = Core, State0) ->
    case maps:find(Name, State0#state.local_funs) of
        {ok, {Lifted, Compiled, Captures}} ->
            local_function_value(Lifted, Compiled, Captures, Arity, Anno, State0);
        error -> named_function_value(Core, State0)
    end;
value(#c_alias{anno = Anno, var = Var, pat = Pattern}, State0) ->
    {Translated, State1} = value(Pattern, State0),
    {node(~"alias", Anno, #{~"var" => variable(Var), ~"pattern" => Translated}), State1};
value(#c_var{} = Var, State) ->
    {variable(Var), State};
value(#c_binary{anno = Anno, segments = Segments}, #state{pattern = true} = State0) ->
    case not lists:member(lynx_segments, Anno) andalso binary_pattern_literal(Segments, <<>>) of
        {ok, Bits} -> value(#c_literal{anno = Anno, val = Bits}, State0);
        _ ->
            {Translated, State1} = binary_pattern_segments(Segments, State0),
            {node(~"bitstring_pattern", Anno, #{~"segments" => Translated}), State1}
    end;
%% Large compound literals, such as lookup tables, are pooled into module
%% definitions. Inline, they are traversed by every termination, induction, and
%% purity proof of the functions using them, even when they appear once. Their
%% elements stay inline in the definition. Names derive from the value, so
%% proofs referring to them do not depend on other literals or on translation
%% order; the module's pool shares equal values and rejects name collisions.
value(#c_literal{anno = Anno, val = Value} = Literal, State0)
        when is_tuple(Value); is_map(Value); is_bitstring(Value); is_list(Value), Value =/= [] ->
    case not lists:member(lynx_inline, Anno) andalso literal_size(Value) >= 32 of
        true ->
            Literals = State0#state.literals,
            {Name, State1} = case Literals of
                #{Value := Existing} -> {Existing, State0};
                #{} ->
                    Hash = erlang:md5(term_to_binary(Value, [deterministic])),
                    Encoded = 'Elixir.Base':encode32(Hash, [{'case', lower}, {padding, false}]),
                    New = <<"lynx_literal_", (binary:part(Encoded, 0, 8))/binary>>,
                    lists:member(New, maps:values(Literals)) andalso
                        core_error(Literal, <<"literal name collision: ", New/binary>>),
                    {New, State0#state{literals = Literals#{Value => New}}}
            end,
            {Translated, State2} = value(Literal#c_literal{anno = [lynx_inline | Anno]}, State1),
            {Translated#{~"pooled" => Name}, State2};
        false ->
            literal_value(Literal, State0)
    end;
value(#c_literal{} = Literal, State) ->
    literal_value(Literal, State);

value(#c_cons{anno = Anno, hd = Head, tl = Tail}, State0) ->
    {TranslatedHead, State1} = value(Head, State0),
    {TranslatedTail, State2} = value(Tail, State1),
    {node(~"cons", Anno, #{~"head" => TranslatedHead, ~"tail" => TranslatedTail}), State2};
value(#c_tuple{anno = Anno, es = Elements}, State0) ->
    {Translated, State1} = lists:mapfoldl(fun value/2, State0, Elements),
    {node(~"tuple", Anno, #{~"elements" => Translated}), State1};
value(#c_map{anno = Anno, es = Pairs, is_pat = true}, State0) ->
    {Entries, State1} = lists:mapfoldl(fun map_pattern_entry/2, State0, Pairs),
    {node(~"map", Anno, #{~"entries" => Entries}), State1};
value(#c_map{anno = Anno, arg = #c_literal{val = Base}, es = Pairs,
             is_pat = false}, State0) when is_map(Base), map_size(Base) =:= 0 ->
    {Entries, State1} = lists:mapfoldl(fun map_entry/2, State0, Pairs),
    {node(~"map", Anno, #{~"entries" => Entries}), State1};
value(Core, #state{pattern = true}) ->
    unsupported(Core);
value(Core, State0) ->
    {Computation, State1} = expression(Core, State0),
    Var = var_node(#{~"generated" => State1#state.next_var}, cerl:get_ann(Core)),
    {Var, State1#state{next_var = State1#state.next_var + 1,
                       binds = [{Var, Computation} | State1#state.binds]}}.

literal_value(#c_literal{anno = Anno, val = Fun} = Core, State0) when is_function(Fun) ->
    case erlang:fun_info(Fun, type) of
        {type, external} ->
            {module, Module} = erlang:fun_info(Fun, module),
            {name, Name} = erlang:fun_info(Fun, name),
            {arity, Arity} = erlang:fun_info(Fun, arity),
            external_function_value(Module, Name, Arity, Anno, State0);
        _ -> unsupported(Core)
    end;
literal_value(#c_literal{anno = Anno, val = []}, State) ->
    {node(~"nil", Anno, #{}), State};
literal_value(#c_literal{anno = Anno, val = [Head | Tail]}, State0) ->
    {TranslatedHead, State1} = value(#c_literal{anno = Anno, val = Head}, State0),
    {TranslatedTail, State2} = value(#c_literal{anno = Anno, val = Tail}, State1),
    {node(~"cons", Anno, #{~"head" => TranslatedHead, ~"tail" => TranslatedTail}), State2};
literal_value(#c_literal{anno = Anno, val = N}, State) when is_integer(N) ->
    {node(~"integer", Anno, #{~"value" => N}), State};
literal_value(#c_literal{anno = Anno, val = N}, State) when is_float(N) ->
    <<Sign:1, Exponent:11, Fraction:52>> = <<N:64/float>>,
    {node(~"float", Anno, #{~"negative" => Sign =:= 1,
        ~"exponent" => Exponent, ~"fraction" => Fraction}), State};
literal_value(#c_literal{anno = Anno, val = Bits}, State) when is_bitstring(Bits) ->
    Padding = (8 - bit_size(Bits) rem 8) rem 8,
    Bytes = binary_to_list(<<Bits/bitstring, 0:Padding>>),
    {node(~"bitstring", Anno, #{~"bytes" => Bytes, ~"last_bits" => bit_size(Bits) rem 8}), State};
literal_value(#c_literal{anno = Anno, val = Atom}, State) when is_atom(Atom) ->
    {node(~"atom", Anno, #{~"value" => atom_to_binary(Atom, utf8)}), State};
literal_value(#c_literal{anno = Anno, val = Tuple}, State) when is_tuple(Tuple) ->
    value(#c_tuple{anno = Anno, es = [#c_literal{anno = Anno, val = V} || V <- tuple_to_list(Tuple)]}, State);
literal_value(#c_literal{anno = Anno, val = Map}, State0) when is_map(Map) ->
    Pairs = [#c_map_pair{anno = Anno, op = #c_literal{val = assoc},
                       key = #c_literal{anno = Anno, val = K},
                       val = #c_literal{anno = Anno, val = V}} || {K, V} <- maps:to_list(Map)],
    value(#c_map{anno = Anno, arg = #c_literal{val = #{}}, es = Pairs}, State0).

%% The number of terms a literal renders to in Lean, counting each byte.
literal_size(Value) when is_tuple(Value) ->
    lists:foldl(fun(Element, Size) -> Size + literal_size(Element) end, 1, tuple_to_list(Value));
literal_size([Head | Tail]) ->
    1 + literal_size(Head) + literal_size(Tail);
literal_size(Value) when is_map(Value) ->
    maps:fold(fun(Key, Element, Size) -> Size + literal_size(Key) + literal_size(Element) end, 1, Value);
literal_size(Value) when is_bitstring(Value) ->
    1 + byte_size(Value);
literal_size(_) ->
    1.

%% Fold constant bitstring patterns into ordinary literals. Bound each segment
%% expansion; larger segments retain matching without changing their semantics.
binary_pattern_literal([], Bits) -> {ok, Bits};
binary_pattern_literal([#c_bitstr{val = #c_literal{val = Value},
        size = #c_literal{val = Size}, unit = #c_literal{val = Unit},
        type = #c_literal{val = integer}, flags = #c_literal{val = Flags}} | Rest], Bits)
        when is_integer(Value), is_integer(Size), Size >= 0,
             is_integer(Unit), Unit >= 1, Unit =< 256, is_list(Flags) ->
    case binary_segment_flags(Flags) of
        [Endian, Signed] when (Endian =:= big orelse Endian =:= little),
                              (Signed =:= signed orelse Signed =:= unsigned) ->
            Width = Size * Unit,
            case Width =< 4096 andalso integer_pattern_value(Value, Width, Signed) of
                true ->
                    Segment = case Endian of
                        big -> <<Value:Width/big>>;
                        little -> <<Value:Width/little>>
                    end,
                    binary_pattern_literal(Rest, <<Bits/bitstring, Segment/bitstring>>);
                false -> error
            end;
        _ -> error
    end;
binary_pattern_literal(_, _) -> error.

%% Pattern literals must be representable; unlike construction, they do not truncate.
integer_pattern_value(Value, 0, _) -> Value =:= 0;
integer_pattern_value(Value, Width, unsigned) -> Value >= 0 andalso Value < (1 bsl Width);
integer_pattern_value(Value, Width, signed) ->
    Bound = 1 bsl (Width - 1),
    Value >= -Bound andalso Value < Bound.

binary_pattern_segments([], State) -> {[], State};
binary_pattern_segments([#c_bitstr{anno = Anno, val = Value,
        type = #c_literal{val = binary}, size = Size,
        unit = #c_literal{val = Unit}} | Rest], State0)
        when is_integer(Unit), Unit >= 1, Unit =< 256 ->
    {TranslatedValue, State1} = value(Value, State0),
    {TranslatedSize, State2} = value(Size, State1),
    {Remaining, State3} = binary_pattern_segments(Rest, State2),
    {[#{~"type" => ~"binary", ~"span" => span(Anno), ~"size" => TranslatedSize,
        ~"value" => TranslatedValue, ~"unit" => Unit} | Remaining], State3};
binary_pattern_segments([#c_bitstr{type = #c_literal{val = Type}} = Segment | Rest], State0)
        when Type =:= integer; Type =:= float; Type =:= utf8; Type =:= utf16; Type =:= utf32 ->
    {Translated, State1} = binary_segment(Segment, State0),
    {Remaining, State2} = binary_pattern_segments(Rest, State1),
    {[Translated | Remaining], State2};
binary_pattern_segments([Core | _], _State) ->
    unsupported(#c_binary{anno = cerl:get_ann(Core), segments = [Core]}).

binary_segment(#c_bitstr{anno = Anno, val = Value, size = Size,
        unit = #c_literal{val = Unit}, type = #c_literal{val = binary}}, State0)
        when is_integer(Unit), Unit >= 1, Unit =< 256 ->
    {TranslatedValue, State1} = value(Value, State0),
    {TranslatedSize, State2} = value(Size, State1),
    {#{~"type" => ~"binary", ~"span" => span(Anno), ~"value" => TranslatedValue,
       ~"size" => TranslatedSize, ~"unit" => Unit}, State2};
binary_segment(#c_bitstr{unit = #c_literal{val = Unit}, type = #c_literal{val = integer},
        flags = #c_literal{val = Flags}} = Core, State0)
        when is_integer(Unit), Unit >= 1, Unit =< 256, is_list(Flags) ->
    binary_integer_segment(binary_segment_flags(Flags), Core, State0);
binary_segment(#c_bitstr{unit = #c_literal{val = Unit},
        type = #c_literal{val = float}, flags = #c_literal{val = Flags}} = Core, State0)
        when is_integer(Unit), Unit >= 1, Unit =< 256, is_list(Flags) ->
    binary_float_segment(binary_segment_flags(Flags), Core, State0);
binary_segment(#c_bitstr{size = #c_literal{val = undefined},
        unit = #c_literal{val = undefined}, type = #c_literal{val = Type},
        flags = #c_literal{val = Flags}} = Core, State0)
        when (Type =:= utf8 orelse Type =:= utf16 orelse Type =:= utf32), is_list(Flags) ->
    binary_utf_segment(binary_segment_flags(Flags), Core, State0);
binary_segment(Core, _State) ->
    core_error(Core, ~"unsupported binary segment (expected integer, float, binary, or utf8/utf16/utf32 segment)").

%% Resolve native on the translating VM so Lean only needs explicit endianness.
binary_segment_flags(Flags) ->
    lists:sort([case Flag of native -> erlang:system_info(endian); _ -> Flag end || Flag <- Flags]).

binary_integer_segment([Endian, Signed], #c_bitstr{anno = Anno, val = Value, size = Size,
        unit = #c_literal{val = Unit}}, State0)
        when (Endian =:= big orelse Endian =:= little),
             (Signed =:= signed orelse Signed =:= unsigned) ->
    {TranslatedValue, State1} = value(Value, State0),
    {TranslatedSize, State2} = value(Size, State1),
    {#{~"type" => ~"integer", ~"span" => span(Anno), ~"value" => TranslatedValue, ~"size" => TranslatedSize,
       ~"unit" => Unit, ~"signed" => Signed =:= signed,
       ~"endian" => atom_to_binary(Endian, utf8)}, State2};
binary_integer_segment(_Flags, Core, _State) ->
    core_error(Core, ~"unsupported binary segment flags (expected signed/unsigned and big/little/native)").

%% Sizes may be computed at runtime; invalid widths raise badarg or fail to match.
binary_float_segment([Endian, Signed], #c_bitstr{anno = Anno, val = Value,
        size = Size, unit = #c_literal{val = Unit}}, State0)
        when (Endian =:= big orelse Endian =:= little),
             (Signed =:= signed orelse Signed =:= unsigned) ->
    {TranslatedValue, State1} = value(Value, State0),
    {TranslatedSize, State2} = value(Size, State1),
    {#{~"type" => ~"float", ~"span" => span(Anno), ~"value" => TranslatedValue,
       ~"size" => TranslatedSize, ~"unit" => Unit,
       ~"endian" => atom_to_binary(Endian, utf8)}, State2};
binary_float_segment(_Flags, Core, _State) ->
    core_error(Core, ~"unsupported float segment flags (expected big/little/native)").

binary_utf_segment([Endian, unsigned], #c_bitstr{anno = Anno, val = Value,
        type = #c_literal{val = Type}}, State0)
        when Endian =:= big; Endian =:= little ->
    {TranslatedValue, State1} = value(Value, State0),
    {#{~"type" => atom_to_binary(Type, utf8), ~"span" => span(Anno),
       ~"value" => TranslatedValue, ~"endian" => atom_to_binary(Endian, utf8)}, State1};
binary_utf_segment(_Flags, Core, _State) ->
    core_error(Core, ~"unsupported UTF segment flags (expected unsigned and big/little/native)").

local_function_value(Lifted, Compiled, Captures, Arity, Anno, State0) ->
    Key = {State0#state.module, Compiled, Arity},
    case maps:find(Key, State0#state.funs) of
        {ok, Entry} -> function_node(Key, Entry, Anno, State0);
        error ->
            %% Reuse one wrapper so a named fun and its self-reference have
            %% the same identity. Adapt capture-first dispatch to the lifted ABI.
            {Args, State1} = lists:mapfoldl(fun(_, Acc) ->
                Arg = var_node(#{~"generated" => Acc#state.next_var}, Anno),
                {Arg, Acc#state{next_var = Acc#state.next_var + 1}}
            end, State0, lists:seq(1, Arity)),
            Name = {Compiled, length(Captures) + Arity},
            Entry = #{module => State0#state.module, name => Name, arity => Arity,
                      captures => Captures},
            State2 = translate_def(Lifted,
                State1#state{funs = (State1#state.funs)#{Key => Entry}}),
            {CaptureArgs, State3} = lists:mapfoldl(fun value/2, State2, Captures),
            Definition = node(~"def", Anno, #{
                ~"name" => function_name(Name), ~"params" => CaptureArgs ++ Args,
                ~"body" => local_call_node(function_name(Lifted), Args ++ CaptureArgs, Anno)}),
            Wrapper = #{translation => Definition, local_calls => [Lifted], size_calls => [],
                        purity => pure, dispatches => false},
            State4 = State3#state{translated = (State3#state.translated)#{Name => Wrapper}},
            function_node(Key, Entry, Anno, State4)
    end.

%% External captures share one dispatch entry per MFA, including repeated literals
%% and local captures of the same function, which behave the same. The entry calls
%% the function through a wrapper named Module:Function.
external_function_value(Module, Function, Arity, Anno, State0) ->
    Key = {Module, Function, Arity},
    case maps:find(Key, State0#state.funs) of
        {ok, Entry} -> function_node(Key, Entry, Anno, State0);
        error ->
            Name = {list_to_atom(atom_to_list(Module) ++ ":" ++ atom_to_list(Function)), Arity},
            Args = [#c_var{name = Index} || Index <- lists:seq(0, Arity - 1)],
            Entry = #{module => State0#state.module, name => Name, arity => Arity,
                      captures => []},
            Fun = #c_fun{anno = Anno, vars = Args, body = #c_call{anno = Anno,
                module = #c_literal{val = Module}, name = #c_literal{val = Function}, args = Args}},
            State1 = State0#state{funs = (State0#state.funs)#{Key => Entry}},
            State2 = translate_def(Name, {function, Fun}, State1),
            function_node(Key, Entry, Anno, State2)
    end.

named_function_value(#c_var{anno = Anno, name = {Function, Arity} = Name}, State0) ->
    Key = {State0#state.module, Function, Arity},
    case maps:find(Key, State0#state.funs) of
        {ok, Entry} -> function_node(Key, Entry, Anno, State0);
        error ->
            Entry = #{module => State0#state.module, name => Name, arity => Arity, captures => []},
            State1 = State0#state{funs = (State0#state.funs)#{Key => Entry}},
            State2 = translate_def(Name, State1),
            function_node(Key, Entry, Anno, State2)
    end.

%% The name the compiler gave a fun. Copies the compiler inlines have none, and
%% are named as the compiler names them later, counting them in translation order.
compiled_name(#c_fun{} = Fun, #state{name = {Function, Arity}, anonymous = Count} = State) ->
    case [Compiled || {id, {_, _, Compiled}} <- cerl:get_ann(Fun)] of
        [Compiled | _] -> {Compiled, State};
        [] ->
            Name = list_to_atom(lists:flatten(io_lib:format("-~ts/~b-anonymous-~b-",
                [Function, Arity, Count]))),
            {Name, State#state{anonymous = Count + 1}}
    end.

map_update(#c_map{anno = Anno, arg = Base, es = Pairs}, State0) ->
    {TranslatedBase, State1} = value(Base, State0),
    map_updates(Pairs, TranslatedBase, Anno, State1).

map_updates([], Base, Anno, State) ->
    {node(~"return", Anno, #{~"values" => [Base]}), State};
map_updates([#c_map_pair{anno = Anno, op = #c_literal{val = Op},
                         key = Key, val = Value} | Rest], Base, MapAnno, State0)
        when Op =:= assoc; Op =:= exact ->
    Name = case Op of assoc -> put; exact -> update end,
    {Context, Callback} = State0#state.remote,
    {Callee, NewFuns, NewContext} = Callback(Context, maps, Name, 3, Anno, State0#state.funs),
    {TranslatedKey, State1} = value(Key,
        State0#state{funs = NewFuns, remote = {NewContext, Callback}}),
    {TranslatedValue, State2} = value(Value, State1),
    Call = remote_call_node(module_name(maps), atom_to_binary(Name, utf8),
        [TranslatedKey, TranslatedValue, Base], Callee, Anno),
    State3 = call_purity(Callee, State2),
    case Rest of
        [] -> {Call, State3};
        _ ->
            Var = var_node(#{~"generated" => State3#state.next_var}, Anno),
            {Body, State4} = map_updates(Rest, Var, MapAnno,
                State3#state{next_var = State3#state.next_var + 1}),
            {node(~"bind", MapAnno, #{~"vars" => [Var],
                ~"computation" => Call, ~"body" => Body}), State4}
    end;
map_updates([Core | _], _, _, _) -> unsupported(Core).

map_pattern_entry(#c_map_pair{anno = Anno, op = #c_literal{val = exact},
                               key = Key, val = Pattern}, State0) ->
    {TranslatedKey, State1} = value(Key, State0),
    {TranslatedPattern, State2} = value(Pattern, State1),
    {#{~"span" => span(Anno), ~"key" => TranslatedKey,
       ~"value" => TranslatedPattern}, State2};
map_pattern_entry(Core, _) -> unsupported(Core).

map_entry(#c_map_pair{anno = Anno, op = #c_literal{val = assoc},
                       key = Key, val = Value}, State0) ->
    {TranslatedKey, State1} = value(Key, State0),
    {TranslatedValue, State2} = value(Value, State1),
    {#{~"span" => span(Anno), ~"key" => TranslatedKey,
       ~"value" => TranslatedValue}, State2};
map_entry(Core, _State) ->
    unsupported(Core).

%% The table contains code; every function value carries its name and its own
%% capture values.
function_node({Module, Name, Arity}, #{captures := Captures}, Anno, State0) ->
    {Values, State1} = lists:mapfoldl(fun value/2, State0, Captures),
    {node(~"function", Anno, #{~"module" => atom_to_binary(Module, utf8),
        ~"name" => atom_to_binary(Name, utf8), ~"arity" => Arity, ~"captures" => Values}), State1}.

%% Preserve Core names. Lean owns identifier escaping and separates integer
%% compiler temporaries from atom-named source variables.
variable(#c_var{anno = Anno, name = Name}) when is_integer(Name), Name >= 0 ->
    var_node(Name, Anno);
variable(#c_var{anno = Anno, name = Name}) when is_atom(Name) ->
    var_node(atom_to_binary(Name, utf8), Anno);
variable(Core) ->
    unsupported(Core).

function_name({Name, Arity}) when is_atom(Name), is_integer(Arity), Arity >= 0 ->
    atom_to_binary(Name, utf8).

var_node(Name, Anno) ->
    node(~"var", Anno, #{~"name" => Name}).

error_node(Reason, Anno) ->
    node(~"raise", Anno, #{~"class" => ~"error",
        ~"reason" => node(~"atom", Anno, #{~"value" => atom_to_binary(Reason, utf8)})}).

local_call_node(Name, Args, Anno) ->
    node(~"local_call", Anno, #{~"name" => Name, ~"args" => Args}).

%% Calls carry the callee's purity: other computations embed pure callees.
remote_call_node(Module, Name, Args, Callee, Anno) ->
    node(~"remote_call", Anno,
         with_purity(#{~"module" => Module, ~"name" => Name, ~"args" => Args}, Callee)).

%% A caller is as impure as its callees, and calls function values when they do.
call_purity({Purity, Dispatches}, State) ->
    State#state{purity = join_purity(State#state.purity, Purity),
                dispatches = State#state.dispatches orelse Dispatches}.

node(Kind, Anno, Fields) ->
    Fields#{~"kind" => Kind, ~"span" => span(Anno)}.

span([{Line, Column} | _]) when is_integer(Line), Line > 0, is_integer(Column), Column > 0 ->
    [Line, Column];
span([Line | _]) when is_integer(Line), Line > 0 ->
    [Line];
span([_ | Rest]) ->
    span(Rest);
span([]) ->
    [].

unsupported(Core) ->
    core_error(Core, <<"unsupported Core expression:\n\n",
                       (unicode:characters_to_binary(core_pp:format(Core)))/binary>>).

core_error(Core, Reason) ->
    throw({error, Core, Reason}).

